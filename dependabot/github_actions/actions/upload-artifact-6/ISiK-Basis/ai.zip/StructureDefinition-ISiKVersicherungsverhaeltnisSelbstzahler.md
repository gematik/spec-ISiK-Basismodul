# ISiKVersicherungsverhaeltnisSelbstzahler - ISiK Basis Implementierungsleitfaden v6.0.0-rc

ISiK Basis Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiKVersicherungsverhaeltnisSelbstzahler**

## Resource Profile: ISiKVersicherungsverhaeltnisSelbstzahler 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKVersicherungsverhaeltnisSelbstzahler | *Version*:6.0.0-rc |
| Active as of 2025-12-17 | *Computable Name*:ISiKVersicherungsverhaeltnisSelbstzahler |

 
Dieses Profil ermöglicht die Darstellung eines gesetzlichen Versicherungsverhältnisses in ISiK Szenarien. 

### Motivation

 
ISiK unterstützt Anwendungsszenarien, in denen durch das Krankenhaus erbrachte Leistungen erfasst oder gegenüber Kostenträgern abgerechnet werden. In diesen Anwendungsszenarien wird das Versicherungsverhältnis verwendet, um bspw. den Versicherungsstatus oder die Rechnungsanschrift der Versicherung zu ermitteln.
 In FHIR werden Versicherungsverhältnisse mit der Coverage-Ressource repräsentiert. 

### Kompatibilität

 
Das Profil ISiKVersicherungsverhaeltnisSelbstzahler basiert auf dem [Selbstzahler-Profil der deutschen Basisprofile](https://fhir.de/StructureDefinition/coverage-de-sel). Instanzen, die gegen ISiKVersicherungsverhaeltnisSelbstzahler valide sind, sind auch valide gegen 
* [Selbstzahler-Profil der deutschen Basisprofile](https://fhir.de/StructureDefinition/coverage-de-sel)
 
Hinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden. 

**Usages:**

* Examples for this Profile: [Coverage/CoveragePrivat](Coverage-CoveragePrivat.md) and [Coverage/SZ1VersicherungSelbstzahler](Coverage-SZ1VersicherungSelbstzahler.md)
* CapabilityStatements using this Profile: [Akteur ISiKCapabilityStatementBasisServerAkteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur-expanded.md) and [CapabilityStatement für Rolle ISiKCapabilityStatementVersicherungsverhaeltnisRolle](CapabilityStatement-ISiKCapabilityStatementVersicherungsverhaeltnisRolle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/basis|current/StructureDefinition/ISiKVersicherungsverhaeltnisSelbstzahler)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ISiKVersicherungsverhaeltnisSelbstzahler.csv), [Excel](StructureDefinition-ISiKVersicherungsverhaeltnisSelbstzahler.xlsx), [Schematron](StructureDefinition-ISiKVersicherungsverhaeltnisSelbstzahler.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKVersicherungsverhaeltnisSelbstzahler",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKVersicherungsverhaeltnisSelbstzahler",
  "version" : "6.0.0-rc",
  "name" : "ISiKVersicherungsverhaeltnisSelbstzahler",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-17",
  "publisher" : "gematik GmbH",
  "contact" : [
    {
      "name" : "gematik GmbH",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://gematik.de"
        }
      ]
    }
  ],
  "description" : "Dieses Profil ermöglicht die Darstellung eines gesetzlichen Versicherungsverhältnisses in ISiK Szenarien.  \n### Motivation\nISiK unterstützt Anwendungsszenarien, in denen durch das Krankenhaus erbrachte Leistungen erfasst oder gegenüber Kostenträgern abgerechnet werden.\nIn diesen Anwendungsszenarien wird das Versicherungsverhältnis verwendet, um bspw. den Versicherungsstatus oder die Rechnungsanschrift der Versicherung zu ermitteln.  \nIn FHIR werden Versicherungsverhältnisse mit der Coverage-Ressource repräsentiert.\n\n### Kompatibilität\nDas Profil ISiKVersicherungsverhaeltnisSelbstzahler basiert auf dem [Selbstzahler-Profil der deutschen Basisprofile](https://fhir.de/StructureDefinition/coverage-de-sel). \nInstanzen, die gegen ISiKVersicherungsverhaeltnisSelbstzahler valide sind, sind auch valide gegen\n\n* [Selbstzahler-Profil der deutschen Basisprofile](https://fhir.de/StructureDefinition/coverage-de-sel)\n\nHinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden.",
  "fhirVersion" : "4.0.1",
  "kind" : "resource",
  "abstract" : false,
  "type" : "Coverage",
  "baseDefinition" : "http://fhir.de/StructureDefinition/coverage-de-sel",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Coverage",
        "path" : "Coverage"
      },
      {
        "id" : "Coverage.status",
        "path" : "Coverage.status",
        "short" : "Status",
        "comment" : "Zeigt den aktuellen Status der Ressource an.     \n  **WICHTIGER Hinweis für Implementierer:**    \n  * Alle server-seitigen Implementierungen MÜSSEN in der Lage sein, \n  die systemintern möglichen Statuswerte korrekt in FHIR abzubilden, mindestens jedoch den Wert `active`.\n  * Alle client-seitigen Implementierungen MÜSSEN in der Lage sein, sämtliche Status-Codes zu interpretieren und dem Anwender in angemessener Form darstellen zu können, \n  beispielsweise durch Ausblenden/Durchstreichen von Ressourcen mit dem status `entered-in-error` und Ausgrauen von Ressourcen, die einen Plan- oder Entwurfs-Status haben.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.type",
        "path" : "Coverage.type",
        "comment" : "\n  Die Angabe der Versicherungsart `SEL` dient der Kennzeichnung dieser Coverage-Ressource als Selbszahler-Verhältnis.  \n  **Begründung Pflichtfeld:** Die Angabe der Versicherungsart dient der Unterscheidung, wenn zu einem Patienten mehrere Coverage-Ressourcen hinterlegt sind, \n  z.B. gesetzliche Versicherung + Selbszahlerverhältnis und als Suchkriterium, um gezielt nach der in einem konkreten Kontext relevanten Coverage suchen zu können.  \n  **Historie:**  \n  28.07.2017 (zulip): TC Konsens bzgl. Verwendung eines eigenen ValueSets anstelle des im Standard definierten preferred bindings, da die dortigen Codes nicht passen.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.type.coding:VersicherungsArtDeBasis",
        "path" : "Coverage.type.coding",
        "sliceName" : "VersicherungsArtDeBasis",
        "short" : "Codierte Darstellung der Versicherungsart"
      },
      {
        "id" : "Coverage.type.coding:VersicherungsArtDeBasis.system",
        "path" : "Coverage.type.coding.system",
        "short" : "Codier-Schema",
        "comment" : "Hier ist stets der Wert `http://fhir.de/CodeSystem/versicherungsart-de-basis` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Coverage.type.coding:VersicherungsArtDeBasis.code",
        "path" : "Coverage.type.coding.code",
        "short" : "Code",
        "comment" : "Hier ist stets der Code `SEL` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Coverage.beneficiary",
        "path" : "Coverage.beneficiary",
        "comment" : "Hier handelt es ich konkret um den Patienten, für den die Kostenübernahme gilt.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.beneficiary.reference",
        "path" : "Coverage.beneficiary.reference",
        "short" : "Patienten-Link",
        "comment" : "Die Verlinkung auf eine Patienten-Ressource dient der technischen Zuordnung der Dokumentation zu einem Patienten \n    und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Coverage.payor",
        "path" : "Coverage.payor",
        "short" : "Kostenträger",
        "comment" : "Der Kostenträger in einem Selbstzahlerverhältnis kann der Patient selbst sein, ein Angehöriger (z.B. Eltern) oder eine Organisation (z.B. Botschaft/Amt).\n  **Hinweis:** In der Regel sind `payor`und `subscriber` bei Selbstzahlerverhältnissen identisch (die Person , die die Kostenübernahme unterschreibt/zusichert, übernimmt auch die Kosten).\n  Es kann jedoch Ausnahmen geben, z.B. der Kostenträger ist eine Organisation, die Kostenübernahme wird jedoch durch eine Person (Vertreter der Organisation) unterzeichnet.",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://hl7.org/fhir/StructureDefinition/Patient",
              "http://hl7.org/fhir/StructureDefinition/RelatedPerson",
              "http://hl7.org/fhir/StructureDefinition/Organization"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Coverage.payor.reference",
        "path" : "Coverage.payor.reference",
        "short" : "Personen-Link",
        "comment" : "Ist der Kostenträger eine Person (entweder der Patient selbst oder ein Angehöriger), dann MUSS ein Link auf `Patient`, bzw. `RelatedPerson` angegeben werden.  \n    Ist der Kostenträger eine Organisation, dann KANN ein Link auf `Organization` angegeben werden.  \n    Die Verlinkung dient der technischen Zuordnung der Dokumentation zu einer Person \n    und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.payor.display",
        "path" : "Coverage.payor.display",
        "short" : "Organisations-Bezeichnung",
        "comment" : "Ist der Kostenträger eine Organisation und wurde kein Link auf eine `Organization`-Ressource angegeben,\n     dann MUSS die Bezeichnung der Organisation angegeben werden.",
        "mustSupport" : true
      }
    ]
  }
}

```
