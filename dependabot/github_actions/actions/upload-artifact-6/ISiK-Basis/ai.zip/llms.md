# basis#6.0.0-rc: ISiK Basis Implementierungsleitfaden

## Pages

* [Einführung](index.md)
* [Allgemeine Hinweise zu Suchparametern](UebergreifendeFestlegungen_Suchparameter.md)
* [REST-API](UebergreifendeFestlegungen_Rest.md)
* [Umgang mit fehlenden Daten](UebergreifendeFestlegungen_UmgangFehlendeDaten.md)
* [Akteurs- und Rollenmodell](Erlaeuterung-Akteurs-und-Rollenmodell.md)
* [Bestätigungsrelevante Systeme](UebergreifendeFestlegungen_BestaetigungsrelevanteSysteme.md)
* [Methodik](UebergreifendeFestlegungen_Methodik.md)
* [Umgang mit FHIR-Artefakten](UebergreifendeFestlegungen_FHIR_Artefakte.md)
* [Must-Support-Flags](UebergreifendeFestlegungen_Must-Support-Flags.md)
* [Motivation](Motivation.md)
* [Szenario 2: Kreuz-Stern-Diagnose](Szenario-2-Kreuz-Stern-Diagnose.md)
* [FHIR-Artefakte](artifacts.md)
* [Herstellung von Patienten- und Besuchskontext](Patient-Besuch-Kontext.md)
* [Kompatibilität der gematik-Spezifikation](KompatibilitaetDerGematikSpezifikation_Andere.md)
* [Repräsentationsformate](UebergreifendeFestlegungen_Repraesentationsformate.md)
* [Abbildung des Konstrukts "Fall"](Abbildung-des-Konstrukts-Fall.md)
* [Szenario 1: DRG-Fall, Kind mit Wahlleistung](Szenario-1-DRG-Fall-Kind-mit-Wahlleistung.md)
* [Release Notes](ReleaseNotes.md)
* [Datenübermittlung aus Subsystemen](Datenuebermittlung-aus-Subsystemen.md)
* [Kompatibilität der gematik-Spezifikation IHE](KompatibilitaetDerGematikSpezifikation_IHE.md)

## Resources

### CodeSystems

* [TestKatalog](CodeSystem-CodeSystemExample.md)

### ValueSets

* [DiagnosesSCT](ValueSet-DiagnosesSCT.md)
* [ISiKLocationPhysicalType](ValueSet-ISiKLocationPhysicalType.md)
* [TestValueSet](ValueSet-ISiKValueSetExample.md)
* [ProzedurenCodesSCT](ValueSet-ProzedurenCodesSCT.md)
* [ProzedurenKategorieSCT](ValueSet-ProzedurenKategorieSCT.md)
* [Schwangerschaft Erwarteter Entbindungstermin Methode](ValueSet-SchwangerschaftEtMethodeVS.md)
* [Schwangerschaftsstatus Valueset](ValueSet-SchwangerschaftsstatusVS.md)
* [Stillstatus LOINC Antwortoptionen](ValueSet-StillstatusVS.md)
* [Current Smoking Status - IPS](ValueSet-current-smoking-status-uv-ips.md)

### Resource Profiles

* [ISiKAbrechnungsfall](StructureDefinition-ISiKAbrechnungsfall.md)
* [ISiK Alkohol Abusus](StructureDefinition-ISiKAlkoholAbusus.md)
* [ISiKAllergieUnvertraeglichkeit](StructureDefinition-ISiKAllergieUnvertraeglichkeit.md)
* [ISiKAngehoeriger](StructureDefinition-ISiKAngehoeriger.md)
* [ISiKBerichtBundle](StructureDefinition-ISiKBerichtBundle.md)
* [ISiKCodeSystem](StructureDefinition-ISiKCodeSystem.md)
* [ISiKDiagnose](StructureDefinition-ISiKDiagnose.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKLebensZustand](StructureDefinition-ISiKLebensZustand.md)
* [ISiKOrganisation](StructureDefinition-ISiKOrganisation.md)
* [ISiKOrganisationFachabteilung](StructureDefinition-ISiKOrganisationFachabteilung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)
* [ISiKProzedur](StructureDefinition-ISiKProzedur.md)
* [ISiK Raucherstatus](StructureDefinition-ISiKRaucherStatus.md)
* [ISiK Schwangerschaft - Erwarteter Entbindungstermin](StructureDefinition-ISiKSchwangerschaftErwarteterEntbindungstermin.md)
* [ISiK Schwangerschaftsstatus](StructureDefinition-ISiKSchwangerschaftsstatus.md)
* [ISiKStandort](StructureDefinition-ISiKStandort.md)
* [ISiKStandortBettenstellplatz](StructureDefinition-ISiKStandortBettenstellplatz.md)
* [ISiKStandortRaum](StructureDefinition-ISiKStandortRaum.md)
* [ISiKStillstatus](StructureDefinition-ISiKStillstatus.md)
* [ISiKValueSet](StructureDefinition-ISiKValueSet.md)
* [ISiKVersicherungsverhaeltnisGesetzlich](StructureDefinition-ISiKVersicherungsverhaeltnisGesetzlich.md)
* [ISiKVersicherungsverhaeltnisSelbstzahler](StructureDefinition-ISiKVersicherungsverhaeltnisSelbstzahler.md)
* [ISiKVersicherungsverhaeltnisSonstige](StructureDefinition-ISiKVersicherungsverhaeltnisSonstige.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ISiKTerminPriorityExtension](StructureDefinition-ISiKTerminPriorityExtension.md)

### Accounts

* [AbrechnungsfallDRG](Account-AbrechnungsfallDRG.md)
* [AbrechnungsfallGonarthrose](Account-AbrechnungsfallGonarthrose.md)
* [SZ1DRGFall](Account-SZ1DRGFall.md)
* [SZ2DRGFall](Account-SZ2DRGFall.md)

### AllergyIntolerances

* [ISiKAllergieUnvertraeglichkeitBeispiel1](AllergyIntolerance-ISiKAllergieUnvertraeglichkeitBeispiel1.md)

### Bundles

* [BundleExampleIntensivstation](Bundle-BundleExampleIntensivstation.md)
* [ISiKBundle-Example](Bundle-ISiKBundle-Example.md)

### CapabilityStatements

* [CapabilityStatement für Rolle AufbaustrukturRolle](CapabilityStatement-ISiKCapabilityStatementAufbaustrukturRolle.md)
* [Akteur ISiKCapabilityStatementBasisServerAkteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur.md)
* [Akteur ISiKCapabilityStatementBasisServerAkteur](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementCompositionKonsumentenRolle](CapabilityStatement-ISiKCapabilityStatementCompositionKonsumentenRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementErweiterteStammdatenRolle](CapabilityStatement-ISiKCapabilityStatementErweiterteStammdatenRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementGesundheitsstatusRolle](CapabilityStatement-ISiKCapabilityStatementGesundheitsstatusRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementKlinischeRolle](CapabilityStatement-ISiKCapabilityStatementKlinischeRolle.md)
* [CapabilityStatement für Rolle LeistungserbringerRolle](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)
* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementTerminologieRolle](CapabilityStatement-ISiKCapabilityStatementTerminologieRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementVersicherungsverhaeltnisRolle](CapabilityStatement-ISiKCapabilityStatementVersicherungsverhaeltnisRolle.md)

### Conditions

* [AltersbedingteKreislaufstoerung](Condition-AltersbedingteKreislaufstoerung.md)
* [BehandlungsDiagnoseFreitext](Condition-BehandlungsDiagnoseFreitext.md)
* [Example-condition-ausrufezeichen-primaer](Condition-Example-condition-ausrufezeichen-primaer.md)
* [Example-condition-ausrufezeichen-sekundaer](Condition-Example-condition-ausrufezeichen-sekundaer.md)
* [Example-condition-kreuz-stern-primaer](Condition-Example-condition-kreuz-stern-primaer.md)
* [Example-condition-kreuz-stern-sekundaer](Condition-Example-condition-kreuz-stern-sekundaer.md)
* [MittelgradigeIntelligenzminderung](Condition-MittelgradigeIntelligenzminderung.md)
* [PrimaereGonarthroseMinimal](Condition-PrimaereGonarthroseMinimal.md)
* [PrimaereGonarthroseNormal](Condition-PrimaereGonarthroseNormal.md)
* [SZ2Primaerdiagnose](Condition-SZ2Primaerdiagnose.md)
* [SZ2Sekundaerdiagnose](Condition-SZ2Sekundaerdiagnose.md)

### Coverages

* [CoverageGesetzlich](Coverage-CoverageGesetzlich.md)
* [CoveragePrivat](Coverage-CoveragePrivat.md)
* [CoverageSonstige](Coverage-CoverageSonstige.md)
* [SZ1VersicherungGesetzlich](Coverage-SZ1VersicherungGesetzlich.md)
* [SZ1VersicherungSelbstzahler](Coverage-SZ1VersicherungSelbstzahler.md)
* [SZ2VersicherungGesetzlich](Coverage-SZ2VersicherungGesetzlich.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)

### ImplementationGuides

* [ISiK Basis Implementierungsleitfaden](index.md)

### Locations

* [BettenstellplatzStandortBeispiel](Location-BettenstellplatzStandortBeispiel.md)
* [RaumStandortBeispiel](Location-RaumStandortBeispiel.md)
* [Station A](Location-StationStandortBeispiel.md)

### Observations

* [ISiKAlkoholAbususBeispiel](Observation-ISiKAlkoholAbususBeispiel.md)
* [ISiKRaucherStatusBeispiel](Observation-ISiKRaucherStatusBeispiel.md)
* [ISiKSchwangerschaftErwarteterEntbindungsterminBeispiel](Observation-ISiKSchwangerschaftErwarteterEntbindungsterminBeispiel.md)
* [ISiKSchwangerschaftsstatusBeispiel](Observation-ISiKSchwangerschaftsstatusBeispiel.md)
* [ISiKStillstatusBeispiel](Observation-ISiKStillstatusBeispiel.md)

### Organizations

* [Allgemeinchirurgie](Organization-AbteilungAllgemeinchirurgieOrganisationBeispiel.md)
* [Uniklinik Entenhausen](Organization-KrankenhausOrganisationBeispiel.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [IsikPatientTemplate](Patient-IsikPatientTemplate.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)

### Practitioners

* [PractitionerWalterArzt](Practitioner-PractitionerWalterArzt.md)

### Procedures

* [Appendektomie](Procedure-Appendektomie.md)

### RelatedPeople

* [ISiKAngehoerigerMustermann](RelatedPerson-ISiKAngehoerigerMustermann.md)
* [SZ1Mutter](RelatedPerson-SZ1Mutter.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
