# subscription#6.0.0-rc: ISiK Subscription Implementierungsleitfaden

## Pages

* [Einführung](index.md)
* [Übergreifende Festlegungen](Festlegungen.md)
* [Patient merge und Notification](Patientenzusammenfuehrung.md)
* [Akteure](Akteure.md)
* [Release Notes](ReleaseNotes.md)
* [FHIR-Artefakte](artifacts.md)
* [Use Cases - Übersicht](UseCases.md)
* [Funktionen und Interaktionen](FunktionenInteraktionen.md)
* [Encounter Merge Notification (Fallzusammenführung)](Fallzusammenfuehrung.md)

## Resources

### CodeSystems

* [ISiK-SubscriptionTopic](CodeSystem-ISiKSubscriptionTopic.md)
* [SubscriptionNotificationType](CodeSystem-subscription-notification-type.md)

### ValueSets

* [FhirMimeTypeVS](ValueSet-FhirMimeTypeVS.md)
* [ISiKSubscriptionTopic ValueSet](ValueSet-ISiKSubscriptionTopicVS.md)
* [SubscriptionNotificationType](ValueSet-subscription-notification-type.md)

### Resource Profiles

* [R4 Topic-Based Subscription Notification Bundle](StructureDefinition-BackportSubscriptionNotificationR4Fixed.md)
* [R4 Backported R5 SubscriptionStatus](StructureDefinition-BackportSubscriptionStatusR4Fixed.md)
* [ISiK Subscription](StructureDefinition-ISiKSubscription.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)

### CapabilityStatements

* [CapabilityStatement für Rolle &quot;Subscription&quot;](CapabilityStatement-ISiKCapabilityStatementSubscriptionRolle.md)
* [Akteur &quot;ISiKCapabilityStatementSubscriptionServerAkteur&quot; (Expanded)](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.md)
* [Akteur &quot;ISiKCapabilityStatementSubscriptionServerAkteur&quot;](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.md)

### ImplementationGuides

* [ISiK Subscription Implementierungsleitfaden](index.md)

### Subscriptions

* [PatientMergeSubscriptionExample](Subscription-PatientMergeSubscriptionExample.md)
