# terminplanung#6.0.0-rc: ISiK Terminplanung Implementierungsleitfaden

## Pages

* [Einführung](index.md)
* [Prozesse](Prozesse.md)
* [Informationsmodell](Informationsmodell.md)
* [Architekturoptionen](Architekturoptionen.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Akteure](Akteure.md)
* [Kompatibilität zu anderen nationalen FHIR-basierten Spezifikationen](Kompatibilitaet.md)
* [Release Notes](ReleaseNotes.md)
* [Operation: $book](Operations.md)
* [Artifacts Summary](artifacts.md)
* [Use Cases und Kontext](UseCases.md)
* [Interaktionen](Interaktionen.md)
* [FHIR-Artefakte](artifacts_isik.md)

## Resources

### CodeSystems

* [TestKatalog](CodeSystem-CodeSystemExample.md)
* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)

### ValueSets

* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiKLocationPhysicalType](ValueSet-ISiKLocationPhysicalType.md)
* [ISiKTerminCancelationReason](ValueSet-ISiKTerminCancelationReason.md)
* [ISiKTerminPriority](ValueSet-ISiKTerminPriority.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)
* [TestValueSet](ValueSet-ISiKValueSetExample.md)

### Resource Profiles

* [ISiKCodeSystem](StructureDefinition-ISiKCodeSystem.md)
* [ISiKKalender](StructureDefinition-ISiKKalender.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKMedizinischeBehandlungseinheit](StructureDefinition-ISiKMedizinischeBehandlungseinheit.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKTermin](StructureDefinition-ISiKTermin.md)
* [ISiKTerminblock](StructureDefinition-ISiKTerminblock.md)
* [ISiKValueSet](StructureDefinition-ISiKValueSet.md)

### Extensions

* [AppointmentReplaces](StructureDefinition-AppointmentReplaces.md)
* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)
* [ISiKTerminPriorityExtension](StructureDefinition-ISiKTerminPriorityExtension.md)
* [PlannedEndDate](StructureDefinition-PlannedEndDate.md)
* [PlannedStartDate](StructureDefinition-PlannedStartDate.md)
* [ScheduleName](StructureDefinition-ScheduleName.md)

### Appointments

* [ISiKTerminExample](Appointment-ISiKTerminExample.md)
* [ISiKTerminExampleExtendedICU](Appointment-ISiKTerminExampleExtendedICU.md)

### CapabilityStatements

* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)
* [ISiK CapabilityStatement Termin-Repository Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementTerminRepositoryAkteur-expanded.md)
* [ISiK CapabilityStatement Termin-Repository Akteur](CapabilityStatement-ISiKCapabilityStatementTerminRepositoryAkteur.md)
* [ISiK CapabilityStatement Termin-Repository Rolle](CapabilityStatement-ISiKCapabilityStatementTerminRepositoryRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementTerminologieRolle](CapabilityStatement-ISiKCapabilityStatementTerminologieRolle.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)

### HealthcareServices

* [Allgemeine Beratungsstelle der Fachabteilung 0100](HealthcareService-ISiKMedizinischeBehandlungseinheitExample.md)

### ImplementationGuides

* [ISiK Terminplanung Implementierungsleitfaden](index.md)

### OperationDefinitions

* [Book](OperationDefinition-ISiKAppointmentBookOperation.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [IsikPatientTemplate](Patient-IsikPatientTemplate.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)

### Schedules

* [ISiKKalenderExample](Schedule-ISiKKalenderExample.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)

### Slots

* [ISiKTerminblockExample](Slot-ISiKTerminblockExample.md)
