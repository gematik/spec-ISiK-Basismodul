# ISiKMedikationsVerabreichung - AMTS ISiK Implementierungsleitfaden v6.0.0-rc

AMTS ISiK Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ISiKMedikationsVerabreichung**

## Resource Profile: ISiKMedikationsVerabreichung 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKMedikationsVerabreichung | *Version*:6.0.0-rc |
| Active as of 2025-12-17 | *Computable Name*:ISiKMedikationsVerabreichung |

 
Dieses Profil ermöglicht die Abbildung der Verabreichung von Medikamenten für einen Patienten in ISiK Szenarien. Hinweis zur Auswahl des Profils: In Abgrenzung zu ISiKMedikationsInformation (MedicationStatement) wird mittels des vorliegenden Profils die Verabreichung eines Medikaments an einen Patienten mit einer Zeitpunkt-genauen Angabe abgebildet (.effectiveDateTime oder .effectivePeriod auf Sekundenebene gemäß der [FHIR-Core Vorgabe](https://hl7.org/fhir/R4/datatypes.html#dateTime)). D.h. die lediglich Datums-genaue Angabe ist im vorliegenden Profil nicht erlaubt. Das Profil ISiKMedikationsInformation (MedicationStatement) kann ebenfalls für die Abbildung der Verabreichung von Medikamenten für einen Patienten verwendet werden, wenn keine Zeitpunkt-genauen Angaben zur Verabreichung vorliegen, sondern lediglich Datums-genaue Angaben (einschließlich Granularität Jahr, Monat oder Tag). 
Begründung zur Profil- und Nutzungsdifferenzierung: Handelt es sich bei Erfassung um eine medizinische Verabreichungsdokumentation, dann ist ein genauer Zeitstempel zwingend. Die medizinische Verabreichungsdokumentation muss durch medizinisches Personal erfolgen. Angaben von Patienten und Angehörigen sind grundsätzlich keine medizinische Verabreichungsdokumentation und daher als MedicationStament zu erfassen([‘report that such a sequence (or at least a part of it) did take place’](https://hl7.org/fhir/R4/medicationstatement.html)). 
**Hinweis zur Pausierung einer Medikation (Best-Practice):** 
Für die Abbildung der Pausierung einer Medikation wird empfohlen, **mehrere `MedicationAdministration`-Ressourcen** zu verwenden, anstatt eine bestehende zu überschreiben. Dies bringt folgende Vorteile: 
* **Korrekte Statusabbildung:**
 Das `status`-Feld muss stets aktuell gepflegt werden, um den momentanen Zustand der Medikation systemweit sichtbar und durchsuchbar zu halten.
* **Effiziente Abfragen über REST API:**
 In Kombination mit `effective[x]` ermöglicht das `status`-Feld die gezielte Abfrage aller aktuell gültigen Medikationseinträge über die REST API.
 Wird stattdessen nur das `dosage`-Element verändert, ist keine zuverlässige Filterung möglich – alle `MedicationAdministrations` müssten abgerufen und manuell analysiert werden.
* **Erhalt von Verlaufsinformationen:**
 Wenn z. B. auch ein `statusReason` (z. B. „pausiert wegen Nebenwirkungen“) dokumentiert wird, ginge diese Information bei einem Update der bestehenden Ressource verloren, sobald die Medikation fortgesetzt wird.
 Durch neue `MedicationAdministration`-Einträge bleibt die Verlaufshistorie erhalten.
 **(Dieser Anwendungsfall ist aktuell nicht gefordert, aber zukünftig denkbar.)**
 

**Usages:**

* Examples for this Profile: [MedicationAdministration/ExampleISiKMedikationsVerabreichung](MedicationAdministration-ExampleISiKMedikationsVerabreichung.md), [MedicationAdministration/ExampleISiKMedikationsVerabreichung2](MedicationAdministration-ExampleISiKMedikationsVerabreichung2.md), [MedicationAdministration/ExampleISiKMedikationsVerabreichung3](MedicationAdministration-ExampleISiKMedikationsVerabreichung3.md) and [MedicationAdministration/ExampleISiKMedikationsVerabreichung4](MedicationAdministration-ExampleISiKMedikationsVerabreichung4.md)
* CapabilityStatements using this Profile: [ISiK CapabilityStatement AMTS Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementAMTSAkteur-expanded.md) and [ISiK CapabilityStatement Medikationsverabreichung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungRolle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/amts|current/StructureDefinition/ISiKMedikationsVerabreichung)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ISiKMedikationsVerabreichung.csv), [Excel](StructureDefinition-ISiKMedikationsVerabreichung.xlsx), [Schematron](StructureDefinition-ISiKMedikationsVerabreichung.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKMedikationsVerabreichung",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKMedikationsVerabreichung",
  "version" : "6.0.0-rc",
  "name" : "ISiKMedikationsVerabreichung",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-17",
  "publisher" : "gematik GmbH",
  "contact" : [
    {
      "name" : "gematik GmbH",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://gematik.de"
        }
      ]
    }
  ],
  "description" : "Dieses Profil ermöglicht die Abbildung der Verabreichung von Medikamenten für einen Patienten in ISiK Szenarien. \nHinweis zur Auswahl des Profils: In Abgrenzung zu ISiKMedikationsInformation (MedicationStatement) wird mittels des vorliegenden Profils die Verabreichung eines Medikaments an einen Patienten mit einer Zeitpunkt-genauen Angabe abgebildet (.effectiveDateTime oder .effectivePeriod auf Sekundenebene gemäß der [FHIR-Core Vorgabe](https://hl7.org/fhir/R4/datatypes.html#dateTime)). D.h. die lediglich Datums-genaue Angabe  ist im vorliegenden Profil nicht erlaubt. \nDas Profil ISiKMedikationsInformation (MedicationStatement) kann ebenfalls für  die Abbildung der Verabreichung von Medikamenten für einen Patienten verwendet werden, wenn keine Zeitpunkt-genauen Angaben zur Verabreichung vorliegen, sondern lediglich Datums-genaue Angaben (einschließlich Granularität Jahr, Monat oder Tag).\n\nBegründung zur Profil- und Nutzungsdifferenzierung:\nHandelt es sich bei Erfassung um eine medizinische Verabreichungsdokumentation, dann ist ein genauer Zeitstempel zwingend. Die medizinische Verabreichungsdokumentation muss durch medizinisches Personal erfolgen. Angaben von Patienten und Angehörigen sind grundsätzlich keine medizinische Verabreichungsdokumentation und daher als MedicationStament zu erfassen(['report that such a sequence (or at least a part of it) did take place'](https://hl7.org/fhir/R4/medicationstatement.html)). \n\n**Hinweis zur Pausierung einer Medikation (Best-Practice):**\n\nFür die Abbildung der Pausierung einer Medikation wird empfohlen, **mehrere `MedicationAdministration`-Ressourcen** zu verwenden, anstatt eine bestehende zu überschreiben. Dies bringt folgende Vorteile:\n\n- **Korrekte Statusabbildung:**  \n  Das `status`-Feld muss stets aktuell gepflegt werden, um den momentanen Zustand der Medikation systemweit sichtbar und durchsuchbar zu halten.\n\n- **Effiziente Abfragen über REST API:**  \n  In Kombination mit `effective[x]` ermöglicht das `status`-Feld die gezielte Abfrage aller aktuell gültigen Medikationseinträge über die REST API.  \n  Wird stattdessen nur das `dosage`-Element verändert, ist keine zuverlässige Filterung möglich – alle `MedicationAdministrations` müssten abgerufen und manuell analysiert werden.\n\n- **Erhalt von Verlaufsinformationen:**  \n  Wenn z. B. auch ein `statusReason` (z. B. „pausiert wegen Nebenwirkungen“) dokumentiert wird, ginge diese Information bei einem Update der bestehenden Ressource verloren, sobald die Medikation fortgesetzt wird.  \n  Durch neue `MedicationAdministration`-Einträge bleibt die Verlaufshistorie erhalten.  \n  *(Dieser Anwendungsfall ist aktuell nicht gefordert, aber zukünftig denkbar.)*\n",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    },
    {
      "identity" : "w3c.prov",
      "uri" : "http://www.w3.org/ns/prov",
      "name" : "W3C PROV"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "MedicationAdministration",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/MedicationAdministration",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "MedicationAdministration",
        "path" : "MedicationAdministration"
      },
      {
        "id" : "MedicationAdministration.id",
        "path" : "MedicationAdministration.id",
        "short" : "serverseitige, interne ID des Datensatzes",
        "comment" : "**bedingtes Pflichtfeld/bedingtes MS:** Alle von einem Server bereitgestellten Ressourcen MÜSSEN über eine `id` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `id`verfügen. ",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.meta.versionId",
        "path" : "MedicationAdministration.meta.versionId",
        "short" : "Eindeutiger Name der serverseitigen Version des Datensatzes",
        "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über eine `versionID` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `versionID`verfügen. "
      },
      {
        "id" : "MedicationAdministration.meta.lastUpdated",
        "path" : "MedicationAdministration.meta.lastUpdated",
        "short" : "Zeitpunkt der letzten Änderung",
        "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über ein `lastUpdate` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über ein `lastUpdate`verfügen. "
      },
      {
        "id" : "MedicationAdministration.status",
        "path" : "MedicationAdministration.status",
        "short" : "Status der Verabreichungsinformation",
        "comment" : "Begründung des Must-Support: Erforderliche Angabe im FHIR-Standard",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.medication[x]",
        "path" : "MedicationAdministration.medication[x]",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "type",
              "path" : "$this"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        }
      },
      {
        "id" : "MedicationAdministration.medication[x]:medicationCodeableConcept",
        "path" : "MedicationAdministration.medication[x]",
        "sliceName" : "medicationCodeableConcept",
        "short" : "Medikament in codierter Form oder ggf. als Freitext",
        "comment" : "Begründung des Must-Support: Basisinformation\n\n  Hinweis: kann verwendet werden, wenn keine detaillierten Informationen zum Medikament (z.B. Rezepturen) existieren.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "CodeableConcept"
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.medication[x]:medicationCodeableConcept.coding",
        "path" : "MedicationAdministration.medication[x].coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.medication[x]:medicationCodeableConcept.coding:PZN",
        "path" : "MedicationAdministration.medication[x].coding",
        "sliceName" : "PZN",
        "comment" : "Mehrfachcodierung ist zulässig, da für ein abstraktes Medikament auch mehrere PZN-Codes existieren können, z. B. existieren für Aspirin 3 verschiedene Packungsgrößen.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Coding",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/ISiKPZNCoding"
            ]
          }
        ],
        "patternCoding" : {
          "system" : "http://fhir.de/CodeSystem/ifa/pzn"
        },
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.medication[x]:medicationCodeableConcept.coding:ATC-DE",
        "path" : "MedicationAdministration.medication[x].coding",
        "sliceName" : "ATC-DE",
        "comment" : "Mehrfachcodierung ist zulässig, da für ein abstraktes Medikament auch mehrere ATC-Codes existieren können, z. B. existieren für Aspirin 4 verschiedene Codes, je nachdem wofür das Medikament angewendet wird.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Coding",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/ISiKATCCoding"
            ]
          }
        ],
        "patternCoding" : {
          "system" : "http://fhir.de/CodeSystem/bfarm/atc"
        },
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.medication[x]:medicationCodeableConcept.coding:SCT",
        "path" : "MedicationAdministration.medication[x].coding",
        "sliceName" : "SCT",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Coding",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/ISiKSnomedCTCoding"
            ]
          }
        ],
        "patternCoding" : {
          "system" : "http://snomed.info/sct"
        },
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.medication[x]:medicationReference",
        "path" : "MedicationAdministration.medication[x]",
        "sliceName" : "medicationReference",
        "short" : "Referenz auf das Medikament (Medication-Ressource)",
        "comment" : "Begründung des Must-Support: Basisinformation\n\n  Hinweis: wird verwendet, wenn detaillierte Informationen zum Medikament vorliegen",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Medication"]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.medication[x]:medicationReference.reference",
        "path" : "MedicationAdministration.medication[x].reference",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.subject",
        "path" : "MedicationAdministration.subject",
        "short" : "Referenz auf den Patienten",
        "comment" : "Begründung des Must-Support: Basisinformation",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.subject.reference",
        "path" : "MedicationAdministration.subject.reference",
        "short" : "Patienten-Link",
        "comment" : "**Begründung MS:** Die Verlinkung auf eine Patienten-Ressource dient der technischen Zuordnung der Dokumentation zu einem Patienten und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.\nIm ISik Kontext MUSS die referenzierte Ressource konform zu [ISiKPatient](https://gematik.de/fhir/isik/StructureDefinition/ISiKPatient) sein.\nJenseits von ISiK KÖNNEN weitere Instanzen mit anderen Profilen referenziert werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.context",
        "path" : "MedicationAdministration.context",
        "short" : "Referenz auf den Abteilungskontakt",
        "comment" : "Begründung des Must-Support: Basisinformation im Krankenhaus-Kontext",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.context.reference",
        "path" : "MedicationAdministration.context.reference",
        "comment" : "**Begründung MS:** Die Verlinkung auf eine Encounter-Ressource dient der technischen Zuordnung der Dokumentation zu einem Aufenthalt und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.\nIm ISik Kontext MUSS die referenzierte Ressource konform zu [ISiKKontaktGesundheitseinrichtung](https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung) sein.\nJenseits von ISiK KÖNNEN weitere Instanzen mit anderen Profilen referenziert werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.effective[x]",
        "path" : "MedicationAdministration.effective[x]",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "type",
              "path" : "$this"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        }
      },
      {
        "id" : "MedicationAdministration.effective[x]:effectiveDateTime",
        "path" : "MedicationAdministration.effective[x]",
        "sliceName" : "effectiveDateTime",
        "short" : "Zeitpunkt der Verabreichung",
        "comment" : "Begründung des Must-Support: Basisinformation\n  \n  Festlegung zur Nutzung: eine Zeitpunkt-genaue Angabe (.effectiveDateTime oder .effectivePeriod auf Sekundenebene gemäß der [FHIR-Core Vorgabe](https://hl7.org/fhir/R4/datatypes.html#dateTime)) MUSS hier seitens eines bestätigungsrelevanten Systems unterstützt werden.\n\n  Für grobgranularere Angaben (z.B. nur Jahr, Monat oder Tag) SOLL das Profil ISiKMedikationsInformation (MedicationStatement) verwendet werden.\n  ",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "dateTime"
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.effective[x]:effectivePeriod",
        "path" : "MedicationAdministration.effective[x]",
        "sliceName" : "effectivePeriod",
        "short" : "Zeitraum der Verabreichung",
        "comment" : "Begründung des Must-Support: Basisinformation\n  \n  Festlegung zur Nutzung: eine Zeitpunkt-genaue Angabe (.effectiveDateTime oder .effectivePeriod auf Sekundenebene gemäß der [FHIR-Core Vorgabe](https://hl7.org/fhir/R4/datatypes.html#dateTime)) MUSS hier seitens eines bestätigungsrelevanten Systems unterstützt werden.\n  Für grobgranularere Angaben (z.B. nur Jahr, Monat oder Tag) SOLL das Profil ISiKMedikationsInformation (MedicationStatement) verwendet werden.\n  ",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.effective[x]:effectivePeriod.start",
        "path" : "MedicationAdministration.effective[x].start",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.effective[x]:effectivePeriod.end",
        "path" : "MedicationAdministration.effective[x].end",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.performer",
        "path" : "MedicationAdministration.performer",
        "short" : "Durchführende Person(en) der Verabreichung",
        "comment" : "Begründung des Must-Support: Nachvollziehbarkeit",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.performer.actor",
        "path" : "MedicationAdministration.performer.actor",
        "short" : "Referenz auf die verabreichende Person",
        "comment" : "Begründung des Must-Support: Nachvollziehbarkeit",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.performer.actor.reference",
        "path" : "MedicationAdministration.performer.actor.reference",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.reasonCode",
        "path" : "MedicationAdministration.reasonCode",
        "short" : "Grund der Medikation (Referenz)",
        "comment" : "  Festlegung zum MS: Die Elemente .reasonCode und .reasonReference MÜSSEN nach OR-Logik in der Ausgabe verwendet werden, d.h. nur eines MUSS geliefert werden können. Weiterhin MÜSSEN beide Elemente interpretiert werden können.",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.reasonReference",
        "path" : "MedicationAdministration.reasonReference",
        "short" : "Grund der Medikation (Referenz)",
        "comment" : "  Festlegung zum MS: Die Elemente .reasonCode und .reasonReference MÜSSEN nach OR-Logik in der Ausgabe verwendet werden, d.h. nur eines MUSS geliefert werden können. Weiterhin MÜSSEN beide Elemente interpretiert werden können.",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.reasonReference.reference",
        "path" : "MedicationAdministration.reasonReference.reference",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.request",
        "path" : "MedicationAdministration.request",
        "short" : "Referenz auf die Verordnung",
        "comment" : "**Einschränkung der übergreifenden MS-Definition:**\n  Verfügt ein bestätigungsrelevantes System nicht über die Möglichkeit zur Abbildung der zugrunde liegenden Verordnung einer Verabreichung, \n  so MUSS dieses System die Information NICHT abbilden.\n\n  Motivation zum eingeschränkten MS: Die referenzierte Verordnung (`MedicationRequest`) bildet in der Regel die Grundlage einer Verabreichung (`MedicationAdministration`). \n  Aus fachlicher Sicht ist die Verknüpfung beider Ressourcen wesentlich, da sie die Nachvollziehbarkeit der therapeutischen Maßnahme unterstützt. \n  Allerdings existieren in der Versorgungspraxis auch Systeme, die keine strukturierte Erfassung oder Referenzierung einer zugrundeliegenden Verordnung vorsehen. \n  Daher wird `MedicationAdministration.request` in ISiK als eingeschränktes Must Support definiert, um eine einheitliche  Implementierung zu fördern.",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.note",
        "path" : "MedicationAdministration.note",
        "short" : "Zusätzliche Anmerkungen zur Medikation",
        "comment" : "Begründung des Must-Support: Fachlich relevante Zusatzinformationen",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.note.text",
        "path" : "MedicationAdministration.note.text",
        "short" : "Freitext-Notiz",
        "comment" : "Begründung des Must-Support: Angabe zusätzlicher Informationen kann fachlich relevant sein",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage",
        "path" : "MedicationAdministration.dosage",
        "short" : "Dosierungsangaben",
        "comment" : "Begründung des Must-Support: Basisinformation. Zur vollständig strukturierten Abbildung der zahlreichen Möglichkeiten sind die hier mit Must-Support gekennzeichneten Unterelemente erforderlich gemäß Konsens der ISiK AG Medikation",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.text",
        "path" : "MedicationAdministration.dosage.text",
        "short" : "Freitext-Dosierungsangabe",
        "comment" : "Festlegung zum Must-Support: Die Verarbeitung MUSS unterstützt werden, indem empfangende Systeme  die Freitext-Dosierungsinformation entweder direkt in der Textform persistieren, ODER die Informationen in eine alternative (strukturierte) Form umwandeln (ggf. unter Einwirkung geeigneter Nutzer). Im letzteren Fall KANN auf eine Persistierung in Textform verzichtet werden, um Inkonsistenzen zu vermeiden.\n        \n    Ein System KANN jedoch strukturierte Dosierungsinformationen in Freitext-Dosierungsinformationen umwandeln, um sie in einem Dokument oder einer Benutzeroberfläche anzuzeigen - dabei ist auf Konsistenzwahrung zu allen strukturierten Elementen zu achten.\n    \n    Hinweis: Diese Festlegung folgt und spezifiziert folgende MS-Festlegung aus dem [ISiK Basismodul](https://simplifier.net/guide/isik-basis-stufe-5/Einfuehrung/Festlegungen/UebergreifendeFestlegungen_Must-Support-Flags): 'Systeme KÖNNEN es darüber hinaus ermöglichen, dass die jeweiligen Informationen vom Anwender ergänzt oder editiert werden.' \n    \n    Zum Beispiel kann die textuelle Information '1L Infusion mit Rate 50ml/h' in eine entsprechende, strukturierte Form überführt werden - d.h. in die Angabe von 'dose' und 'rateQuantity'.",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.site",
        "path" : "MedicationAdministration.dosage.site",
        "short" : "Körperstelle der Verabreichung",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.site.coding",
        "path" : "MedicationAdministration.dosage.site.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.site.coding:SNOMED-CT",
        "path" : "MedicationAdministration.dosage.site.coding",
        "sliceName" : "SNOMED-CT",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Coding",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/ISiKSnomedCTCoding"
            ]
          }
        ],
        "patternCoding" : {
          "system" : "http://snomed.info/sct"
        },
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.site.text",
        "path" : "MedicationAdministration.dosage.site.text",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.route",
        "path" : "MedicationAdministration.dosage.route",
        "short" : "Route",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.route.coding",
        "path" : "MedicationAdministration.dosage.route.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.route.coding:EDQM",
        "path" : "MedicationAdministration.dosage.route.coding",
        "sliceName" : "EDQM",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Coding",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/ISiKCoding"
            ]
          }
        ],
        "patternCoding" : {
          "system" : "http://standardterms.edqm.eu"
        },
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://hl7.org/fhir/uv/ips/ValueSet/medicine-route-of-administration"
        }
      },
      {
        "id" : "MedicationAdministration.dosage.route.coding:SNOMED-CT",
        "path" : "MedicationAdministration.dosage.route.coding",
        "sliceName" : "SNOMED-CT",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Coding",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/ISiKSnomedCTCoding"
            ]
          }
        ],
        "patternCoding" : {
          "system" : "http://snomed.info/sct"
        },
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://gematik.de/fhir/isik/ValueSet/SctRouteOfAdministration"
        }
      },
      {
        "id" : "MedicationAdministration.dosage.route.text",
        "path" : "MedicationAdministration.dosage.route.text",
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.dose",
        "path" : "MedicationAdministration.dosage.dose",
        "short" : "verabreichte Dosis",
        "type" : [
          {
            "code" : "Quantity",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/MedicationQuantity"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.rate[x]",
        "path" : "MedicationAdministration.dosage.rate[x]",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "type",
              "path" : "$this"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        }
      },
      {
        "id" : "MedicationAdministration.dosage.rate[x]:rateRatio",
        "path" : "MedicationAdministration.dosage.rate[x]",
        "sliceName" : "rateRatio",
        "short" : "Verabreichungs-Rate (Verhältnis)",
        "comment" : "Das Must-Support-Flag auf rateRatio bzw. rateQuantity bedeutet, dass produzierende Systeme zur Kodierung der Ratenangaben nach eigenem Ermessen entweder den Datentyp Ratio oder Quantity verwenden können. Beim Empfang und Verarbeitung der eingehenden Daten müssen dagegen beide Datentypen interpretiert werden können.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Ratio"
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.rate[x]:rateRatio.numerator",
        "path" : "MedicationAdministration.dosage.rate[x].numerator",
        "min" : 1,
        "type" : [
          {
            "code" : "Quantity",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/MedicationQuantity"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.rate[x]:rateRatio.denominator",
        "path" : "MedicationAdministration.dosage.rate[x].denominator",
        "min" : 1,
        "type" : [
          {
            "code" : "Quantity",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/MedicationQuantity"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "MedicationAdministration.dosage.rate[x]:rateQuantity",
        "path" : "MedicationAdministration.dosage.rate[x]",
        "sliceName" : "rateQuantity",
        "short" : "Verabreichungs-Rate",
        "comment" : "Das Must-Support-Flag auf rateRatio bzw. rateQuantity bedeutet, dass produzierende Systeme zur Kodierung der Ratenangaben nach eigenem Ermessen entweder den Datentyp Ratio oder Quantity verwenden können. Beim Empfang und Verarbeitung der eingehenden Daten müssen dagegen beide Datentypen interpretiert werden können.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Quantity",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/MedicationQuantity"
            ]
          }
        ],
        "mustSupport" : true
      }
    ]
  }
}

```
