# example.test.ig#0.0.1: Test Implementation Guide

## Pages

* [Home](index.md)
* [Festlegungen](Festlegungen.md)
* [Architekturoptionen](Architekturoptionen.md)
* [Informationsmodell](Informationsmodell.md)
* [Kompatibilität](Kompatibilitaet.md)
* [Capability Statements](capabilitystatements.md)
* [Profile](profiles.md)
* [UseCases](UseCases.md)
* [Interaktionen](Interaktionen.md)
* [Operation $book](Operations.md)
* [FHIR-Artefakte](artifacts.md)
* [Prozesse](Prozesse.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Terminology](terminology.md)
* [Akteure](Akteure.md)
* [Release Notes](ReleaseNotes.md)

## Resources

### CodeSystems

* [TestKatalog](CodeSystem-CodeSystemExample.md)

### ValueSets

* [ISiKLocationPhysicalType](ValueSet-ISiKLocationPhysicalType.md)
* [ISiKTerminCancelationReason](ValueSet-ISiKTerminCancelationReason.md)
* [TestValueSet](ValueSet-ISiKValueSetExample.md)

### Resource Profiles

* [ISiKCodeSystem](StructureDefinition-ISiKCodeSystem.md)
* [ISiKKalender](StructureDefinition-ISiKKalender.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKMedizinischeBehandlungseinheit](StructureDefinition-ISiKMedizinischeBehandlungseinheit.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKTermin](StructureDefinition-ISiKTermin.md)
* [ISiKTerminblock](StructureDefinition-ISiKTerminblock.md)
* [ISiKValueSet](StructureDefinition-ISiKValueSet.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)

### Appointments

* [ISiKTerminExample](Appointment-ISiKTerminExample.md)
* [ISiKTerminExampleExtendedICU](Appointment-ISiKTerminExampleExtendedICU.md)

### CapabilityStatements

* [CapabilityStatement für Rolle &quot;StammdatenRolle&quot;](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)
* [ISiK CapabilityStatement Termin-Repository Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementTerminRepositoryAkteur.md)
* [ISiK CapabilityStatement Termin-Repository Akteur](CapabilityStatement-ISiKCapabilityStatementTerminRepositoryAkteur.md)
* [ISiK CapabilityStatement Termin-Repository Rolle](CapabilityStatement-ISiKCapabilityStatementTerminRepositoryRolle.md)
* [CapabilityStatement für Rolle &quot;ISiKCapabilityStatementTerminologieRolle&quot;](CapabilityStatement-ISiKCapabilityStatementTerminologieRolle.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)

### HealthcareServices

* [Allgemeine Beratungsstelle der Fachabteilung 0100](HealthcareService-ISiKMedizinischeBehandlungseinheitExample.md)

### ImplementationGuides

* [Test Implementation Guide](index.md)

### OperationDefinitions

* [Book](OperationDefinition-ISiKAppointmentBookOperation.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)

### Schedules

* [ISiKKalenderExample](Schedule-ISiKKalenderExample.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)

### Slots

* [ISiKTerminblockExample](Slot-ISiKTerminblockExample.md)
