# example.test.ig#0.0.1: Test Implementation Guide

## Pages

* [Home](index.md)
* [Festlegungen](festlegungen.md)
* [Release Notes](releasenotes.md)
* [Capability Statements](capabilitystatements.md)
* [Profile](profiles.md)
* [Weitere Use Cases](UseCases.md)
* [Fallzusammenführung](Fallzusammenfuehrung.md)
* [FHIR-Artefakte](artifacts.md)
* [Patientenzusammenführung](Patientenzusammenfuehrung.md)
* [Terminology](terminology.md)
* [Akteure](Akteure.md)
* [Funktionen und Interaktionen](FunktionenInteraktionen.md)

## Resources

### CodeSystems

* [ISiK-SubscriptionTopic](CodeSystem-ISiKSubscriptionTopic.md)
* [SubscriptionNotificationType](CodeSystem-subscription-notification-type.md)

### ValueSets

* [FhirMimeTypeVS](ValueSet-FhirMimeTypeVS.md)
* [ISiKSubscriptionTopic ValueSet](ValueSet-ISiKSubscriptionTopicVS.md)
* [SubscriptionNotificationType](ValueSet-subscription-notification-type.md)

### Resource Profiles

* [R4 Topic-Based Subscription Notification Bundle](StructureDefinition-BackportSubscriptionNotificationR4Fixed.md)
* [R4 Backported R5 SubscriptionStatus](StructureDefinition-BackportSubscriptionStatusR4Fixed.md)
* [ISiK Subscription](StructureDefinition-ISiKSubscription.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)

### CapabilityStatements

* [CapabilityStatement für Rolle &quot;Subscription&quot;](CapabilityStatement-ISiKCapabilityStatementSubscriptionRolle.md)
* [Akteur &quot;ISiKCapabilityStatementSubscriptionServerAkteur&quot; (Expanded)](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.md)
* [Akteur &quot;ISiKCapabilityStatementSubscriptionServerAkteur&quot;](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.md)

### ImplementationGuides

* [Test Implementation Guide](index.md)

### Subscriptions

* [PatientMergeSubscriptionExample](Subscription-PatientMergeSubscriptionExample.md)
