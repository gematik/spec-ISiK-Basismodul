# ISiK CapabilityStatement Imports Expectation - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiK CapabilityStatement Imports Expectation**

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation-definitions.md) 
*  [Mappings](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation-mappings.md) 
*  [XML](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.profile.xml.md) 
*  [JSON](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.profile.json.md) 
*  [TTL](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.profile.ttl.md) 

## Extension: ISiK CapabilityStatement Imports Expectation 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ExtensionISiKCapabilityStatementImportsExpectation | *Version*:0.0.1 |
| Active as of 2025-06-26 | *Computable Name*:ExtensionISiKCapabilityStatementImportsExpectation |

Defines the level of expectation associated with a given system capability. See the capabilitystatement-prohibited modifier extension to set expectations to **not** support a feature.

**Context of Use**

This extension may be used on the following element(s):

* Element ID CapabilityStatement.imports

**Usage info**

**Usages:**

* This Extension is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.test.ig|current/StructureDefinition/ExtensionISiKCapabilityStatementImportsExpectation)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Text Summary](#tabs-summ) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type code: Defines the level of expectation associated with a given system capability. See the capabilitystatement-prohibited modifier extension to set expectations to **not** support a feature.

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type code: Defines the level of expectation associated with a given system capability. See the capabilitystatement-prohibited modifier extension to set expectations to **not** support a feature.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

 

Other representations of profile: [CSV](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.csv), [Excel](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.xlsx), [Schematron](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

