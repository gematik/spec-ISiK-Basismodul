# ISiK-SubscriptionTopic - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiK-SubscriptionTopic**

*  [Narrative Content](#) 
*  [XML](CodeSystem-ISiKSubscriptionTopic.xml.md) 
*  [JSON](CodeSystem-ISiKSubscriptionTopic.json.md) 
*  [TTL](CodeSystem-ISiKSubscriptionTopic.ttl.md) 

## CodeSystem: ISiK-SubscriptionTopic 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/CodeSystem/ISiKSubscriptionTopic | *Version*:0.0.1 |
| Active as of 2025-06-26 | *Computable Name*:ISiKSubscriptionTopic |

 
Liste der aller SubscriptionTopics, die in ISiK verwendet werden können. Neben den merge-SubscriptionTopics sind auch die SubscriptionTopics für Updates der Ressourcen enthalten, die in ISiK verwendet werden können. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ISiKSubscriptionTopicVS](ValueSet-ISiKSubscriptionTopicVS.md)

This code system `https://gematik.de/fhir/isik/CodeSystem/ISiKSubscriptionTopic` defines the following codes:

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

