# FhirMimeTypeVS - JSON Representation - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **FhirMimeTypeVS**

*  [Narrative Content](ValueSet-FhirMimeTypeVS.md) 
*  [XML](ValueSet-FhirMimeTypeVS.xml.md) 
*  [JSON](#) 
*  [TTL](ValueSet-FhirMimeTypeVS.ttl.md) 

## : FhirMimeTypeVS - JSON Representation

| |
| :--- |
| Active as of 2025-06-26 |

[Raw json](ValueSet-FhirMimeTypeVS.json) | [Download](ValueSet-FhirMimeTypeVS.json)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

