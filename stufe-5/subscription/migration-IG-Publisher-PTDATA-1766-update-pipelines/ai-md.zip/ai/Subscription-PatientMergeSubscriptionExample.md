#  - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

*  [Narrative Content](#) 
*  [XML](Subscription-PatientMergeSubscriptionExample.xml.md) 
*  [JSON](Subscription-PatientMergeSubscriptionExample.json.md) 
*  [TTL](Subscription-PatientMergeSubscriptionExample.ttl.md) 

## Subscription: 

Profile: [ISiK Subscription](StructureDefinition-ISiKSubscription.md)

**status**: Requested

**reason**: Patient merge subscription

**criteria**: https://gematik.de/fhir/isik/SubscriptionTopic/patient-merge

### Channels

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| - | **Type** | **Endpoint** | **Payload** | **Header** |
| * | Rest Hook | [http://localhost:8081/fhir/Bundle](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://localhost:8081/fhir/Bundle) | application/fhir+json | Authorization: Bearer xxxxxxxxxx |

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

