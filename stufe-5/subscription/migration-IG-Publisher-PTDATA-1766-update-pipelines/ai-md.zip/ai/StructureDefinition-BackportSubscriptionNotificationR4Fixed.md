# R4 Topic-Based Subscription Notification Bundle - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **R4 Topic-Based Subscription Notification Bundle**

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BackportSubscriptionNotificationR4Fixed-definitions.md) 
*  [Mappings](StructureDefinition-BackportSubscriptionNotificationR4Fixed-mappings.md) 
*  [XML](StructureDefinition-BackportSubscriptionNotificationR4Fixed.profile.xml.md) 
*  [JSON](StructureDefinition-BackportSubscriptionNotificationR4Fixed.profile.json.md) 
*  [TTL](StructureDefinition-BackportSubscriptionNotificationR4Fixed.profile.ttl.md) 

## Resource Profile: R4 Topic-Based Subscription Notification Bundle 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/BackportSubscriptionNotificationR4Fixed | *Version*:0.0.1 |
| Active as of 2023-01-11 | *Computable Name*:BackportSubscriptionNotificationR4Fixed |

 
Profil auf der FHIR-R4-Resource Bundle, um R5-ähnliche, themenbasierte Subscription-Benachrichtigungen in FHIR R4 zu ermöglichen. 
Dieses Profil ist funktional identisch mit`http://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition/backport-subscription-notification-r4`.
Die Version 1.1.0 des offiziellen Profils enthält jedoch technische Fehler. Daher wurde dieses Profil lokal als temporärer Workaround nachgebildet. Es wird durch das offizielle`backport-subscription-notification-r4`Profil ersetzt, sobald eine korrigierte Version veröffentlicht wurde. 

**Usages:**

* CapabilityStatements using this Profile: [Akteur "ISiKCapabilityStatementSubscriptionServerAkteur" (Expanded)](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.md)
* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.test.ig|current/StructureDefinition/BackportSubscriptionNotificationR4Fixed)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 3 elements
 Must-Support: 3 elements

**Structures**

This structure refers to these other structures:

* [R4 Backported R5 SubscriptionStatus(https://gematik.de/fhir/isik/StructureDefinition/BackportSubscriptionStatusR4Fixed)](StructureDefinition-BackportSubscriptionStatusR4Fixed.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 3 elements
 Must-Support: 3 elements

**Structures**

This structure refers to these other structures:

* [R4 Backported R5 SubscriptionStatus(https://gematik.de/fhir/isik/StructureDefinition/BackportSubscriptionStatusR4Fixed)](StructureDefinition-BackportSubscriptionStatusR4Fixed.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 

Other representations of profile: [CSV](StructureDefinition-BackportSubscriptionNotificationR4Fixed.csv), [Excel](StructureDefinition-BackportSubscriptionNotificationR4Fixed.xlsx), [Schematron](StructureDefinition-BackportSubscriptionNotificationR4Fixed.sch) 

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

