# Akteure - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* **Akteure**

## Akteure

##

### Subscription Server

Unter einem Subscription Server ist in diesem Modul ein Anwendungssystem zu verstehen, das folgende Interkation implementiert:

* Registrierung einer Subscription in der Rolle “Server”
* Benachrichtigung eines Clients über einen Subscription-Event in der Rolle “Server”

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

