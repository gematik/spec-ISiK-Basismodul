# Akteur "ISiKCapabilityStatementSubscriptionServerAkteur" - JSON Representation - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Akteur &quot;ISiKCapabilityStatementSubscriptionServerAkteur&quot;**

*  [Narrative Content](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.md) 
*  [XML](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.xml.md) 
*  [JSON](#) 
*  [TTL](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.ttl.md) 

## : Akteur "ISiKCapabilityStatementSubscriptionServerAkteur" - JSON Representation

| |
| :--- |
| Active as of 2025-06-26 |

[Raw json](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.json) | [Download](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.json)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

