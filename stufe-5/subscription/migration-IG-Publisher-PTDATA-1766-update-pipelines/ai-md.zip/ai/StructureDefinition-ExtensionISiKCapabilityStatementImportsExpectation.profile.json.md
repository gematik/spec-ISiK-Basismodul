# ISiK CapabilityStatement Imports Expectation - JSON Representation - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiK CapabilityStatement Imports Expectation**

*  [Content](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md) 
*  [Detailed Descriptions](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation-definitions.md) 
*  [Mappings](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation-mappings.md) 
*  [XML](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.profile.ttl.md) 

## Extension: ExtensionISiKCapabilityStatementImportsExpectation - JSON Profile

| |
| :--- |
| Active as of 2025-06-26 |

JSON representation of the ExtensionISiKCapabilityStatementImportsExpectation extension.

[Raw json](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.json) | [Download](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.json)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

