# Terminology - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* **Terminology**

## Terminology

# Terminologien

Diese Seite listet alle wesentlichen FHIR-Terminologien, die in diesem Implementation Guide definiert sind.

[ISiK SubscriptionTopic CodeSystem](CodeSystem-ISiKSubscriptionTopic.md)

[ISiK Subscription Notification CodeSystem](CodeSystem-subscription-notification-type.md)

TODO: hier ggf. die entsprechenden VS einfügen?!

[FhirMimeTypeVS](ValueSet-FhirMimeTypeVS.md)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

