# Capability Statements - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* **Capability Statements**

## Capability Statements

# CapabilityStatements

Diese Seite beschreibt die CapabilityStatements, die die erwarteten Fähigkeiten von FHIR-Servern für dieses Implementation Guide definieren.

## Überblick

CapabilityStatements dokumentieren die FHIR-Funktionalitäten, die ein Server implementieren muss, um mit diesem Implementation Guide konform zu sein.

[Akteur Capability Statement](CapabilityStatement-ISiKCapabilityStatementSubscriptionRolle.md)

[Rolle Subscription Capability Statement](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.md)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

