# SubscriptionNotificationType - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **SubscriptionNotificationType**

*  [Narrative Content](#) 
*  [XML](CodeSystem-subscription-notification-type.xml.md) 
*  [JSON](CodeSystem-subscription-notification-type.json.md) 
*  [TTL](CodeSystem-subscription-notification-type.ttl.md) 

## CodeSystem: SubscriptionNotificationType 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/subscription-notification-type | *Version*:0.0.1 | |
| *Standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 0 | *Computable Name*:SubscriptionNotificationTypeCS |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.1.1524 | | |

 
The type of notification represented by the status message. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [SubscriptionNotificationTypeVS](ValueSet-subscription-notification-type.md)

Last updated: 2022-05-28 13:47:40+1100

Profile: [Shareable CodeSystem](http://hl7.org/fhir/R4/shareablecodesystem.html)

This case-sensitive code system `http://hl7.org/fhir/subscription-notification-type` defines the following codes:

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

