# R4 Backported R5 SubscriptionStatus - TTL Representation - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **R4 Backported R5 SubscriptionStatus**

*  [Content](StructureDefinition-BackportSubscriptionStatusR4Fixed.md) 
*  [Detailed Descriptions](StructureDefinition-BackportSubscriptionStatusR4Fixed-definitions.md) 
*  [Mappings](StructureDefinition-BackportSubscriptionStatusR4Fixed-mappings.md) 
*  [XML](StructureDefinition-BackportSubscriptionStatusR4Fixed.profile.xml.md) 
*  [JSON](StructureDefinition-BackportSubscriptionStatusR4Fixed.profile.json.md) 
*  [TTL](#) 

## Resource Profile: BackportSubscriptionStatusR4Fixed - TTL Profile

| |
| :--- |
| Active as of 2023-01-11 |

TTL representation of the BackportSubscriptionStatusR4Fixed resource profile.

[Raw ttl](StructureDefinition-BackportSubscriptionStatusR4Fixed.ttl) | [Download](StructureDefinition-BackportSubscriptionStatusR4Fixed.ttl)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

