# ISiK Subscription - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiK Subscription**

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ISiKSubscription-definitions.md) 
*  [Mappings](StructureDefinition-ISiKSubscription-mappings.md) 
*  [XML](StructureDefinition-ISiKSubscription.profile.xml.md) 
*  [JSON](StructureDefinition-ISiKSubscription.profile.json.md) 
*  [TTL](StructureDefinition-ISiKSubscription.profile.ttl.md) 

## Resource Profile: ISiK Subscription 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKSubscription | *Version*:0.0.1 |
| Active as of 2025-06-26 | *Computable Name*:ISiKSubscription |

 
ISiK Subscription 

### Motivation

 
Subscription ist eine FHIR Ressource, um als Client-System Benachrichtigungen über Events auf dem FHIR Server anzufragen. Der Subscription Mechanismus in FHIR R4 ist nicht geeignet, um alle relevanten Events (hier im Speziellen das Mergen von Patienten) zu unterstützen. Daher basiert das ISiK Subscription-Profil auf dem[Subscriptions R5 Backport Profil von HL7](https://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html). 
Um als Subsystem über ein Subsription-Event informiert zu werden, KANN der FHIR Subscription Mechanismus gemäß des[Subscriptions R5 Backport IGs von HL7](https://hl7.org/fhir/uv/subscriptions-backport/STU1.1/index.html)genutzt werden. 

### Kompatibilität

 
Das Profil ISiKSubscription basiert auf dem[Backport-Subscription Profil](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-backport-subscription.html). Der[SubscriptionStatus](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-backport-subscription-status-r4.html), sowie das[Subscription Notification Bundle](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-backport-subscription-notification-r4.html)werden unverändert direkt aus dem[Subscriptions R5 Backport IG](https://hl7.org/fhir/uv/subscriptions-backport/index.html)genutzt. 
Hinweise zu Inkompatibilitäten können über die[Portalseite](https://service.gematik.de/servicedesk/customer/portal/16)gemeldet werden. 

**Usages:**

* Examples for this Profile: [Subscription/PatientMergeSubscriptionExample](Subscription-PatientMergeSubscriptionExample.md)
* CapabilityStatements using this Profile: [CapabilityStatement für Rolle "Subscription"](CapabilityStatement-ISiKCapabilityStatementSubscriptionRolle.md) and [Akteur "ISiKCapabilityStatementSubscriptionServerAkteur" (Expanded)](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.test.ig|current/StructureDefinition/ISiKSubscription)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [BackportSubscription](http://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [BackportSubscription](http://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html) 

**Summary**

Must-Support: 11 elements
 Prohibited: 1 element

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [BackportSubscription](http://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [BackportSubscription](http://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html) 

**Summary**

Must-Support: 11 elements
 Prohibited: 1 element

 

Other representations of profile: [CSV](StructureDefinition-ISiKSubscription.csv), [Excel](StructureDefinition-ISiKSubscription.xlsx), [Schematron](StructureDefinition-ISiKSubscription.sch) 

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

