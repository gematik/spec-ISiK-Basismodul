# R4 Backported R5 SubscriptionStatus - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **R4 Backported R5 SubscriptionStatus**

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BackportSubscriptionStatusR4Fixed-definitions.md) 
*  [Mappings](StructureDefinition-BackportSubscriptionStatusR4Fixed-mappings.md) 
*  [XML](StructureDefinition-BackportSubscriptionStatusR4Fixed.profile.xml.md) 
*  [JSON](StructureDefinition-BackportSubscriptionStatusR4Fixed.profile.json.md) 
*  [TTL](StructureDefinition-BackportSubscriptionStatusR4Fixed.profile.ttl.md) 

## Resource Profile: R4 Backported R5 SubscriptionStatus 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/BackportSubscriptionStatusR4Fixed | *Version*:0.0.1 |
| Active as of 2023-01-11 | *Computable Name*:BackportSubscriptionStatusR4Fixed |

 
Profil auf der FHIR-R4-Resource Parameters zur Unterstützung themenbasierter Subscription-Benachrichtigungen in R4. 
Dieses Profil ist funktional identisch mit`http://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition/backport-subscription-status-r4`.
Die Version 1.1.0 des offiziellen Profils weist jedoch technische Fehler auf. Daher wurde es hier als Workaround erneut implementiert. Diese lokale Definition wird durch das offizielle`backport-subscription-status-r4`Profil ersetzt, sobald eine korrigierte Version veröffentlicht wurde. 

**Usages:**

* Use this Profile: [R4 Topic-Based Subscription Notification Bundle](StructureDefinition-BackportSubscriptionNotificationR4Fixed.md)
* CapabilityStatements using this Profile: [Akteur "ISiKCapabilityStatementSubscriptionServerAkteur" (Expanded)](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.test.ig|current/StructureDefinition/BackportSubscriptionStatusR4Fixed)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

**Summary**

Mandatory: 6 elements(3 nested mandatory elements)
 Must-Support: 23 elements
 Fixed: 11 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter
* The element 1 is sliced based on the value of Parameters.parameter.part

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Parameters](http://hl7.org/fhir/R4/parameters.html) 

**Summary**

Mandatory: 6 elements(3 nested mandatory elements)
 Must-Support: 23 elements
 Fixed: 11 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Parameters.parameter
* The element 1 is sliced based on the value of Parameters.parameter.part

 

Other representations of profile: [CSV](StructureDefinition-BackportSubscriptionStatusR4Fixed.csv), [Excel](StructureDefinition-BackportSubscriptionStatusR4Fixed.xlsx), [Schematron](StructureDefinition-BackportSubscriptionStatusR4Fixed.sch) 

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

