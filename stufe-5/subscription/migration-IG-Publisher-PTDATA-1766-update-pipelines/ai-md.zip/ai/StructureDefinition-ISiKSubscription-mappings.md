# ISiK Subscription - Mappings - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiK Subscription**

*  [Content](StructureDefinition-ISiKSubscription.md) 
*  [Detailed Descriptions](StructureDefinition-ISiKSubscription-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-ISiKSubscription.profile.xml.md) 
*  [JSON](StructureDefinition-ISiKSubscription.profile.json.md) 
*  [TTL](StructureDefinition-ISiKSubscription.profile.ttl.md) 

## Resource Profile: ISiKSubscription - Mappings

| |
| :--- |
| Active as of 2025-06-26 |

Mappings for the ISiKSubscription resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

