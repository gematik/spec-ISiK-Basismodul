# ISiK CapabilityStatement Imports Expectation - XML Representation - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiK CapabilityStatement Imports Expectation**

*  [Content](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md) 
*  [Detailed Descriptions](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation-definitions.md) 
*  [Mappings](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.profile.json.md) 
*  [TTL](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.profile.ttl.md) 

## Extension: ExtensionISiKCapabilityStatementImportsExpectation - XML Profile

| |
| :--- |
| Active as of 2025-06-26 |

XML representation of the ExtensionISiKCapabilityStatementImportsExpectation extension.

[Raw xml](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.xml) | [Download](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.xml)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

