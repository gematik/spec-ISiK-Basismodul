# ISiK Subscription - Definitions - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiK Subscription**

*  [Content](StructureDefinition-ISiKSubscription.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-ISiKSubscription-mappings.md) 
*  [XML](StructureDefinition-ISiKSubscription.profile.xml.md) 
*  [JSON](StructureDefinition-ISiKSubscription.profile.json.md) 
*  [TTL](StructureDefinition-ISiKSubscription.profile.ttl.md) 

## Resource Profile: ISiKSubscription - Detailed Descriptions

| |
| :--- |
| Active as of 2025-06-26 |

Definitions for the ISiKSubscription resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

