# Funktionen und Interaktionen - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* **Funktionen und Interaktionen**

## Funktionen und Interaktionen

##

Es gelten die in Interaktionen und der Workflow aus dem [Subscription Backport IG](https://hl7.org/fhir/uv/subscriptions-backport/workflow.html#workflow-fhir-r4)

### Interaktionen

* Topic Discovery SOLL durch die [CapabilityStatementSubscriptionTopic-Extension](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-capabilitystatement-subscriptiontopic-canonical.html) supported werden.
* [HandShake](https://hl7.org/fhir/uv/subscriptions-backport/workflow.html#workflow-fhir-r4) MUSS unterstützt werden.
* Benachrichtigungen mittels [REST-Hook](https://hl7.org/fhir/uv/subscriptions-backport/channels.html#rest-hook-1) MÜSSEN unterstützt werden.

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

