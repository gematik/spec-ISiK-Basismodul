#  - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

*  [Narrative Content](CapabilityStatement-ISiKCapabilityStatementSubscriptionRolle.md) 
*  [XML](CapabilityStatement-ISiKCapabilityStatementSubscriptionRolle.xml.md) 
*  [JSON](CapabilityStatement-ISiKCapabilityStatementSubscriptionRolle.json.md) 
*  [TTL](CapabilityStatement-ISiKCapabilityStatementSubscriptionRolle.ttl.md) 

## : ISiKCapabilityStatementSubscriptionRolle - Change History

History of changes for ISiKCapabilityStatementSubscriptionRolle .

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

