# SubscriptionNotificationType - JSON Representation - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **SubscriptionNotificationType**

*  [Narrative Content](ValueSet-subscription-notification-type.md) 
*  [XML](ValueSet-subscription-notification-type.xml.md) 
*  [JSON](#) 
*  [TTL](ValueSet-subscription-notification-type.ttl.md) 

## : SubscriptionNotificationType - JSON Representation

| | |
| :--- | :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 0 |

[Raw json](ValueSet-subscription-notification-type.json) | [Download](ValueSet-subscription-notification-type.json)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

