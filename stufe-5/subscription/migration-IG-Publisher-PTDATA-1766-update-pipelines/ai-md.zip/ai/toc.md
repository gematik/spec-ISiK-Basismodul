# Table of Contents - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* **Table of Contents**

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home](index.md) |
| [2 Release Notes](releasenotes.md) |
| [3 Festlegungen](festlegungen.md) |
| [4 Patientenzusammenführung](Patientenzusammenfuehrung.md) |
| [5 Fallzusammenführung](Fallzusammenfuehrung.md) |
| [6 Weitere Use Cases](UseCases.md) |
| [7 Akteure](Akteure.md) |
| [8 Funktionen und Interaktionen](FunktionenInteraktionen.md) |
| [9 FHIR-Artefakte](artifacts.md) |
| [9.1 Akteur &quot;ISiKCapabilityStatementSubscriptionServerAkteur&quot; (Expanded)](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.md) |
| [9.2 R4 Topic-Based Subscription Notification Bundle](StructureDefinition-BackportSubscriptionNotificationR4Fixed.md) |
| [9.3 R4 Backported R5 SubscriptionStatus](StructureDefinition-BackportSubscriptionStatusR4Fixed.md) |
| [9.4 ISiK Subscription](StructureDefinition-ISiKSubscription.md) |
| [9.5 ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md) |
| [9.6 FhirMimeTypeVS](ValueSet-FhirMimeTypeVS.md) |
| [9.7 ISiKSubscriptionTopic ValueSet](ValueSet-ISiKSubscriptionTopicVS.md) |
| [9.8 SubscriptionNotificationType](ValueSet-subscription-notification-type.md) |
| [9.9 ISiK-SubscriptionTopic](CodeSystem-ISiKSubscriptionTopic.md) |
| [9.10 SubscriptionNotificationType](CodeSystem-subscription-notification-type.md) |
| [9.11](Subscription-PatientMergeSubscriptionExample.md) |
| [10 Profile](profiles.md) |
| [11 Terminology](terminology.md) |
| [12 Capability Statements](capabilitystatements.md) |

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

