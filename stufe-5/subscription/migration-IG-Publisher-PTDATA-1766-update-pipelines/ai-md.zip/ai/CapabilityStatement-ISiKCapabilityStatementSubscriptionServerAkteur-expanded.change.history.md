#  - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

*  [Narrative Content](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.md) 
*  [XML](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.xml.md) 
*  [JSON](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.json.md) 
*  [TTL](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.ttl.md) 

## : ISiK-CapabilityStatementSubscriptionServerAkteurExpanded - Change History

History of changes for ISiKCapabilityStatementSubscriptionServerAkteur-expanded .

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

