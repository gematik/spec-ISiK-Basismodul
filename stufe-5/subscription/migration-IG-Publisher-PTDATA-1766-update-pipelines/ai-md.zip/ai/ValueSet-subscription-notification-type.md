# SubscriptionNotificationType - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **SubscriptionNotificationType**

*  [Narrative Content](#) 
*  [XML](ValueSet-subscription-notification-type.xml.md) 
*  [JSON](ValueSet-subscription-notification-type.json.md) 
*  [TTL](ValueSet-subscription-notification-type.ttl.md) 

## ValueSet: SubscriptionNotificationType 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/ValueSet/subscription-notification-type | *Version*:0.0.1 | |
| *Standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 0 | *Computable Name*:SubscriptionNotificationTypeVS |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.3.1523 | | |

 
The type of notification represented by the status message. 

 **References** 

* [R4 Backported R5 SubscriptionStatus](http://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription-status-r4.html)
* [R4 Backported R5 SubscriptionStatus](StructureDefinition-BackportSubscriptionStatusR4Fixed.md)

### Logical Definition (CLD)

Last updated: 2022-05-28 13:47:40+1100

Profile: [Shareable ValueSet](http://hl7.org/fhir/R4/shareablevalueset.html)

* Include all codes defined in [`http://hl7.org/fhir/subscription-notification-type`](CodeSystem-subscription-notification-type.md)

 

### Expansion

Expansion performed internally based on [codesystem SubscriptionNotificationType v0.0.1 (CodeSystem)](CodeSystem-subscription-notification-type.md)

This value set contains 5 concepts

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

