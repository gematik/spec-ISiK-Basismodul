# R4 Topic-Based Subscription Notification Bundle - Definitions - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **R4 Topic-Based Subscription Notification Bundle**

*  [Content](StructureDefinition-BackportSubscriptionNotificationR4Fixed.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-BackportSubscriptionNotificationR4Fixed-mappings.md) 
*  [XML](StructureDefinition-BackportSubscriptionNotificationR4Fixed.profile.xml.md) 
*  [JSON](StructureDefinition-BackportSubscriptionNotificationR4Fixed.profile.json.md) 
*  [TTL](StructureDefinition-BackportSubscriptionNotificationR4Fixed.profile.ttl.md) 

## Resource Profile: BackportSubscriptionNotificationR4Fixed - Detailed Descriptions

| |
| :--- |
| Active as of 2023-01-11 |

Definitions for the BackportSubscriptionNotificationR4Fixed resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

