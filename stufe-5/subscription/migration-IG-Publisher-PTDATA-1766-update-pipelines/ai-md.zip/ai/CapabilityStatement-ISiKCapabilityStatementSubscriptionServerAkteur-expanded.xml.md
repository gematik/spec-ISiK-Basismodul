# Akteur "ISiKCapabilityStatementSubscriptionServerAkteur" (Expanded) - XML Representation - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Akteur &quot;ISiKCapabilityStatementSubscriptionServerAkteur&quot; (Expanded)**

*  [Narrative Content](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.md) 
*  [XML](#) 
*  [JSON](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.json.md) 
*  [TTL](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.ttl.md) 

## : Akteur "ISiKCapabilityStatementSubscriptionServerAkteur" (Expanded) - XML Representation

| |
| :--- |
| Active as of 2025-06-26 |

[Raw xml](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.xml) | [Download](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.xml)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

