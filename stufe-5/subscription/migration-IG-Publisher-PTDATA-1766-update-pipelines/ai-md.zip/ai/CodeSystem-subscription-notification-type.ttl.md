# SubscriptionNotificationType - TTL Representation - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **SubscriptionNotificationType**

*  [Narrative Content](CodeSystem-subscription-notification-type.md) 
*  [XML](CodeSystem-subscription-notification-type.xml.md) 
*  [JSON](CodeSystem-subscription-notification-type.json.md) 
*  [TTL](#) 

## : SubscriptionNotificationType - TTL Representation

| | |
| :--- | :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 0 |

[Raw ttl](CodeSystem-subscription-notification-type.ttl) | [Download](CodeSystem-subscription-notification-type.ttl)

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

