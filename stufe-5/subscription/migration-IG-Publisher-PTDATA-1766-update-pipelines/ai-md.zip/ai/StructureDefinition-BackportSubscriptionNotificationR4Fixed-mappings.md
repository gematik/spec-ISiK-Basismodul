# R4 Topic-Based Subscription Notification Bundle - Mappings - Test Implementation Guide v0.0.1

Implementation Guide

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **R4 Topic-Based Subscription Notification Bundle**

*  [Content](StructureDefinition-BackportSubscriptionNotificationR4Fixed.md) 
*  [Detailed Descriptions](StructureDefinition-BackportSubscriptionNotificationR4Fixed-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-BackportSubscriptionNotificationR4Fixed.profile.xml.md) 
*  [JSON](StructureDefinition-BackportSubscriptionNotificationR4Fixed.profile.json.md) 
*  [TTL](StructureDefinition-BackportSubscriptionNotificationR4Fixed.profile.ttl.md) 

## Resource Profile: BackportSubscriptionNotificationR4Fixed - Mappings

| |
| :--- |
| Active as of 2023-01-11 |

Mappings for the BackportSubscriptionNotificationR4Fixed resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ . Paket example.test.ig#0.0.1 basierend auf [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generiert 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

