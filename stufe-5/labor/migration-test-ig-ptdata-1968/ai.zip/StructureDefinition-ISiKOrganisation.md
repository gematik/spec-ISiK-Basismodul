# ISiKOrganisation - Test Implementation Guide v0.0.1

Test Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ISiKOrganisation**

## Resource Profile: ISiKOrganisation 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKOrganisation | *Version*:0.0.1 |
| Active as of 2025-10-23 | *Computable Name*:ISiKOrganisation |

 
Dieses Profil beschreibt die Nutzung von Organisationseinheiten innerhalb eines Krankenhauses oder eines Krankenhauses als ganzem in ISiK-Szenarien. 

**Usages:**

* Examples for this Profile: [Uniklinik Entenhausen](Organization-KrankenhausOrganisationBeispiel.md)
* CapabilityStatements using this Profile: [CapabilityStatement für Rolle "AufbaustrukturRolle"](CapabilityStatement-ISiKCapabilityStatementAufbaustrukturRolle.md) and [Akteur "ISiKCapabilityStatementBasisServerAkteur" (Expanded)](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur-expanded.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/labor.test.ig|current/StructureDefinition/ISiKOrganisation)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ISiKOrganisation.csv), [Excel](StructureDefinition-ISiKOrganisation.xlsx), [Schematron](StructureDefinition-ISiKOrganisation.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKOrganisation",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKOrganisation",
  "version" : "0.0.1",
  "name" : "ISiKOrganisation",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-10-23",
  "description" : "Dieses Profil beschreibt die Nutzung von Organisationseinheiten innerhalb eines Krankenhauses oder eines Krankenhauses als ganzem in ISiK-Szenarien.",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "servd",
      "uri" : "http://www.omg.org/spec/ServD/1.0/",
      "name" : "ServD"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Organization",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Organization",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Organization",
        "path" : "Organization"
      },
      {
        "id" : "Organization.identifier",
        "path" : "Organization.identifier",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "short" : "Identifier",
        "comment" : "Motivation Kardinalität und Must Support: Jede Organisation muss über einen Business Identifier eindeutig identifiziert werden können.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.identifier:IKNR",
        "path" : "Organization.identifier",
        "sliceName" : "IKNR",
        "short" : "IKNR",
        "comment" : "Motivation: Entsprechend der Vorgabe der KBV Organisation 1.5.0. (https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Organization), muss ein System ein Institutionskennzeichen (IKNR) verarbeiten können, sofern diese Information verfügbar ist. ",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Identifier",
            "profile" : ["http://fhir.de/StructureDefinition/identifier-iknr"]
          }
        ],
        "patternIdentifier" : {
          "system" : "http://fhir.de/sid/arge-ik/iknr"
        },
        "mustSupport" : true
      },
      {
        "id" : "Organization.identifier:BSNR",
        "path" : "Organization.identifier",
        "sliceName" : "BSNR",
        "short" : "BSNR",
        "comment" : "Motivation: Entsprechend der Bedarfsmeldung im Rahmen der Stakeholderbefragung zu einem Profil Organisation in der Arbeitsgruppe zum ISIK Basismodul Stufe 4 und der Vorgabe der KBV Organisation 1.5.0. (https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Organization), muss ein System eine Betriebsstättennummer (BSNR) verarbeiten können, sofern diese Information verfügbar ist.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Identifier",
            "profile" : ["http://fhir.de/StructureDefinition/identifier-bsnr"]
          }
        ],
        "patternIdentifier" : {
          "system" : "https://fhir.kbv.de/NamingSystem/KBV_NS_Base_BSNR"
        },
        "mustSupport" : true
      },
      {
        "id" : "Organization.identifier:OrganisationseinheitenID",
        "path" : "Organization.identifier",
        "sliceName" : "OrganisationseinheitenID",
        "short" : "OrganisationseinheitenID",
        "comment" : "Hinweis: Für IDs, die krankenhaus-intern spezifischen Organisationseinheiten wie Abteilungen oder Stationen vergeben werden, ist diese Identifier zu nutzen - analog zu Slice Abteilungsidentifikator in https://simplifier.net/medizininformatikinitiative-modulstrukturdaten/mii_pr_struktur_abteilung. Da auch Stationen im Identifier-System inkludiert werden könnten, sollte hier das Identifier generisch Organisationseinheiten abbilden und nicht Abteilungen allein.\n  \n  Motivation Must Support: Jede Organisation, die über eine Organisationseinheiten-ID verfügt, soll dadurch eindeutig identifiziert werden können.",
        "min" : 0,
        "max" : "1",
        "patternIdentifier" : {
          "type" : {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "43741000"
              }
            ]
          }
        },
        "mustSupport" : true
      },
      {
        "id" : "Organization.identifier:OrganisationseinheitenID.system",
        "path" : "Organization.identifier.system",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.identifier:OrganisationseinheitenID.value",
        "path" : "Organization.identifier.value",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.identifier:TelematikID",
        "path" : "Organization.identifier",
        "sliceName" : "TelematikID",
        "short" : "Telematik-ID",
        "comment" : "Motivation Must Support: Jede Organisation, die über eine Telematik-ID verfügt, soll dadurch eindeutig identifiziert werden können.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Identifier",
            "profile" : ["http://fhir.de/StructureDefinition/identifier-telematik-id"]
          }
        ],
        "patternIdentifier" : {
          "system" : "https://gematik.de/fhir/sid/telematik-id"
        },
        "mustSupport" : true
      },
      {
        "id" : "Organization.active",
        "path" : "Organization.active",
        "short" : "Aktivitäts-Status der Organisation",
        "comment" : "Motivation: Ein System muss prüfen können, ob eine Organisation aktiv ist oder nicht, sofern diese Information verfügbar ist.",
        "mustSupport" : true
      },
      {
        "id" : "Organization.type",
        "path" : "Organization.type",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        },
        "short" : "Typ der Organisation",
        "comment" : "Motivation: Ein System muss den Typ einer Organisation zum Abruf bereitstellen, sofern diese Information verfügbar ist. \n  Die Festlegung einer endlichen Menge von Organisations-Formen in verbindlicher weise, ist zum Zeitpunkt der Festlegung nicht möglich.",
        "mustSupport" : true
      },
      {
        "id" : "Organization.type:organisationstyp",
        "path" : "Organization.type",
        "sliceName" : "organisationstyp",
        "short" : "Allgemeiner Organisationstyp",
        "comment" : "Definiert den allgemeinen Typ der Organisation.",
        "min" : 0,
        "max" : "1",
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://hl7.org/fhir/ValueSet/organization-type"
        }
      },
      {
        "id" : "Organization.type:organisationstyp.coding.system",
        "path" : "Organization.type.coding.system",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.type:organisationstyp.coding.code",
        "path" : "Organization.type.coding.code",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.type:EinrichtungsArt",
        "path" : "Organization.type",
        "sliceName" : "EinrichtungsArt",
        "short" : "Art der Einrichtung (IHE XDS)",
        "comment" : "Beschreibt die Art der Einrichtung nach IHE XDS Standards.",
        "min" : 0,
        "max" : "1",
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://ihe-d.de/ValueSets/IHEXDShealthcareFacilityTypeCode"
        }
      },
      {
        "id" : "Organization.type:EinrichtungsArt.coding.system",
        "path" : "Organization.type.coding.system",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.type:EinrichtungsArt.coding.code",
        "path" : "Organization.type.coding.code",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.type:ErweiterterFachabteilungsschluessel",
        "path" : "Organization.type",
        "sliceName" : "ErweiterterFachabteilungsschluessel",
        "short" : "Erweiterter Fachabteilungsschlüssel",
        "comment" : "Spezifiziert den erweiterten Fachabteilungsschlüssel für medizinische Einrichtungen.",
        "min" : 0,
        "max" : "1",
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://fhir.de/ValueSet/dkgev/Fachabteilungsschluessel-erweitert"
        }
      },
      {
        "id" : "Organization.type:ErweiterterFachabteilungsschluessel.coding.system",
        "path" : "Organization.type.coding.system",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.type:ErweiterterFachabteilungsschluessel.coding.code",
        "path" : "Organization.type.coding.code",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.name",
        "path" : "Organization.name",
        "short" : "Name der Organisation",
        "comment" : "Motivation: Ein System muss den Namen einer Organisation zum Abruf bereitstellen, sofern diese Information verfügbar ist..",
        "mustSupport" : true
      },
      {
        "id" : "Organization.alias",
        "path" : "Organization.alias",
        "short" : "Alias der Organisation",
        "comment" : "Hinweis: unter Umstaänden können hier Kürzel genutzt werden. Motivation: Ein System muss den Alias einer Organisation zum Abruf bereitstellen, sofern diese Information verfügbar ist.",
        "mustSupport" : true
      },
      {
        "id" : "Organization.telecom",
        "path" : "Organization.telecom",
        "short" : "Kontaktinformation",
        "comment" : "Motivation: Ein System muss Kontaktinformation einer Organisation zum Abruf bereitstellen, sofern diese Information verfügbar ist.",
        "mustSupport" : true
      },
      {
        "id" : "Organization.address",
        "path" : "Organization.address",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "short" : "Adresse der Organisation",
        "comment" : "Um zwischen Postfachadressen und physischen Adressen, Straßennamen und Hausnummern zu unterscheiden und Städtenamenszusätze hinzuzufügen, können Anbieter die Erweiterungen unterstützen, die im Deutschen Adress-Basisprofil vorgeschlagen werden (http://fhir.de/StructureDefinition/address-de-basis). Solche Differenzierungen sind jedoch im Rahmen dieser Spezifikation nicht erforderlich.",
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift",
        "path" : "Organization.address",
        "sliceName" : "Strassenanschrift",
        "short" : "Straßenanschrift",
        "comment" : "Wohn- oder Aufenthaltsort des Patienten",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Address",
            "profile" : ["http://fhir.de/StructureDefinition/address-de-basis"]
          }
        ],
        "patternAddress" : {
          "type" : "both"
        },
        "constraint" : [
          {
            "key" : "address-cnt-2or3-char",
            "severity" : "warning",
            "human" : "The content of the country element (if present) SHALL be selected EITHER from ValueSet ISO Country Alpha-2 http://hl7.org/fhir/ValueSet/iso3166-1-2 OR MAY be selected from ISO Country Alpha-3 Value Set http://hl7.org/fhir/ValueSet/iso3166-1-3, IF the country is not specified in value Set ISO Country Alpha-2 http://hl7.org/fhir/ValueSet/iso3166-1-2.",
            "expression" : "country.empty() or (country.memberOf('http://hl7.org/fhir/ValueSet/iso3166-1-2') or country.memberOf('http://hl7.org/fhir/ValueSet/iso3166-1-3'))",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKOrganisation"
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift.extension:Stadtteil",
        "path" : "Organization.address.extension",
        "sliceName" : "Stadtteil",
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift.type",
        "path" : "Organization.address.type",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift.line",
        "path" : "Organization.address.line",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift.line.extension:Strasse",
        "path" : "Organization.address.line.extension",
        "sliceName" : "Strasse",
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift.line.extension:Hausnummer",
        "path" : "Organization.address.line.extension",
        "sliceName" : "Hausnummer",
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift.line.extension:Adresszusatz",
        "path" : "Organization.address.line.extension",
        "sliceName" : "Adresszusatz",
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift.line.extension:Postfach",
        "path" : "Organization.address.line.extension",
        "sliceName" : "Postfach",
        "max" : "0"
      },
      {
        "id" : "Organization.address:Strassenanschrift.city",
        "path" : "Organization.address.city",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift.postalCode",
        "path" : "Organization.address.postalCode",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Strassenanschrift.country",
        "path" : "Organization.address.country",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Postfach",
        "path" : "Organization.address",
        "sliceName" : "Postfach",
        "short" : "Postfachadresse",
        "comment" : "Adresse, die nur für postalische Zustellung genutzt werden kann.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Address",
            "profile" : ["http://fhir.de/StructureDefinition/address-de-basis"]
          }
        ],
        "patternAddress" : {
          "type" : "postal"
        },
        "constraint" : [
          {
            "key" : "address-cnt-2or3-char",
            "severity" : "warning",
            "human" : "The content of the country element (if present) SHALL be selected EITHER from ValueSet ISO Country Alpha-2 http://hl7.org/fhir/ValueSet/iso3166-1-2 OR MAY be selected from ISO Country Alpha-3 Value Set http://hl7.org/fhir/ValueSet/iso3166-1-3, IF the country is not specified in value Set ISO Country Alpha-2 http://hl7.org/fhir/ValueSet/iso3166-1-2.",
            "expression" : "country.empty() or (country.memberOf('http://hl7.org/fhir/ValueSet/iso3166-1-2') or country.memberOf('http://hl7.org/fhir/ValueSet/iso3166-1-3'))",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKOrganisation"
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Postfach.extension:Stadtteil",
        "path" : "Organization.address.extension",
        "sliceName" : "Stadtteil",
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Postfach.type",
        "path" : "Organization.address.type",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Postfach.line",
        "path" : "Organization.address.line",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Postfach.line.extension:Strasse",
        "path" : "Organization.address.line.extension",
        "sliceName" : "Strasse",
        "max" : "0"
      },
      {
        "id" : "Organization.address:Postfach.line.extension:Hausnummer",
        "path" : "Organization.address.line.extension",
        "sliceName" : "Hausnummer",
        "max" : "0"
      },
      {
        "id" : "Organization.address:Postfach.line.extension:Adresszusatz",
        "path" : "Organization.address.line.extension",
        "sliceName" : "Adresszusatz",
        "max" : "0"
      },
      {
        "id" : "Organization.address:Postfach.line.extension:Postfach",
        "path" : "Organization.address.line.extension",
        "sliceName" : "Postfach",
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Postfach.city",
        "path" : "Organization.address.city",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Postfach.postalCode",
        "path" : "Organization.address.postalCode",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.address:Postfach.country",
        "path" : "Organization.address.country",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Organization.partOf",
        "path" : "Organization.partOf",
        "short" : "Übergeordnete Organisation",
        "comment" : "Motivation: System muss die Hierarchie einer Organisationseinheit innherhalb einer Organisation zum Abruf bereitstellen, sofern diese Information verfügbar ist.",
        "mustSupport" : true
      },
      {
        "id" : "Organization.contact",
        "path" : "Organization.contact",
        "short" : "Kontaktperson oder -abteilung",
        "comment" : "Motivation: Ein System muss Kontaktinformation einer Organisation zum Abruf bereitstellen, sofern diese Information verfügbar ist.",
        "mustSupport" : true
      },
      {
        "id" : "Organization.endpoint",
        "path" : "Organization.endpoint",
        "short" : "Technischer Endpunkt",
        "comment" : "Motivation: Ein System muss den technischen Endpunt einer Organisation zum Abruf bereitstellen, sofern diese Information verfügbar ist.",
        "mustSupport" : true
      }
    ]
  }
}

```
