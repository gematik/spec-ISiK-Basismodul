# dok.test.ig#0.0.1: Test Implementation Guide

## Pages

* [Dokumentenabfrage](Dokumentenabfrage.md)
* [Einführung](Einfuehrung.md)
* [Abgrenzung zum Basismodul](Abgrenzung-Basis.md)
* [Erzeugen von Metadaten](ErzeugenVonMetadaten.md)
* [Artifacts Summary](artifacts.md)
* [Kompatibilität](Kompatibilitaet.page.md)
* [Festlegungen zu Interaktionen](FestlegungenZuInteraktionen.md)
* [Interaktion Dokumentenbereitstellung](Interaktion-Dokumentenbereitstellung.page.md)
* [Update](Update.page.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.page.md)
* [Use Case und Akteure](UseCaseUndAkteure.md)
* [Akteure](Akteure.md)
* [Interaktionen](Interaktionen.page.md)
* [Release Notes](ReleaseNotes.page.md)

## Resources

### ValueSets

* [ISiKConfidentialityCodes](ValueSet-ISiKConfidentialityCodes.md)

### Resource Profiles

* [ISiKBinary](StructureDefinition-ISiKBinary.md)
* [Erforderliche Metadaten für Dokumentenaustausch in ISiK](StructureDefinition-ISiKDokumentenMetadaten.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)

### CapabilityStatements

* [ISiK CapabilityStatement Dokumenten Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementDokumentenServerAkteur.md)
* [ISiK CapabilityStatement Dokumenten Server Akteur](CapabilityStatement-ISiKCapabilityStatementDokumentenServerAkteur.md)
* [ISiK CapabilityStatement Dokumentenverwaltung Rolle](CapabilityStatement-ISiKCapabilityStatementDokumentenverwaltungRolle.md)
* [ISiK CapabilityStatement Metadaten Erzeugen Rolle](CapabilityStatement-ISiKCapabilityStatementMetadatenErzeugenRolle.md)
* [ISiK CapabilityStatement Metadaten Update Rolle](CapabilityStatement-ISiKCapabilityStatementMetadatenUpdateRolle.md)

### DocumentReferences

* [dok-beispiel-client-with-binary-jpeg-example-short](DocumentReference-dok-beispiel-client-with-binary-jpeg-example-short.md)
* [dok-beispiel-client-with-binary-jpeg-example](DocumentReference-dok-beispiel-client-with-binary-jpeg-example.md)
* [dok-beispiel-client-with-binary-pdf-example-short](DocumentReference-dok-beispiel-client-with-binary-pdf-example-short.md)
* [dok-beispiel-client-with-binary-pdf-example](DocumentReference-dok-beispiel-client-with-binary-pdf-example.md)
* [dok-beispiel-server](DocumentReference-dok-beispiel-server.md)

### ImplementationGuides

* [Test Implementation Guide](index.md)

### OperationDefinitions

* [Update document metadata](OperationDefinition-UpdateMetadata.md)
