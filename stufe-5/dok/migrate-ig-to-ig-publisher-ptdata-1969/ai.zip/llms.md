# dok.test.ig#0.0.1: Test Implementation Guide

## Pages

* [Dokumentenabfrage](Dokumentenabfrage.md)
* [Einführung](Einfuehrung.md)
* [Abgrenzung zum Basismodul](Abgrenzung-Basis.md)
* [Erzeugen von Metadaten](ErzeugenVonMetadaten.md)
* [Artifacts Summary](artifacts.md)
* [Kompatibilität](Kompatibilitaet.page.md)
* [Festlegungen zu Interaktionen](FestlegungenZuInteraktionen.md)
* [Interaktion Dokumentenbereitstellung](Interaktion-Dokumentenbereitstellung.page.md)
* [Update](Update.page.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.page.md)
* [Use Case und Akteure](UseCaseUndAkteure.md)
* [Akteure](Akteure.md)
* [Interaktionen](Interaktionen.page.md)
* [Release Notes](ReleaseNotes.page.md)

## Resources

### CodeSystems

* [TestKatalog](CodeSystem-CodeSystemExample.md)

### ValueSets

* [DiagnosesSCT](ValueSet-DiagnosesSCT.md)
* [ISiKLocationPhysicalType](ValueSet-ISiKLocationPhysicalType.md)
* [TestValueSet](ValueSet-ISiKValueSetExample.md)
* [ProzedurenCodesSCT](ValueSet-ProzedurenCodesSCT.md)
* [ProzedurenKategorieSCT](ValueSet-ProzedurenKategorieSCT.md)
* [Schwangerschaft Erwarteter Entbindungstermin Methode](ValueSet-SchwangerschaftEtMethodeVS.md)
* [Schwangerschaftsstatus Valueset](ValueSet-SchwangerschaftsstatusVS.md)
* [Stillstatus LOINC Antwortoptionen](ValueSet-StillstatusVS.md)
* [Current Smoking Status - IPS](ValueSet-current-smoking-status-uv-ips.md)

### Resource Profiles

* [ISiKAbrechnungsfall](StructureDefinition-ISiKAbrechnungsfall.md)
* [ISiK Alkohol Abusus](StructureDefinition-ISiKAlkoholAbusus.md)
* [ISiKAllergieUnvertraeglichkeit](StructureDefinition-ISiKAllergieUnvertraeglichkeit.md)
* [ISiKAngehoeriger](StructureDefinition-ISiKAngehoeriger.md)
* [ISiKBerichtBundle](StructureDefinition-ISiKBerichtBundle.md)
* [ISiKCodeSystem](StructureDefinition-ISiKCodeSystem.md)
* [ISiKDiagnose](StructureDefinition-ISiKDiagnose.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKLebensZustand](StructureDefinition-ISiKLebensZustand.md)
* [ISiKOrganisation](StructureDefinition-ISiKOrganisation.md)
* [ISiKOrganisationFachabteilung](StructureDefinition-ISiKOrganisationFachabteilung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)
* [ISiKProzedur](StructureDefinition-ISiKProzedur.md)
* [ISiK Raucherstatus](StructureDefinition-ISiKRaucherStatus.md)
* [ISiK Schwangerschaft - Erwarteter Entbindungstermin](StructureDefinition-ISiKSchwangerschaftErwarteterEntbindungstermin.md)
* [ISiK Schwangerschaftsstatus](StructureDefinition-ISiKSchwangerschaftsstatus.md)
* [ISiKStandort](StructureDefinition-ISiKStandort.md)
* [ISiKStandortBettenstellplatz](StructureDefinition-ISiKStandortBettenstellplatz.md)
* [ISiKStandortRaum](StructureDefinition-ISiKStandortRaum.md)
* [ISiKStillstatus](StructureDefinition-ISiKStillstatus.md)
* [ISiKValueSet](StructureDefinition-ISiKValueSet.md)
* [ISiKVersicherungsverhaeltnisGesetzlich](StructureDefinition-ISiKVersicherungsverhaeltnisGesetzlich.md)
* [ISiKVersicherungsverhaeltnisSelbstzahler](StructureDefinition-ISiKVersicherungsverhaeltnisSelbstzahler.md)
* [ISiKVersicherungsverhaeltnisSonstige](StructureDefinition-ISiKVersicherungsverhaeltnisSonstige.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)

### Accounts

* [AbrechnungsfallDRG](Account-AbrechnungsfallDRG.md)
* [AbrechnungsfallGonarthrose](Account-AbrechnungsfallGonarthrose.md)
* [SZ1DRGFall](Account-SZ1DRGFall.md)
* [SZ2DRGFall](Account-SZ2DRGFall.md)

### AllergyIntolerances

* [ISiKAllergieUnvertraeglichkeitBeispiel1](AllergyIntolerance-ISiKAllergieUnvertraeglichkeitBeispiel1.md)

### Bundles

* [ISiKBundle-Example](Bundle-ISiKBundle-Example.md)

### CapabilityStatements

* [CapabilityStatement für Rolle &quot;AufbaustrukturRolle&quot;](CapabilityStatement-ISiKCapabilityStatementAufbaustrukturRolle.md)
* [Akteur &quot;ISiKCapabilityStatementBasisServerAkteur&quot; (Expanded)](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur.md)
* [Akteur &quot;ISiKCapabilityStatementBasisServerAkteur&quot;](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur.md)
* [CapabilityStatement für Rolle &quot;ISiKCapabilityStatementCompositionKonsumentenRolle&quot;](CapabilityStatement-ISiKCapabilityStatementCompositionKonsumentenRolle.md)
* [CapabilityStatement für Rolle &quot;ISiKCapabilityStatementErweiterteStammdatenRolle&quot;](CapabilityStatement-ISiKCapabilityStatementErweiterteStammdatenRolle.md)
* [CapabilityStatement für Rolle &quot;ISiKCapabilityStatementGesundheitsstatusRolle&quot;](CapabilityStatement-ISiKCapabilityStatementGesundheitsstatusRolle.md)
* [CapabilityStatement für Rolle &quot;ISiKCapabilityStatementKlinischeRolle&quot;](CapabilityStatement-ISiKCapabilityStatementKlinischeRolle.md)
* [CapabilityStatement für Rolle &quot;LeistungserbringerRolle&quot;](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)
* [CapabilityStatement für Rolle &quot;StammdatenRolle&quot;](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)
* [CapabilityStatement für Rolle &quot;ISiKCapabilityStatementTerminologieRolle&quot;](CapabilityStatement-ISiKCapabilityStatementTerminologieRolle.md)
* [CapabilityStatement für Rolle &quot;ISiKCapabilityStatementVersicherungsverhaeltnisRolle&quot;](CapabilityStatement-ISiKCapabilityStatementVersicherungsverhaeltnisRolle.md)

### Conditions

* [AltersbedingteKreislaufstoerung](Condition-AltersbedingteKreislaufstoerung.md)
* [BehandlungsDiagnoseFreitext](Condition-BehandlungsDiagnoseFreitext.md)
* [Example-condition-ausrufezeichen-primaer](Condition-Example-condition-ausrufezeichen-primaer.md)
* [Example-condition-ausrufezeichen-sekundaer](Condition-Example-condition-ausrufezeichen-sekundaer.md)
* [Example-condition-kreuz-stern-primaer](Condition-Example-condition-kreuz-stern-primaer.md)
* [Example-condition-kreuz-stern-sekundaer](Condition-Example-condition-kreuz-stern-sekundaer.md)
* [MittelgradigeIntelligenzminderung](Condition-MittelgradigeIntelligenzminderung.md)
* [PrimaereGonarthroseMinimal](Condition-PrimaereGonarthroseMinimal.md)
* [PrimaereGonarthroseNormal](Condition-PrimaereGonarthroseNormal.md)
* [SZ2Primaerdiagnose](Condition-SZ2Primaerdiagnose.md)
* [SZ2Sekundaerdiagnose](Condition-SZ2Sekundaerdiagnose.md)

### Coverages

* [CoverageGesetzlich](Coverage-CoverageGesetzlich.md)
* [CoveragePrivat](Coverage-CoveragePrivat.md)
* [CoverageSonstige](Coverage-CoverageSonstige.md)
* [SZ1VersicherungGesetzlich](Coverage-SZ1VersicherungGesetzlich.md)
* [SZ1VersicherungSelbstzahler](Coverage-SZ1VersicherungSelbstzahler.md)
* [SZ2VersicherungGesetzlich](Coverage-SZ2VersicherungGesetzlich.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)

### ImplementationGuides

* [Test Implementation Guide](index.md)

### Locations

* [BettenstellplatzStandortBeispiel](Location-BettenstellplatzStandortBeispiel.md)
* [RaumStandortBeispiel](Location-RaumStandortBeispiel.md)
* [Station A](Location-StationStandortBeispiel.md)

### Observations

* [ISiKAlkoholAbususBeispiel](Observation-ISiKAlkoholAbususBeispiel.md)
* [ISiKRaucherStatusBeispiel](Observation-ISiKRaucherStatusBeispiel.md)
* [ISiKSchwangerschaftErwarteterEntbindungsterminBeispiel](Observation-ISiKSchwangerschaftErwarteterEntbindungsterminBeispiel.md)
* [ISiKSchwangerschaftsstatusBeispiel](Observation-ISiKSchwangerschaftsstatusBeispiel.md)
* [ISiKStillstatusBeispiel](Observation-ISiKStillstatusBeispiel.md)

### Organizations

* [Allgemeinchirurgie](Organization-AbteilungAllgemeinchirurgieOrganisationBeispiel.md)
* [Uniklinik Entenhausen](Organization-KrankenhausOrganisationBeispiel.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)

### Practitioners

* [PractitionerWalterArzt](Practitioner-PractitionerWalterArzt.md)

### Procedures

* [Appendektomie](Procedure-Appendektomie.md)

### RelatedPeople

* [ISiKAngehoerigerMustermann](RelatedPerson-ISiKAngehoerigerMustermann.md)
* [SZ1Mutter](RelatedPerson-SZ1Mutter.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
