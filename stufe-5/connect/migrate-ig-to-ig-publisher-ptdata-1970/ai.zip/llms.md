# connect.test.ig#0.0.1: Test Implementation Guide

## Pages

* [Einführung](index.md)
* [Schritt 2: Client Autorisierung](Schritt2ClientAutorisierung.md)
* [Conformance Scopes und Kontexte](ConformanceScopesKontexte.md)
* [ISiK Connect Kontext](Kontext.md)
* [Schritt 3 Abruf Access Token](Schritt3AbrufAccessToken.md)
* [Schritt 1 Registrierung Backend Service](Schritt1RegistrierungBackendService.md)
* [Conformance Smart Capabilities](ConformanceSmartCapabilities.md)
* [Schritt 4 FHIR Rest Interaktion](Schritt4FHIRRestInteraktion.md)
* [Schritt 4: Austausch von Autorisierungscodes gegen Zugangstoken](Schritt4AustauschAutorisierungscodesZugangstoken.md)
* [Conformance](Conformance.md)
* [Artifacts Summary](artifacts.md)
* [Festlegungen zur Kompatibilität der gematik-Spezifikation](KompatibilitaetDerGematikSpezifikation.md)
* [Schritt 3: Evaluierung von Autorisierungsanfragen](Schritt3EvaluierungAutorisierungsanfragen.md)
* [Autorisierung](ISiKAutorisierung.md)
* [Übergreifende Festlegungen und Kompatibilität](UebergreifendeFestlegungen.md)
* [Schritt 1: Registrierung eines Clients](Schritt1RegistrierungClient.md)
* [Schritt 2 Abruf Smart Configuration](Schritt2AbrufSmartConfiguration.md)
* [Akteure](Akteure.md)
* [Auto Provisioning](AutoProvisioning.md)
* [Backend Services](BackendServices.md)
* [Release Notes](ReleaseNotes.md)
* [Schritt 6: Refresh Token & Revocation](Schritt6RefreshToken.md)
* [Schritt 5: FHIR REST Interaktion](Schritt5FHIRRestInteraktion.md)
* [Anforderungsübersicht](Anforderungsuebersicht.md)
* [ISiK Connect und Smart-on-FHIR](ISiKundSMART.md)

## Resources

### ImplementationGuides

* [Test Implementation Guide](index.md)
