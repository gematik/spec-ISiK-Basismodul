# vitalparameter.test.ig#0.0.1: Test Implementation Guide

## Pages

* [Einführung](index.md)
* [Laborprofile](Laborprofile.md)
* [Signaldaten](Signaldaten.md)
* [Kompatibilität](Kompatibilitaet.md)
* [Interaktionen](Interaktionen.md)
* [REST-API](RestApi.md)
* [Artifacts Summary](artifacts.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Interaktionen und Akteure](InteraktionenAkteure.md)
* [Release Notes](ReleaseNotes.md)
* [Intensivversorgung](Intensivversorgung.md)
* [AMTS](AMTS.md)
* [Übergreifende Festlegungen Index](UebergreifendeFestlegungenIndex.md)

## Resources

### ValueSets

* [ISiKLocationPhysicalType](ValueSet-ISiKLocationPhysicalType.md)
* [ObservationCodesCRP](ValueSet-ObservationCodesCRP.md)
* [ObservationCodesGFR](ValueSet-ObservationCodesGFR.md)
* [ObservationCodesHb](ValueSet-ObservationCodesHb.md)
* [ObservationCodesPCT](ValueSet-ObservationCodesPCT.md)
* [ObservationCodesSerumkreatinin](ValueSet-ObservationCodesSerumkreatinin.md)
* [ObservationCodesTSH](ValueSet-ObservationCodesTSH.md)
* [ObservationCodesThrombozyten](ValueSet-ObservationCodesThrombozyten.md)
* [ObservationCodesTroponin](ValueSet-ObservationCodesTroponin.md)
* [ObservationUnitsCRP](ValueSet-ObservationUnitsCRP.md)
* [ObservationUnitsGFR](ValueSet-ObservationUnitsGFR.md)
* [ObservationUnitsHb](ValueSet-ObservationUnitsHb.md)
* [ObservationUnitsPCT](ValueSet-ObservationUnitsPCT.md)
* [ObservationUnitsSerumkreatinin](ValueSet-ObservationUnitsSerumkreatinin.md)
* [ObservationUnitsTSH](ValueSet-ObservationUnitsTSH.md)
* [ObservationUnitsThrombozyten](ValueSet-ObservationUnitsThrombozyten.md)
* [ObservationUnitsTroponin](ValueSet-ObservationUnitsTroponin.md)

### Resource Profiles

* [ISiKAtemfrequenz](StructureDefinition-ISiKAtemfrequenz.md)
* [ISiKBlutdruckSystemischArteriell](StructureDefinition-ISiKBlutdruckSystemischArteriell.md)
* [ISiKEKG](StructureDefinition-ISiKEKG.md)
* [ISiKGCS](StructureDefinition-ISiKGCS.md)
* [ISiKHerzfrequenz](StructureDefinition-ISiKHerzfrequenz.md)
* [ISiKKoerpergewicht](StructureDefinition-ISiKKoerpergewicht.md)
* [ISiKKoerpergroesse](StructureDefinition-ISiKKoerpergroesse.md)
* [ISiKKoerpertemperatur](StructureDefinition-ISiKKoerpertemperatur.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKKopfumfang](StructureDefinition-ISiKKopfumfang.md)
* [ISiKLaboruntersuchung](StructureDefinition-ISiKLaboruntersuchung.md)
* [ISiKLaboruntersuchungCRP](StructureDefinition-ISiKLaboruntersuchungCRP.md)
* [ISiKLaboruntersuchungGFR](StructureDefinition-ISiKLaboruntersuchungGFR.md)
* [ISiKLaboruntersuchungHb](StructureDefinition-ISiKLaboruntersuchungHb.md)
* [ISiKLaboruntersuchungPCT](StructureDefinition-ISiKLaboruntersuchungPCT.md)
* [ISiKLaboruntersuchungSerumkreatinin](StructureDefinition-ISiKLaboruntersuchungSerumkreatinin.md)
* [ISiKLaboruntersuchungTSH](StructureDefinition-ISiKLaboruntersuchungTSH.md)
* [ISiKLaboruntersuchungThrombozyten](StructureDefinition-ISiKLaboruntersuchungThrombozyten.md)
* [ISiKLaboruntersuchungTroponin](StructureDefinition-ISiKLaboruntersuchungTroponin.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKSauerstoffsaettigungArteriell](StructureDefinition-ISiKSauerstoffsaettigungArteriell.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ISiKTerminPriorityExtension](StructureDefinition-ISiKTerminPriorityExtension.md)

### CapabilityStatements

* [ISiK CapabilityStatement Labor Minimal Rolle](CapabilityStatement-ISiKCapabilityStatementLaborMinimalRolle.md)
* [CapabilityStatement für Rolle &quot;StammdatenRolle&quot;](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)
* [ISiK CapabilityStatement Vital Sign Standard Source Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementVitalSignStandardSourceAkteur.md)
* [ISiK CapabilityStatement Vital Sign Standard Source Akteur](CapabilityStatement-ISiKCapabilityStatementVitalSignStandardSourceAkteur.md)
* [ISiK CapabilityStatement VitalSign Standard Source Rolle](CapabilityStatement-ISiKCapabilityStatementVitalSignStandardSourceRolle.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)

### ImplementationGuides

* [Test Implementation Guide](index.md)

### Observations

* [ExampleISiKLaboruntersuchungCRP1](Observation-ExampleISiKLaboruntersuchungCRP1.md)
* [ExampleISiKLaboruntersuchungGFR1](Observation-ExampleISiKLaboruntersuchungGFR1.md)
* [ExampleISiKLaboruntersuchungHb1](Observation-ExampleISiKLaboruntersuchungHb1.md)
* [ExampleISiKLaboruntersuchungPCT1](Observation-ExampleISiKLaboruntersuchungPCT1.md)
* [ExampleISiKLaboruntersuchungSerumkreatinin1](Observation-ExampleISiKLaboruntersuchungSerumkreatinin1.md)
* [ExampleISiKLaboruntersuchungTSH1](Observation-ExampleISiKLaboruntersuchungTSH1.md)
* [ExampleISiKLaboruntersuchungThrombozyten1](Observation-ExampleISiKLaboruntersuchungThrombozyten1.md)
* [ExampleISiKLaboruntersuchungTroponin1](Observation-ExampleISiKLaboruntersuchungTroponin1.md)
* [ExtractedObservationKoerpergewicht](Observation-ExtractedObservationKoerpergewicht.md)
* [ExtractedObservationKoerpergroesse](Observation-ExtractedObservationKoerpergroesse.md)
* [ISiKAtemfrequenzExample](Observation-ISiKAtemfrequenzExample.md)
* [ISiKAtemfrequenzMaxExample](Observation-ISiKAtemfrequenzMaxExample.md)
* [ISiKAtemfrequenzMinExample](Observation-ISiKAtemfrequenzMinExample.md)
* [ISiKBlutdruckSystemischArteriellExample](Observation-ISiKBlutdruckSystemischArteriellExample.md)
* [ISiKBlutdruckSystemischArteriellMaxExample](Observation-ISiKBlutdruckSystemischArteriellMaxExample.md)
* [ISiKBlutdruckSystemischArteriellMinExample](Observation-ISiKBlutdruckSystemischArteriellMinExample.md)
* [ISiKEKGExample](Observation-ISiKEKGExample.md)
* [ISiKEKGMaxExample](Observation-ISiKEKGMaxExample.md)
* [ISiKEKGMinExample](Observation-ISiKEKGMinExample.md)
* [ISiKGCSExample](Observation-ISiKGCSExample.md)
* [ISiKGCSMaxExample](Observation-ISiKGCSMaxExample.md)
* [ISiKGCSMinExample](Observation-ISiKGCSMinExample.md)
* [ISiKHerzfrequenzExample](Observation-ISiKHerzfrequenzExample.md)
* [ISiKHerzfrequenzMaxExample](Observation-ISiKHerzfrequenzMaxExample.md)
* [ISiKHerzfrequenzMinExample](Observation-ISiKHerzfrequenzMinExample.md)
* [ISiKKoerpergewichtExample](Observation-ISiKKoerpergewichtExample.md)
* [ISiKKoerpergewichtMaxExample](Observation-ISiKKoerpergewichtMaxExample.md)
* [ISiKKoerpergewichtMinExample](Observation-ISiKKoerpergewichtMinExample.md)
* [ISiKKoerpergroesseExample](Observation-ISiKKoerpergroesseExample.md)
* [ISiKKoerpergroesseMaxExample](Observation-ISiKKoerpergroesseMaxExample.md)
* [ISiKKoerpergroesseMinExample](Observation-ISiKKoerpergroesseMinExample.md)
* [ISiKKoerpertemperaturExample](Observation-ISiKKoerpertemperaturExample.md)
* [ISiKKoerpertemperaturMaxExample](Observation-ISiKKoerpertemperaturMaxExample.md)
* [ISiKKoerpertemperaturMinExample](Observation-ISiKKoerpertemperaturMinExample.md)
* [ISiKKopfumfangExample](Observation-ISiKKopfumfangExample.md)
* [ISiKKopfumfangMaxExample](Observation-ISiKKopfumfangMaxExample.md)
* [ISiKKopfumfangMinExample](Observation-ISiKKopfumfangMinExample.md)
* [ISiKSauerstoffsaettigungArteriellExample](Observation-ISiKSauerstoffsaettigungArteriellExample.md)
* [ISiKSauerstoffsaettigungArteriellMaxExample](Observation-ISiKSauerstoffsaettigungArteriellMaxExample.md)
* [ISiKSauerstoffsaettigungArteriellMinExample](Observation-ISiKSauerstoffsaettigungArteriellMinExample.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
