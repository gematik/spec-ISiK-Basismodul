# amts#6.0.0-rc: AMTS ISiK Implementierungsleitfaden

## Pages

* [Einführung](index.md)
* [Festlegungen](Festlegungen.md)
* [Use Cases](UseCases.md)
* [Artifacts Summary](artifacts.md)
* [Stakeholder, User und weitere Systeme](Akteure.md)
* [Release Notes](ReleaseNotes.md)
* [FHIR-Artefakte](artifacts-isik.md)

## Resources

### CodeSystems

* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiK Medikationsart](CodeSystem-ISiKMedikationsartCS.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)

### ValueSets

* [DiagnosesSCT](ValueSet-DiagnosesSCT.md)
* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiKLocationPhysicalType](ValueSet-ISiKLocationPhysicalType.md)
* [ISiKMedikationsartVS](ValueSet-ISiKMedikationsartVS.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)
* [Medikationslisten-Modes](ValueSet-MedikationsListeListModeVS.md)
* [ObservationCodesCRP](ValueSet-ObservationCodesCRP.md)
* [ObservationCodesGFR](ValueSet-ObservationCodesGFR.md)
* [ObservationCodesHb](ValueSet-ObservationCodesHb.md)
* [ObservationCodesPCT](ValueSet-ObservationCodesPCT.md)
* [ObservationCodesSerumkreatinin](ValueSet-ObservationCodesSerumkreatinin.md)
* [ObservationCodesTSH](ValueSet-ObservationCodesTSH.md)
* [ObservationCodesThrombozyten](ValueSet-ObservationCodesThrombozyten.md)
* [ObservationCodesTroponin](ValueSet-ObservationCodesTroponin.md)
* [ObservationUnitsCRP](ValueSet-ObservationUnitsCRP.md)
* [ObservationUnitsGFR](ValueSet-ObservationUnitsGFR.md)
* [ObservationUnitsHb](ValueSet-ObservationUnitsHb.md)
* [ObservationUnitsPCT](ValueSet-ObservationUnitsPCT.md)
* [ObservationUnitsSerumkreatinin](ValueSet-ObservationUnitsSerumkreatinin.md)
* [ObservationUnitsTSH](ValueSet-ObservationUnitsTSH.md)
* [ObservationUnitsThrombozyten](ValueSet-ObservationUnitsThrombozyten.md)
* [ObservationUnitsTroponin](ValueSet-ObservationUnitsTroponin.md)
* [ProzedurenCodesSCT](ValueSet-ProzedurenCodesSCT.md)
* [ProzedurenKategorieSCT](ValueSet-ProzedurenKategorieSCT.md)
* [Schwangerschaft Erwarteter Entbindungstermin Methode](ValueSet-SchwangerschaftEtMethodeVS.md)
* [Schwangerschaftsstatus Valueset](ValueSet-SchwangerschaftsstatusVS.md)
* [SctRouteOfAdministration](ValueSet-SctRouteOfAdministration.md)
* [Stillstatus LOINC Antwortoptionen](ValueSet-StillstatusVS.md)
* [Current Smoking Status - IPS](ValueSet-current-smoking-status-uv-ips.md)

### Complex-type Profiles

* [ISiKASKCoding](StructureDefinition-ISiKASKCoding.md)
* [ISiKATCCoding](StructureDefinition-ISiKATCCoding.md)
* [ISiKCoding](StructureDefinition-ISiKCoding.md)
* [ISiKICD10GMCoding](StructureDefinition-ISiKICD10GMCoding.md)
* [ISiKLoincCoding](StructureDefinition-ISiKLoincCoding.md)
* [ISiKPZNCoding](StructureDefinition-ISiKPZNCoding.md)
* [ISiKSnomedCTCoding](StructureDefinition-ISiKSnomedCTCoding.md)
* [Medication Quantity](StructureDefinition-MedicationQuantity.md)

### Resource Profiles

* [ISiK AMTS-Bewertung](StructureDefinition-ISiKAMTSBewertung.md)
* [ISiK Alkohol Abusus](StructureDefinition-ISiKAlkoholAbusus.md)
* [ISiKAllergieUnvertraeglichkeit](StructureDefinition-ISiKAllergieUnvertraeglichkeit.md)
* [ISiKDiagnose](StructureDefinition-ISiKDiagnose.md)
* [ISiKKoerpergewicht](StructureDefinition-ISiKKoerpergewicht.md)
* [ISiKKoerpergroesse](StructureDefinition-ISiKKoerpergroesse.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKLaboruntersuchung](StructureDefinition-ISiKLaboruntersuchung.md)
* [ISiKLaboruntersuchungCRP](StructureDefinition-ISiKLaboruntersuchungCRP.md)
* [ISiKLaboruntersuchungGFR](StructureDefinition-ISiKLaboruntersuchungGFR.md)
* [ISiKLaboruntersuchungHb](StructureDefinition-ISiKLaboruntersuchungHb.md)
* [ISiKLaboruntersuchungPCT](StructureDefinition-ISiKLaboruntersuchungPCT.md)
* [ISiKLaboruntersuchungSerumkreatinin](StructureDefinition-ISiKLaboruntersuchungSerumkreatinin.md)
* [ISiKLaboruntersuchungTSH](StructureDefinition-ISiKLaboruntersuchungTSH.md)
* [ISiKLaboruntersuchungThrombozyten](StructureDefinition-ISiKLaboruntersuchungThrombozyten.md)
* [ISiKLaboruntersuchungTroponin](StructureDefinition-ISiKLaboruntersuchungTroponin.md)
* [ISiKLebensZustand](StructureDefinition-ISiKLebensZustand.md)
* [ISiKMedikament](StructureDefinition-ISiKMedikament.md)
* [ISiKMedikationsInformation](StructureDefinition-ISiKMedikationsInformation.md)
* [ISiK Medikationsliste](StructureDefinition-ISiKMedikationsListe.md)
* [ISiKMedikationsVerabreichung](StructureDefinition-ISiKMedikationsVerabreichung.md)
* [ISiKMedikationsVerordnung](StructureDefinition-ISiKMedikationsVerordnung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)
* [ISiKProzedur](StructureDefinition-ISiKProzedur.md)
* [ISiK Raucherstatus](StructureDefinition-ISiKRaucherStatus.md)
* [ISiK Schwangerschaft - Erwarteter Entbindungstermin](StructureDefinition-ISiKSchwangerschaftErwarteterEntbindungstermin.md)
* [ISiK Schwangerschaftsstatus](StructureDefinition-ISiKSchwangerschaftsstatus.md)
* [ISiKStillstatus](StructureDefinition-ISiKStillstatus.md)

### Extensions

* [ISiK Accepted Risk](StructureDefinition-ExtensionISiKAcceptedRisk.md)
* [ISiK Behandlungsziel](StructureDefinition-ExtensionISiKBehandlungsziel.md)
* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ISiK MedicationRequestReplaces](StructureDefinition-ExtensionISiKMedicationRequestReplaces.md)
* [ISiK MedicationStatementReplaces](StructureDefinition-ExtensionISiKMedicationStatementReplaces.md)
* [ISiK Medikationsart](StructureDefinition-ExtensionISiKMedikationsart.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)
* [ISiK Selbstmedikation](StructureDefinition-ExtensionISiKSelbstmedikation.md)
* [PlannedEndDate](StructureDefinition-PlannedEndDate.md)
* [PlannedStartDate](StructureDefinition-PlannedStartDate.md)

### CapabilityStatements

* [ISiK CapabilityStatement AMTS Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementAMTSAkteur-expanded.md)
* [ISiK CapabilityStatement AMTS Akteur](CapabilityStatement-ISiKCapabilityStatementAMTSAkteur.md)
* [ISiK CapabilityStatement AMTS Rolle](CapabilityStatement-ISiKCapabilityStatementAMTSRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementGesundheitsstatusRolle](CapabilityStatement-ISiKCapabilityStatementGesundheitsstatusRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementKlinischeRolle](CapabilityStatement-ISiKCapabilityStatementKlinischeRolle.md)
* [ISiK CapabilityStatement Labor Minimal Rolle](CapabilityStatement-ISiKCapabilityStatementLaborMinimalRolle.md)
* [CapabilityStatement für Rolle LeistungserbringerRolle](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)
* [ISiK CapabilityStatement MedikamentRolle](CapabilityStatement-ISiKCapabilityStatementMedikamentRolle.md)
* [ISiK CapabilityStatement Medikation Server - Medikationsinformation](CapabilityStatement-ISiKCapabilityStatementMedikationInformationRolle.md)
* [ISiK CapabilityStatement Medikationsverabreichung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungRolle.md)
* [ISiK CapabilityStatement Medikationsverordnung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungRolle.md)
* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)

### ImplementationGuides

* [AMTS ISiK Implementierungsleitfaden](index.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
