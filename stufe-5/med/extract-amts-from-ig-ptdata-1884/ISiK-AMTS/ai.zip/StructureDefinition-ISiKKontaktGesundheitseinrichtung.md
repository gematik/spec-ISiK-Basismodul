# ISiKKontaktGesundheitseinrichtung - AMTS ISiK Implementierungsleitfaden v6.0.0-rc

AMTS ISiK Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ISiKKontaktGesundheitseinrichtung**

## Resource Profile: ISiKKontaktGesundheitseinrichtung 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung | *Version*:6.0.0-rc |
| Active as of 2025-12-17 | *Computable Name*:ISiKKontaktGesundheitseinrichtung |

 
Dieses Profil ermöglicht die Abbildung von Besuchen/Aufenthalten eines Patienten in einer Gesundheitseinrichtung. 

### Motivation

 
Informationen über die Besuche des Patienten entlang seines Behandlungspfades im Krankenhaus sind ein wichtiger Bestandteil des einrichtungsinternen Datenaustausches. Sie ermöglichen die Unterscheidung von stationären und ambulanten sowie aufgenommenen und entlassenen Patienten. Weiterhin ist aus den Besuchsinformationen der aktuelle Aufenthaltsort des Patienten (Fachabteilung, Station, Bettplatz) ermittelbar. Klinische Ressourcen werden in FHIR durch Verlinkung auf die Encounter-Ressource in einen Kontext zum Besuch gestellt. Dieser Kontext ist wichtig für die Steuerung von Zugriffsberechtigungen und Abrechnungsprozessen. 
Zu Beginn der meisten klinischen Workflows steht die Auswahl des Besuchskontextes. Dies geschieht bspw. durch das Suchen der Encounter-Ressource anhand von Eigenschaften wie Aufnahmenummer, Fallart oder Aufnahmedatum. Daraufhin werden die zutreffenden Suchergebnisse angezeigt und der gewünschte Besuch ausgewählt. 
In FHIR werden Besuche, Aufenthalte, aber auch virtuelle Kontakte mit der `Encounter`-Ressource repräsentiert. 
Weitere Hinweise zu den Abgrenzungen der Begrifflichkeiten Fall und Kontakt finden sie unter {{pagelink: Fall, text: Fall-Begriff in ISiK}} 

### Kompatibilität

 
Für das Profil ISiKKontaktGesundheitseinrichtung wird eine Kompatibilität mit folgenden Profilen angestrebt; allerdings kann nicht sichergestellt werden, dass Instanzen, die gegen ISiKKontaktGesundheitseinrichtung valide sind, auch valide sind gegen: 
* Profil [Kontakt mit einer Gesundheitseinrichtung der Medizininformatik-Initiative](https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung)
 
Hinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden. 

**Usages:**

* CapabilityStatements using this Profile: [ISiK CapabilityStatement AMTS Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementAMTSAkteur-expanded.md), [CapabilityStatement für Rolle LeistungserbringerRolle](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md) and [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)
* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/amts|current/StructureDefinition/ISiKKontaktGesundheitseinrichtung)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKKontaktGesundheitseinrichtung",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung",
  "version" : "6.0.0-rc",
  "name" : "ISiKKontaktGesundheitseinrichtung",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-17",
  "publisher" : "gematik GmbH",
  "contact" : [
    {
      "name" : "gematik GmbH",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://gematik.de"
        }
      ]
    }
  ],
  "description" : "\nDieses Profil ermöglicht die Abbildung von Besuchen/Aufenthalten eines Patienten in einer Gesundheitseinrichtung.\n### Motivation\nInformationen über die Besuche des Patienten entlang seines \nBehandlungspfades im Krankenhaus sind ein wichtiger Bestandteil \ndes einrichtungsinternen Datenaustausches. \nSie ermöglichen die Unterscheidung von stationären und ambulanten \nsowie aufgenommenen und entlassenen Patienten. \nWeiterhin ist aus den Besuchsinformationen der aktuelle Aufenthaltsort \ndes Patienten (Fachabteilung, Station, Bettplatz) ermittelbar. \nKlinische Ressourcen werden in FHIR durch Verlinkung auf die \nEncounter-Ressource in einen Kontext zum Besuch gestellt. \nDieser Kontext ist wichtig für die Steuerung von Zugriffsberechtigungen \nund Abrechnungsprozessen.  \n\nZu Beginn der meisten klinischen Workflows steht die Auswahl \ndes Besuchskontextes. \nDies geschieht bspw. durch das Suchen der Encounter-Ressource \nanhand von Eigenschaften wie Aufnahmenummer, Fallart oder Aufnahmedatum. \nDaraufhin werden die zutreffenden Suchergebnisse angezeigt \nund der gewünschte Besuch ausgewählt.\n\nIn FHIR werden Besuche, Aufenthalte, aber auch virtuelle Kontakte mit der `Encounter`-Ressource repräsentiert.\n\nWeitere Hinweise zu den Abgrenzungen der Begrifflichkeiten Fall und Kontakt finden sie unter {{pagelink: Fall, text: Fall-Begriff in ISiK}}\n\n### Kompatibilität\nFür das Profil ISiKKontaktGesundheitseinrichtung wird eine Kompatibilität \nmit folgenden Profilen angestrebt; \nallerdings kann nicht sichergestellt werden, dass Instanzen, \ndie gegen ISiKKontaktGesundheitseinrichtung valide sind, \nauch valide sind gegen:\n\n* Profil [Kontakt mit einer Gesundheitseinrichtung \nder Medizininformatik-Initiative](https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung)\n\nHinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden.",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Encounter",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Encounter",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Encounter",
        "path" : "Encounter",
        "constraint" : [
          {
            "key" : "ISiK-enc-1",
            "severity" : "error",
            "human" : "Abgeschlossene, ambulante Kontakte sollten einen Start-Zeitpunkt angeben",
            "expression" : "status = 'finished' and class = 'AMB' implies period.start.exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
          },
          {
            "key" : "ISiK-enc-2",
            "severity" : "error",
            "human" : "Abgeschlossene, stationäre Kontakte sollten einen Start- und End-Zeitpunkt angeben",
            "expression" : "status = 'finished' and class = 'IMP' implies period.start.exists() and period.end.exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
          },
          {
            "key" : "ISiK-enc-3",
            "severity" : "error",
            "human" : "Geplante Kontakte sollten keinen Start- oder End-Zeitpunkt angeben",
            "expression" : "status = 'planned' implies period.exists().not()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
          },
          {
            "key" : "ISiK-enc-4",
            "severity" : "warning",
            "human" : "Geplante Kontakte sollten die Extensions für den geplanten Start- oder End-Zeitpunkt verwenden",
            "expression" : "status = 'planned' implies extension.where(url = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Encounter.plannedStartDate').exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
          },
          {
            "key" : "ISiK-enc-5",
            "severity" : "error",
            "human" : "In-Durchführung befindliche Kontakte sollten einen Start-Zeitpunkt angeben",
            "expression" : "status = 'in-progress' implies period.start.exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
          },
          {
            "key" : "ISiK-enc-6",
            "severity" : "error",
            "human" : "Kontakte mit Abwesenheitsstatus sollten einen Start-Zeitpunkt angeben",
            "expression" : "status = 'onleave' implies period.start.exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
          },
          {
            "key" : "ISiK-enc-7",
            "severity" : "warning",
            "human" : "Kontakte mit unbekannten Status sollten einen Start-Zeitpunkt angeben",
            "expression" : "status = 'unknown' implies period.start.exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
          },
          {
            "key" : "ISiK-enc-8",
            "severity" : "error",
            "human" : "Die Rolle der assoziierten Diagnose(n) darf nicht 'Billing' sein",
            "expression" : "diagnosis.use.all(coding.code != 'billing')",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
          }
        ]
      },
      {
        "id" : "Encounter.id",
        "path" : "Encounter.id",
        "short" : "serverseitige, interne ID des Datensatzes",
        "comment" : "**bedingtes Pflichtfeld/bedingtes MS:** Alle von einem Server bereitgestellten Ressourcen MÜSSEN über eine `id` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `id`verfügen. ",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.meta.versionId",
        "path" : "Encounter.meta.versionId",
        "short" : "Eindeutiger Name der serverseitigen Version des Datensatzes",
        "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über eine `versionID` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `versionID`verfügen. "
      },
      {
        "id" : "Encounter.meta.lastUpdated",
        "path" : "Encounter.meta.lastUpdated",
        "short" : "Zeitpunkt der letzten Änderung",
        "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über ein `lastUpdate` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über ein `lastUpdate`verfügen. "
      },
      {
        "id" : "Encounter.extension",
        "path" : "Encounter.extension",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "url"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        },
        "mustSupport" : true
      },
      {
        "id" : "Encounter.extension:Aufnahmegrund",
        "path" : "Encounter.extension",
        "sliceName" : "Aufnahmegrund",
        "short" : "Aufnahmegrund",
        "comment" : "Aufnahmegrund nach § 301 Abs. 3 SGB V. Dieser gehört zu den 'Medizinischen Daten des Behandlungsfalls' entsprechend der Definitionen für die Datenübermittlung\nnach § 301 Abs. 3 SGB V. Somit sind diese über den Kontakt und nicht über den Abrechnungsfall zu dokumentieren. Diese Extension SOLL am ersten Abteilungskontakt, der die stationäre Aufnahme repräsentiert, dokumentiert werden. Wird durch den Encounter ein Einrichtungskontakt repräsentiert, SOLL dort zusätzlich zu dem Abteilungskontakt der Aufnahmegrund dokumentiert werden.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : ["http://fhir.de/StructureDefinition/Aufnahmegrund"]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Encounter.extension:Aufnahmegrund.extension:ErsteUndZweiteStelle",
        "path" : "Encounter.extension.extension",
        "sliceName" : "ErsteUndZweiteStelle",
        "short" : "Aufnahmegrund: 1. & 2. Stelle",
        "comment" : "1. und 2. Stelle des Aufnahmegrunds nach § 301 Abs. 3 SGB V.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.extension:Aufnahmegrund.extension:DritteStelle",
        "path" : "Encounter.extension.extension",
        "sliceName" : "DritteStelle",
        "short" : "Aufnahmegrund: 3. Stelle",
        "comment" : "3. Stelle des Aufnahmegrunds nach § 301 Abs. 3 SGB V.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.extension:Aufnahmegrund.extension:VierteStelle",
        "path" : "Encounter.extension.extension",
        "sliceName" : "VierteStelle",
        "short" : "Aufnahmegrund: 4. Stelle",
        "comment" : "4. Stelle des Aufnahmegrunds nach § 301 Abs. 3 SGB V.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.extension:plannedStartDate",
        "path" : "Encounter.extension",
        "sliceName" : "plannedStartDate",
        "short" : "geplantes Aufnahmedatum",
        "comment" : "**Begründung MS:** Im Falle einer geplanten Aufnahme ist das Datum mittels dieser Extension anzugeben.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://hl7.org/fhir/5.0/StructureDefinition/extension-Encounter.plannedStartDate"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Encounter.extension:plannedEndDate",
        "path" : "Encounter.extension",
        "sliceName" : "plannedEndDate",
        "short" : "geplantes Entlassdatum",
        "comment" : "**Begründung MS:** Im Falle der Dokumentation eines geplanten Entlassdatums ist diese Extension zu befüllen.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://hl7.org/fhir/5.0/StructureDefinition/extension-Encounter.plannedEndDate"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Encounter.identifier",
        "path" : "Encounter.identifier",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "comment" : "Eindeutiger Identifier des Encounter",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.identifier:Aufnahmenummer",
        "path" : "Encounter.identifier",
        "sliceName" : "Aufnahmenummer",
        "short" : "Aufnahmenummer",
        "comment" : "**Begründung MS:** Die Aufnahmenummer ist nicht die 'Fallnummer', welche sich auf den kompletten Abrechnungsfall bezieht. Hier wird ein Identifier angegeben, der den Kontakt eindeutig identifiziert.",
        "min" : 0,
        "max" : "1",
        "patternIdentifier" : {
          "type" : {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                "code" : "VN"
              }
            ]
          }
        },
        "mustSupport" : true
      },
      {
        "id" : "Encounter.identifier:Aufnahmenummer.type",
        "path" : "Encounter.identifier.type",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.identifier:Aufnahmenummer.type.coding",
        "path" : "Encounter.identifier.type.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.identifier:Aufnahmenummer.type.coding:vn-type",
        "path" : "Encounter.identifier.type.coding",
        "sliceName" : "vn-type",
        "short" : "Codierte Darstellung des Identifier-Typs",
        "min" : 1,
        "max" : "1",
        "patternCoding" : {
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "VN"
        },
        "mustSupport" : true
      },
      {
        "id" : "Encounter.identifier:Aufnahmenummer.type.coding:vn-type.system",
        "path" : "Encounter.identifier.type.coding.system",
        "short" : "Codier-Schema",
        "comment" : "Hier ist stets der Wert `http://terminology.hl7.org/CodeSystem/v2-0203` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.identifier:Aufnahmenummer.type.coding:vn-type.code",
        "path" : "Encounter.identifier.type.coding.code",
        "short" : "Code",
        "comment" : "Hier ist stets der Wert `VN` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.identifier:Aufnahmenummer.system",
        "path" : "Encounter.identifier.system",
        "short" : "Namensraum des Identifiers",
        "comment" : "Hier ist stets der eindeutige Name (URL) des Namensraums anzugeben, \n    aus dem der Identifier stammt. \n    Hinweise zur Festlegung der URLs für lokale Namensräume sind in den \n    [Deutschen Basisprofilen](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Terminologie-Namensraeume?version=current) beschrieben.  \n    **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.identifier:Aufnahmenummer.value",
        "path" : "Encounter.identifier.value",
        "comment" : "Enthält den eigentlichen Wert des Identifiers.  \n    **Begründung Pflichtfeld:** Ist der Wert nicht bekannt, sollte der gesamte Slice weggelassen werden.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.status",
        "path" : "Encounter.status",
        "short" : "Status",
        "comment" : "Zeigt den aktuellen Status der Ressource an.     \n  **WICHTIGER Hinweis für Implementierer:**    \n  * Alle server-seitigen Implementierungen MÜSSEN in der Lage sein, \n  die systemintern möglichen Statuswerte korrekt in FHIR abzubilden, mindestens jedoch die Werte `in-progress`, `finished` und `cancelled`.\n  * Alle client-seitigen Implementierungen MÜSSEN in der Lage sein, sämtliche Status-Codes zu interpretieren und dem Anwender in angemessener Form darstellen zu können, \n  beispielsweise durch Ausblenden/Durchstreichen von Ressourcen mit dem status `entered-in-error` und Ausgrauen von Ressourcen, die einen Plan- oder Entwurfs-Status haben.  \n  **Historie:** Die Reduktion der zulässigen Status-Werte im Vergleich zur FHIR-Kernspezifikation \n  erfolgt im Vorgriff auf eine entsprechende Anpassung in FHIR R5.",
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "description" : "Eingeschränkter Status vgl. FHIR R5",
          "valueSet" : "http://fhir.de/ValueSet/EncounterStatusDe"
        }
      },
      {
        "id" : "Encounter.class",
        "path" : "Encounter.class",
        "short" : "Fallart",
        "comment" : "Die Klassifikation von Encountern nach Fallarten folgt den internationalen Vorgaben und \n  dient der groben Unterscheidung von Besuchen mit und ohne Bettendisposition (ambulant/stationär). \n  Die in Deutschland übliche Fallklassifikation anhand von unterschiedlichen \n  regulatorischen und abrechnungrelevanten Rahmenbedingungen, erfolgt in `type`.  \n  Für ein korrektes Mapping der in Deutschland gebräuchlichen Fallarten auf `class` siehe [Deutsche Basisprofile](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Ressourcen-AmbulanterStationaererFall?version=current)",
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://fhir.de/ValueSet/EncounterClassDE"
        }
      },
      {
        "id" : "Encounter.type",
        "path" : "Encounter.type",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "comment" : "Typ des Encounter",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.type:Kontaktebene",
        "path" : "Encounter.type",
        "sliceName" : "Kontaktebene",
        "short" : "Kontaktebene",
        "comment" : "  **Begründung Pflichtfeld:** Die Abteilungsebene muss aus Kompatibilitätsgründen angegeben werden.\n  \n    **Hinweis bei Abbildung von Versorgungsstellenkontakten:**\n  Es ist ein üblicher Fall, dass die Dauer eines Versorgungsstellenkontaktes in der Versorgung die eines Abteilungskontaktes übersteigt. Ein Beispiel hierfür: Ein Patient bleibt im Bett (Versorgungsstellenkontakt), aber ein Fachabteilungswechsel geschieht, da die Diagnose über eine Fachabteilung (Onkologie) läuft, dann aber der Wechsel zur Fachabteilung Chirurgie (neuer Abteilungskontakt) notwendig wird.\n  Für einen solchen Fall gilt auf Ebene der FHIR-Instanzen (z.B. entgegen des tatsächliche Aufenthaltes im gleichen Bett): Im Falle eines Fachabteilungswechsels legt ein System einen neuen Abteilungskontakt an. Bestehende Versorgungsstellenkontakt SOLLEN NICHT in ihrer Relation (.partOf) zum Abteilungskontakt modifiziert werden. Hingegen SOLL das System einen oder mehrere Versorgungsstellenkontakte erzeugen und mit dem neu angelegten Abteilungskontakt in Verbindung setzen.\n\n  Hintergrund: Das Konzept der 'Kontaktebene' stammt aus dem Fallmodell der Medizininformatik-Initiative, \n    das bei Encountern zwischen 'Einrichtungskontakten', 'Fachabteilungskontakten' und 'Versorgungsstellenkontakten' unterscheidet.\n    Im Kontext dieses Moduls werden lediglich Encounter der Ebene 'Fachabteilungskontakt' abgebildet.\n  \n  ",
        "min" : 1,
        "max" : "1",
        "patternCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://fhir.de/CodeSystem/Kontaktebene",
              "code" : "abteilungskontakt"
            }
          ]
        },
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "description" : "Kontaktebene",
          "valueSet" : "http://fhir.de/ValueSet/kontaktebene-de"
        }
      },
      {
        "id" : "Encounter.type:Kontaktebene.coding",
        "path" : "Encounter.type.coding",
        "short" : "Codierte Darstellung der Kontaktebene"
      },
      {
        "id" : "Encounter.type:Kontaktebene.coding.system",
        "path" : "Encounter.type.coding.system",
        "short" : "Codier-Schema",
        "comment" : "Hier ist stets der Wert `http://fhir.de/CodeSystem/Kontaktebene` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.type:Kontaktebene.coding.code",
        "path" : "Encounter.type.coding.code",
        "short" : "Code",
        "comment" : "Hier ist stets der Wert `abteilungskontakt` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.type:KontaktArt",
        "path" : "Encounter.type",
        "sliceName" : "KontaktArt",
        "short" : "Kontaktart",
        "comment" : "Die Kontaktart dient der feingranularen Differenzierung unterschiedlicher stationärer \n  und ambulanter Fallarten gemäß der in Deutschland üblichen regulatorischen \n  und abrechnungsrelevanten Rahmenbedingungen.  \n  Für ein korrektes Mapping der in Deutschland gebräuchlichen Fallarten auf `type` siehe [Deutsche Basisprofile](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Ressourcen-AmbulanterStationaererFall?version=current)",
        "min" : 0,
        "max" : "1",
        "patternCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://fhir.de/CodeSystem/kontaktart-de"
            }
          ]
        },
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://fhir.de/ValueSet/kontaktart-de"
        }
      },
      {
        "id" : "Encounter.type:KontaktArt.coding",
        "path" : "Encounter.type.coding",
        "short" : "Codierte Darstellung der Kontaktart"
      },
      {
        "id" : "Encounter.type:KontaktArt.coding.system",
        "path" : "Encounter.type.coding.system",
        "short" : "Codier-Schema",
        "comment" : "Hier ist stets der Wert `http://fhir.de/CodeSystem/kontaktart-de` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.type:KontaktArt.coding.code",
        "path" : "Encounter.type.coding.code",
        "short" : "Code",
        "comment" : "vorstationaer | nachstationaer | begleitperson | tagesklinik | +",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.serviceType",
        "path" : "Encounter.serviceType",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.serviceType.coding",
        "path" : "Encounter.serviceType.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.serviceType.coding:Fachabteilungsschluessel",
        "path" : "Encounter.serviceType.coding",
        "sliceName" : "Fachabteilungsschluessel",
        "short" : "Fachabteilungsschlüssel",
        "comment" : "Fachabteilungen gemäß Anhang 1 der BPflV",
        "min" : 0,
        "max" : "1",
        "patternCoding" : {
          "system" : "http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel"
        },
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://fhir.de/ValueSet/dkgev/Fachabteilungsschluessel"
        }
      },
      {
        "id" : "Encounter.serviceType.coding:ErweiterterFachabteilungsschluessel",
        "path" : "Encounter.serviceType.coding",
        "sliceName" : "ErweiterterFachabteilungsschluessel",
        "short" : "Fachabteilungsschlüssel",
        "comment" : "Fachabteilungen gemäß Anhang 1 der BPflV inkl. Spezialisierungen",
        "min" : 0,
        "max" : "1",
        "patternCoding" : {
          "system" : "http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel-erweitert"
        },
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://fhir.de/ValueSet/dkgev/Fachabteilungsschluessel-erweitert"
        }
      },
      {
        "id" : "Encounter.subject",
        "path" : "Encounter.subject",
        "short" : "Patientenbezug",
        "comment" : "**Begründung Must-Support:** Ein Patientenbezug des Kontakt MUSS stets zum Zwecke der Nachvollziehbarkeit und Datenintegrität vorliegen.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.subject.reference",
        "path" : "Encounter.subject.reference",
        "short" : "Patienten-Link",
        "comment" : "**Begründung Pflichtfeld:** Die Verlinkung auf eine Patienten-Ressource dient der technischen Zuordnung der Dokumentation zu einem Patienten \n      und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.appointment",
        "path" : "Encounter.appointment",
        "short" : "Verknüpfung mit einem Termin",
        "comment" : "\n  \n**Begründung und Einschränkung des Must Support**: Dieses Element dient der Verknüpfung mit einem Termin (Appointment) aus dem entsprechenden ISiK Modul und - darauf aufbauend - der Dokumentenkommunikation. Das Element 'appointment' SOLL für den im Folgenden geschilderten Fall implementiert werden. Andernfalls KANN es entfallen. \n\nDie Anforderung einer Verknüpfung mit einem Appointment stammt aus dem Szenario der Dokumentenübertragung zwischen Patientenportal und krankenhaus-internem Primärsystem (z.B. KIS) im Kontext einer Terminbuchung: Dokumente liegen bei Terminbuchung erst im Patientenportal (im Appointment) vor und werden erst mit Anlage des Encounters in das KIS (etc.) übermittelt. Dazu SOLL ein Primärsystem zu Beginn des Termins das Appointment mit dem neu angelegten Encounter verknüpfen, um die Dokumente aus dem Patientenportal darüber vermittelt zuordnen zu können (ausgenommen hiervon sind Termine, die nicht stattfinden, da für diese in der Regel keine Encounter angelegt werden).\n\nÜber die Referenz auf Appointment KÖNNEN Patientenportale den Fallbezug aus dem Termin ermitteln und Dokumente an ein KIS senden.\n\nHieraus folgt, dass das Element nur relevant ist, falls das bestätigungsrelevante System zusätzlich zum vorliegenden Profil (Encounter) das Profil ISiKTermin (Appointment) implementiert.\n\n**Hinweis:**  Zur Umsetzung der Funktionalität zum Dokumentenaustausch gemäß ISiK ist der entsprechende [Implementation Guide zum Modul Dokumentenaustausch](https://simplifier.net/guide/isik-dokumentenaustausch-stufe-5) zu beachten.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.period",
        "path" : "Encounter.period",
        "short" : "Aufenthaltszeitraum",
        "comment" : "**WICHTIGER Hinweis für Implementierer:** \n  * Das Aufnahmedatum  MUSS angegeben werden, \n  wenn der `status` des Encounters impliziert, dass dieser bereits begonnen hat.\n  * Das Entlassdatum MUSS angegeben werden, \n  wenn der `status` des Encounters impliziert, dass dieser beendet ist.  \n  Siehe hierzu die Übersicht der Invarianten in diesem Profil. ",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.period.start",
        "path" : "Encounter.period.start",
        "short" : "Aufnahmedatum",
        "comment" : "Hier ist stets das *tatsächliche* Aufnahmedatum anzugeben.\n    *Geplante* Aufnahmedaten müssen über die Extension `plannedStartDate` erfasst werden.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.period.end",
        "path" : "Encounter.period.end",
        "short" : "Entlassdatum",
        "comment" : "Hier ist stets das *tatsächliche* Entlassdatum anzugeben.\n    *Geplante* Entlassdaten müssen über die Extension `plannedEndDate` erfasst werden.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.diagnosis",
        "path" : "Encounter.diagnosis",
        "short" : "Falldiagnosen/-prozeduren",
        "comment" : "Verweis auf Diagnosen/Prozeduren, die eine besondere Rolle im Kontext eines Encounters einnehmen, z.B. 'Aufnahmediagnose'   \n  **WICHTIGER Hinweis für Implementierer:**   Der Fallbezug von Diagnosen und Prozeduren wird über das jeweilige `encounter`-Element \n  der Condition bzw. Procedure-Ressource hinreichend etabliert.  Die *zusätzliche* Rückverlinkung von `Encounter.diagnosis` auf Condition/Procedure wird *nur dann* verwendet, \n  wenn einer Diagnose bzw. Prozedur *im Kontext eines Aufenthaltes* eine besondere Rolle zugewiesen werden soll, z.B. Haupt-/Neben-/Aufnahme- oder Überweisungsdiagnose).  \n  Hier werden Diagnosen und Prozeduren nur nach ihrer *medizinschen* Relevanz bezüglich eines Aufenthaltes qualifiziert. \n  Die Qualifikation von Diagnosen und Prozeduren im Kontext der *Abrechnung* erfolgt in der `Account`-Ressource!"
      },
      {
        "id" : "Encounter.diagnosis.condition",
        "path" : "Encounter.diagnosis.condition",
        "short" : "Verweis auf Diagnose/Prozedur",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.diagnosis.condition.reference",
        "path" : "Encounter.diagnosis.condition.reference",
        "short" : "Condition/Procedure-Link",
        "comment" : "**Begründung Pflichtfeld:** Die Verlinkung auf die Condition/Procedure-Ressource dient der technischen Zuordnung des Encounters zur Condition/Precedure \n  und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.diagnosis.use",
        "path" : "Encounter.diagnosis.use",
        "short" : "Bedeutung der Diagnose/Prozedur",
        "comment" : "Bedeutung der Diagnose/Prozedur im Encounter-Kontext",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.diagnosis.use.coding",
        "path" : "Encounter.diagnosis.use.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.diagnosis.use.coding:Diagnosetyp",
        "path" : "Encounter.diagnosis.use.coding",
        "sliceName" : "Diagnosetyp",
        "short" : "Diagnosetyp",
        "comment" : "International standardisierte, grobgranulare Unterscheidung zwischen extern gestellten Diagnosen (`referral-diagnosis`) und intern gestellten Diagnosen (`treatment-diagnosis`)",
        "min" : 1,
        "max" : "1",
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://fhir.de/ValueSet/DiagnoseTyp"
        }
      },
      {
        "id" : "Encounter.diagnosis.use.coding:DiagnosesubTyp",
        "path" : "Encounter.diagnosis.use.coding",
        "sliceName" : "DiagnosesubTyp",
        "short" : "Diagnosesubtyp",
        "comment" : "An deutschen Kodierrichtlinien orientierte, feingranulare Unterscheidung von Diagnose-Rollen, \n      z.B. 'Fachabteilungshauptdiagnose', 'Todesursache' etc.",
        "min" : 0,
        "max" : "*",
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://fhir.de/ValueSet/Diagnosesubtyp"
        }
      },
      {
        "id" : "Encounter.diagnosis.rank",
        "path" : "Encounter.diagnosis.rank",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.account",
        "path" : "Encounter.account",
        "short" : "Abrechnungskontext",
        "comment" : "Der Bezug zu einem Account stellt den Abrechnungskontext für einen oder mehrere Encounter her.\n  Mittels der Account-Referenz können zum Beispiel ein vorstationärer, ein stationärer \n  und ein nachstationärer Besuch zu einem 'DRG-Fall' zusammengefasst werden.  \n  **WICHTIGER Hinweis für Implementierer:** Im Deutschen Sprachgebrauch ist unter dem Begriff 'Fall' \n  meist der Abrechnungskontext gemeint, nicht der einzelne Besuch. Die 'Fallnummer' ist daher nicht der Identifier des Encounters, \n  sondern der des Accounts auf den der Encounter referenziert. \n  Auf diesem Wege können mehrere Besuche einer Fallnummer zugeordnet werden.  \n  Da die Fallnummer ein häufig verwendetes Suchkriterium darstellt, \n  ist diese hier als logische Referenz (`account.identifier`) zu hinterlegen.\n  Damit wird sichergestellt, dass diese als Suchparameter für die Suche nach Encountern zur Verfügung steht, \n  auch wenn einzelne Systeme kein Chaining unterstützen oder einzelne Benutzer keine Sichtberechtigung auf Abrechnungsdaten haben,\n  im Versorgunskontext aber dennoch Encounter anhand der assoziierten Fallnummer suchen möchten.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.account.reference",
        "path" : "Encounter.account.reference",
        "short" : "Account-Link",
        "comment" : "**Begründung MS:** Die Verlinkung auf eine Account-Ressource dient der technischen Zuordnung des Besuchs zu einem Abrechnungskontext \n  und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.account.identifier",
        "path" : "Encounter.account.identifier",
        "short" : "(Abrechnungs-)Fallnummer",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.account.identifier.system",
        "path" : "Encounter.account.identifier.system",
        "short" : "Namensraum des Identifiers",
        "comment" : "Hier ist stets der eindeutige Name (URL) des Namensraums anzugeben, \n      aus dem der Identifier stammt. \n      Hinweise zur Festlegung der URLs für lokale Namensräume sind in den \n      [Deutschen Basisprofilen](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Terminologie-Namensraeume?version=current) beschrieben.  \n      **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.account.identifier.value",
        "path" : "Encounter.account.identifier.value",
        "comment" : "Enthält den eigentlichen Wert des Identifiers.  \n        **Begründung Pflichtfeld:** Ist der Wert nicht bekannt, sollte der gesamte Slice weggelassen werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.hospitalization",
        "path" : "Encounter.hospitalization",
        "short" : "Details zum Aufenthalt",
        "comment" : "Details zu einem stationären Aufenthalt",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.hospitalization.extension",
        "path" : "Encounter.hospitalization.extension",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "url"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        }
      },
      {
        "id" : "Encounter.hospitalization.extension:Wahlleistung",
        "path" : "Encounter.hospitalization.extension",
        "sliceName" : "Wahlleistung",
        "short" : "Wahlleistung",
        "comment" : "**Begründung MS:**  Vom Patienten gebuchte Wahlleistungen (z.B. Chefarztbehandlung, Einzelzimmer) \n    sind häufig system- und abteilungsübergreifend zu beachten und sollten daher über die Schnittstelle kommuniziert werden können.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Extension",
            "profile" : ["http://fhir.de/StructureDefinition/Wahlleistung"]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Encounter.hospitalization.admitSource",
        "path" : "Encounter.hospitalization.admitSource",
        "short" : "Aufnahmeanlass",
        "comment" : "Anlass der stationären Aufnahme, z.B. 'Einweisung', 'Notfall' etc.  \n      Begründung MS: Zur Harmonisierung den Festlegungen der Medizininformatik-Initiative",
        "mustSupport" : true,
        "binding" : {
          "strength" : "extensible",
          "valueSet" : "http://fhir.de/ValueSet/dgkev/Aufnahmeanlass"
        }
      },
      {
        "id" : "Encounter.hospitalization.dischargeDisposition",
        "path" : "Encounter.hospitalization.dischargeDisposition",
        "short" : "Entlassungsart bzw. -grund",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.hospitalization.dischargeDisposition.extension:Entlassungsgrund",
        "path" : "Encounter.hospitalization.dischargeDisposition.extension",
        "sliceName" : "Entlassungsgrund",
        "short" : "Entlassungsgrund",
        "comment" : "Entlassungsgrund nach § 301 Abs. 3 SGB V  \n        **Einschränkung MS:** Der Entlassungsgrund muss nur implementiert werden,\n         wenn das bestätigungsrelevante System in der Akutversorgung eingesetzt wird.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : ["http://fhir.de/StructureDefinition/Entlassungsgrund"]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Encounter.hospitalization.dischargeDisposition.extension:RehaEntlassung",
        "path" : "Encounter.hospitalization.dischargeDisposition.extension",
        "sliceName" : "RehaEntlassung",
        "short" : "Entlassungsgrund Reha",
        "comment" : "Entlassungsgrund nach §301 (Abs. 4 und 4a) SGB V  \n      **Einschränkung MS:** Der Entlassungsgrund Reha muss nur implementiert werden,\n        wenn das bestätigungsrelevante System in der Reha-Versorgung eingesetzt wird",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/ExtensionISiKRehaEntlassung"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location",
        "path" : "Encounter.location",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "physicalType"
            },
            {
              "type" : "pattern",
              "path" : "status"
            }
          ],
          "rules" : "open"
        },
        "short" : "Aufenthaltsorte des Patienten",
        "comment" : "Hinweise zur Einschränkung von Encounter.location.status auf \"active\" zu Abbildung des aktuellen Aufenthaltortes des Patienten\nDie Slices `Station`, `Zimmer` und `Bettenstellplatz` verwenden jeweils ein Pattern auf dem status-Element mit dem Wert 'active'.\nDiese Einschränkung dient der sicheren Abbildung des aktuellen Aufenthaltsortes und soll garantieren, dass – wenn bekannt – stets nur ein aktueller Standort dokumentiert wird.\n\nGleichwohl erlaubt die offene Slicing-Strategie (`slicing.rules = open`), dass **weitere Slices mit abweichenden `status`-Werten** (z. B. `planned`, `reserved`, `completed`) verwendet werden dürfen.  \nDamit ist es möglich, zusätzlich auch historische oder geplante Aufenthaltsorte zu dokumentieren, sofern diese Information erfasst wird. Bei Verlegungen in einen anderen Fachbereich, welcher auch einen Wechsel des Aufenthaltsortes zur Folge hat, SOLL der Status der Location auf 'completed' gesetzt werden.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location.physicalType",
        "path" : "Encounter.location.physicalType",
        "binding" : {
          "strength" : "extensible",
          "valueSet" : "https://gematik.de/fhir/isik/ValueSet/ISiKLocationPhysicalType"
        }
      },
      {
        "id" : "Encounter.location:Zimmer",
        "path" : "Encounter.location",
        "sliceName" : "Zimmer",
        "short" : "Slice für das aktive Zimmer",
        "comment" : "**Begründung MS:** Die Kenntnis des aktuellen Aufenthaltsortes ist häufig systemübergreifend relevant (z.B. für Küchen- und Logistiksysteme) und sollte daher über die Schnittstelle kommuniziert werden können.",
        "min" : 0,
        "max" : "1",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.location",
        "path" : "Encounter.location.location",
        "short" : "Aufenthaltsort",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.location.reference",
        "path" : "Encounter.location.location.reference",
        "short" : "Location-Link",
        "comment" : "**Begründung MS:** Die Verlinkung auf eine Location-Ressource dient der technischen Zuordnung des Besuchs zu einem Aufenthaltsort \n    und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.location.identifier",
        "path" : "Encounter.location.location.identifier",
        "short" : "Identifier des Aufenthaltsortes",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.location.identifier.system",
        "path" : "Encounter.location.location.identifier.system",
        "short" : "Namensraum des Identifiers",
        "comment" : "Hier ist stets der eindeutige Name (URL) des Namensraums anzugeben, \n    aus dem der Identifier stammt. \n    Hinweise zur Festlegung der URLs für lokale Namensräume sind in den \n    [Deutschen Basisprofilen](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Terminologie-Namensraeume?version=current) beschrieben.  \n    **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher. Darüber hinaus ermöglicht es der Identifier, die Suche (z.B. von aktuellen Aufenthalten auf einer Station) mittels `/Encounter?location:identifier=XXX` auch dann zu nutzen, wenn keine Verlinkung auf eine Location-Ressource vorhanden ist. Auf `location.display` ist im Standard derzeit kein Suchparameter definiert.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.location.identifier.value",
        "path" : "Encounter.location.location.identifier.value",
        "comment" : "Enthält den eigentlichen Wert des Identifiers.  \n      **Begründung Pflichtfeld:** Ist der Wert nicht bekannt, sollte der gesamte Slice weggelassen werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.location.display",
        "path" : "Encounter.location.location.display",
        "short" : "(Menschenlesbarer) Name des Aufenthaltsortes",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.status",
        "path" : "Encounter.location.status",
        "min" : 1,
        "patternCode" : "active",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.physicalType",
        "path" : "Encounter.location.physicalType",
        "short" : "Art des Aufenthaltsortes (hier: Zimmer)",
        "min" : 1,
        "patternCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
              "code" : "ro"
            }
          ]
        },
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.physicalType.coding",
        "path" : "Encounter.location.physicalType.coding",
        "short" : "Codierte Darstellung der Art des Aufenthaltortes"
      },
      {
        "id" : "Encounter.location:Zimmer.physicalType.coding.system",
        "path" : "Encounter.location.physicalType.coding.system",
        "short" : "Codier-Schema",
        "comment" : "Hier ist stets der Wert `http://terminology.hl7.org/CodeSystem/location-physical-type` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Zimmer.physicalType.coding.code",
        "path" : "Encounter.location.physicalType.coding.code",
        "short" : "Code",
        "comment" : "Hier ist stets der Wert `ro` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz",
        "path" : "Encounter.location",
        "sliceName" : "Bettenstellplatz",
        "short" : "Slice für das aktive Bett",
        "comment" : "**Begründung MS:** Die Kenntnis des aktuellen Aufenthaltsortes ist häufig systemübergreifend relevant (z.B. für Küchen- und Logistiksysteme) und sollte daher über die Schnittstelle kommuniziert werden können.",
        "min" : 0,
        "max" : "1",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.location",
        "path" : "Encounter.location.location",
        "short" : "Aufenthaltsort",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.location.reference",
        "path" : "Encounter.location.location.reference",
        "short" : "Location-Link",
        "comment" : "**Begründung MS:** Die Verlinkung auf eine Location-Ressource dient der technischen Zuordnung des Besuchs zu einem Aufenthaltsort \n    und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.location.identifier",
        "path" : "Encounter.location.location.identifier",
        "short" : "Identifier des Aufenthaltsortes",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.location.identifier.system",
        "path" : "Encounter.location.location.identifier.system",
        "short" : "Namensraum des Identifiers",
        "comment" : "Hier ist stets der eindeutige Name (URL) des Namensraums anzugeben, \n    aus dem der Identifier stammt. \n    Hinweise zur Festlegung der URLs für lokale Namensräume sind in den \n    [Deutschen Basisprofilen](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Terminologie-Namensraeume?version=current) beschrieben.  \n    **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher. Darüber hinaus ermöglicht es der Identifier, die Suche (z.B. von aktuellen Aufenthalten auf einer Station) mittels `/Encounter?location:identifier=XXX` auch dann zu nutzen, wenn keine Verlinkung auf eine Location-Ressource vorhanden ist. Auf `location.display` ist im Standard derzeit kein Suchparameter definiert.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.location.identifier.value",
        "path" : "Encounter.location.location.identifier.value",
        "comment" : "Enthält den eigentlichen Wert des Identifiers.  \n      **Begründung Pflichtfeld:** Ist der Wert nicht bekannt, sollte der gesamte Slice weggelassen werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.location.display",
        "path" : "Encounter.location.location.display",
        "short" : "(Menschenlesbarer) Name des Aufenthaltsortes",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.status",
        "path" : "Encounter.location.status",
        "min" : 1,
        "patternCode" : "active",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.physicalType",
        "path" : "Encounter.location.physicalType",
        "short" : "Art des Aufenthaltsortes (hier: Bettenstellplatz)",
        "comment" : "Die Kodierung in diesem Slice entstammt folgendem Valueset - gelistet unter .location.(All slices.)physicalType: https://gematik.de/fhir/isik/ValueSet/ISiKLocationPhysicalType",
        "min" : 1,
        "patternCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
              "code" : "bd"
            }
          ]
        },
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.physicalType.coding",
        "path" : "Encounter.location.physicalType.coding",
        "short" : "Codierte Darstellung der Art des Aufenthaltortes"
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.physicalType.coding.system",
        "path" : "Encounter.location.physicalType.coding.system",
        "short" : "Codier-Schema",
        "comment" : "Hier ist stets der Wert `http://terminology.hl7.org/CodeSystem/location-physical-type` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Bettenstellplatz.physicalType.coding.code",
        "path" : "Encounter.location.physicalType.coding.code",
        "short" : "Code",
        "comment" : "Hier ist stets der Wert `bd` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station",
        "path" : "Encounter.location",
        "sliceName" : "Station",
        "short" : "Slice für die aktive Station",
        "comment" : "**Begründung MS:** Die Kenntnis des aktuellen Aufenthaltsortes ist häufig systemübergreifend relevant (z.B. für Küchen- und Logistiksysteme) und sollte daher über die Schnittstelle kommuniziert werden können.",
        "min" : 0,
        "max" : "1",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.location",
        "path" : "Encounter.location.location",
        "short" : "Aufenthaltsort",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.location.reference",
        "path" : "Encounter.location.location.reference",
        "short" : "Location-Link",
        "comment" : "**Begründung MS:** Die Verlinkung auf eine Location-Ressource dient der technischen Zuordnung des Besuchs zu einem Aufenthaltsort \n    und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.location.identifier",
        "path" : "Encounter.location.location.identifier",
        "short" : "Identifier des Aufenthaltsortes",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.location.identifier.system",
        "path" : "Encounter.location.location.identifier.system",
        "short" : "Namensraum des Identifiers",
        "comment" : "Hier ist stets der eindeutige Name (URL) des Namensraums anzugeben, \n    aus dem der Identifier stammt. \n    Hinweise zur Festlegung der URLs für lokale Namensräume sind in den \n    [Deutschen Basisprofilen](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Terminologie-Namensraeume?version=current) beschrieben.  \n    **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher. Darüber hinaus ermöglicht es der Identifier, die Suche (z.B. von aktuellen Aufenthalten auf einer Station) mittels `/Encounter?location:identifier=XXX` auch dann zu nutzen, wenn keine Verlinkung auf eine Location-Ressource vorhanden ist. Auf `location.display` ist im Standard derzeit kein Suchparameter definiert.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.location.identifier.value",
        "path" : "Encounter.location.location.identifier.value",
        "comment" : "Enthält den eigentlichen Wert des Identifiers.  \n      **Begründung Pflichtfeld:** Ist der Wert nicht bekannt, sollte der gesamte Slice weggelassen werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.location.display",
        "path" : "Encounter.location.location.display",
        "short" : "(Menschenlesbarer) Name des Aufenthaltsortes",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.status",
        "path" : "Encounter.location.status",
        "min" : 1,
        "patternCode" : "active",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.physicalType",
        "path" : "Encounter.location.physicalType",
        "short" : "Art des Aufenthaltsortes (hier: Station)",
        "min" : 1,
        "patternCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
              "code" : "wa"
            }
          ]
        },
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.physicalType.coding",
        "path" : "Encounter.location.physicalType.coding",
        "short" : "Codierte Darstellung der Art des Aufenthaltortes"
      },
      {
        "id" : "Encounter.location:Station.physicalType.coding.system",
        "path" : "Encounter.location.physicalType.coding.system",
        "short" : "Codier-Schema",
        "comment" : "Hier ist stets der Wert `http://terminology.hl7.org/CodeSystem/location-physical-type` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.location:Station.physicalType.coding.code",
        "path" : "Encounter.location.physicalType.coding.code",
        "short" : "Code",
        "comment" : "Hier ist stets der Wert `wa` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.serviceProvider",
        "path" : "Encounter.serviceProvider",
        "short" : "Zuständige ServiceProvider",
        "comment" : "**Begründung MS:** Der zuständige ServiceProvider für diesen Kontakt sollte hier angegeben werden.",
        "mustSupport" : true
      },
      {
        "id" : "Encounter.serviceProvider.identifier",
        "path" : "Encounter.serviceProvider.identifier",
        "comment" : "**Begründung Pflichtfeld:** Ein eindeutiger Identifier des ServiceProvider muss vorhanden sein.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Encounter.serviceProvider.display",
        "path" : "Encounter.serviceProvider.display",
        "comment" : "**Begründung MS:** Ein Anzeigename für den ServiceProvider muss vorhanden sein.",
        "min" : 1,
        "mustSupport" : true
      }
    ]
  }
}

```
