# ISiKProzedur - AMTS ISiK Implementation Guide v0.0.1

AMTS ISiK Implementation Guide

Version 0.0.1 - STU1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ISiKProzedur**

## Resource Profile: ISiKProzedur 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKProzedur | *Version*:0.0.1 |
| Active as of 2025-12-17 | *Computable Name*:ISiKProzedur |

 
Dieses Profil spezifiziert die Minimalanforderungen für die Bereitstellung von Informationen über die Behandlungen/Prozeduren eines Patienten im Rahmen des Bestätigungsverfahrens der gematik. 

### Motivation

 
Die Möglichkeit auf eine Übersicht der Prozeduren eines Patienten zuzugreifen, Patienten anhand durchgeführter oder geplanter Prozeduren zu suchen, oder zu prüfen, ob eine konkrete Prozedur bei einem Patienten durchgeführt wurde, sind wichtige Funktionen im klinischen Behandlungsablauf. 
In FHIR werden Prozeduren mit der Procedure-Ressource repräsentiert. 
Da die Prozeduren in klinischen Primärsystemen, in der Regel, in OPS-codierter Form vorliegen, fordert ISiK in erster Linie diese Form des Austausches. Falls eine Prozedur zwar dokumentiert aber noch nicht codiert wurde (z.B. wenn die Kodierung erst nach der Entlassung erfolgt), ist alternativ eine Repräsentation als Freitext-Prozedur möglich. 

### Kompatibilität

 
Für das Profil ISIKProzedur wird eine Kompatibilität mit folgenden Profilen angestrebt; allerdings kann nicht sichergestellt werden, dass Instanzen, die gegen ISIKProzedur valide sind, auch valide sind gegen: 
* [Profil Prozedur](https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Procedure) der Medizininformatik Initiative
 Hinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden.
 

**Usages:**

* Examples for this Profile: [Procedure/Appendektomie](Procedure-Appendektomie.md)
* CapabilityStatements using this Profile: [ISiK CapabilityStatement AMTS Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementAMTSAkteur-expanded.md) and [CapabilityStatement für Rolle "ISiKCapabilityStatementKlinischeRolle"](CapabilityStatement-ISiKCapabilityStatementKlinischeRolle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/amts.test.ig|current/StructureDefinition/ISiKProzedur)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ISiKProzedur.csv), [Excel](StructureDefinition-ISiKProzedur.xlsx), [Schematron](StructureDefinition-ISiKProzedur.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKProzedur",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKProzedur",
  "version" : "0.0.1",
  "name" : "ISiKProzedur",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-17",
  "description" : "Dieses Profil spezifiziert die Minimalanforderungen für die Bereitstellung von Informationen über die Behandlungen/Prozeduren eines Patienten im Rahmen des Bestätigungsverfahrens der gematik.\n### Motivation\nDie Möglichkeit auf eine Übersicht der Prozeduren eines Patienten zuzugreifen, Patienten anhand durchgeführter oder geplanter Prozeduren zu suchen, oder zu prüfen, ob eine konkrete Prozedur bei einem Patienten durchgeführt wurde, sind wichtige Funktionen im klinischen Behandlungsablauf.\n\nIn FHIR werden Prozeduren mit der Procedure-Ressource repräsentiert.\n\nDa die Prozeduren in klinischen Primärsystemen, in der Regel, in OPS-codierter Form vorliegen, fordert ISiK in erster Linie diese Form des Austausches. Falls eine Prozedur zwar dokumentiert aber noch nicht codiert wurde (z.B. wenn die Kodierung erst nach der Entlassung erfolgt), ist alternativ eine Repräsentation als Freitext-Prozedur möglich.\n\n### Kompatibilität\nFür das Profil ISIKProzedur wird eine Kompatibilität mit folgenden Profilen angestrebt; allerdings kann nicht sichergestellt werden, dass Instanzen, die gegen ISIKProzedur valide sind, auch valide sind gegen:\n\n* [Profil Prozedur](https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Procedure) der Medizininformatik Initiative  \nHinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden.",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Procedure",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Procedure",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Procedure",
        "path" : "Procedure",
        "constraint" : [
          {
            "key" : "proc-ISiK-1",
            "severity" : "error",
            "human" : "Falls die Prozedur per OPS kodiert wird, MUSS eine SNOMED-CT kodierte Category abgebildet werden",
            "expression" : "code.coding.where(system = 'http://fhir.de/CodeSystem/bfarm/ops').exists() implies category.coding.where(system = 'http://snomed.info/sct').exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKProzedur"
          },
          {
            "key" : "proc-ISiK-2",
            "severity" : "error",
            "human" : "Falls eine codierte Prozedur vorliegt MUSS eine kodierte Category abgebildet werden",
            "expression" : "code.coding.exists() implies category.coding.exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKProzedur"
          }
        ]
      },
      {
        "id" : "Procedure.id",
        "path" : "Procedure.id",
        "short" : "serverseitige, interne ID des Datensatzes",
        "comment" : "**bedingtes Pflichtfeld/bedingtes MS:** Alle von einem Server bereitgestellten Ressourcen MÜSSEN über eine `id` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `id`verfügen. ",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.meta.versionId",
        "path" : "Procedure.meta.versionId",
        "short" : "Eindeutiger Name der serverseitigen Version des Datensatzes",
        "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über eine `versionID` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `versionID`verfügen. "
      },
      {
        "id" : "Procedure.meta.lastUpdated",
        "path" : "Procedure.meta.lastUpdated",
        "short" : "Zeitpunkt der letzten Änderung",
        "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über ein `lastUpdate` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über ein `lastUpdate`verfügen. "
      },
      {
        "id" : "Procedure.extension",
        "path" : "Procedure.extension",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "url"
            }
          ],
          "rules" : "open"
        },
        "mustSupport" : true
      },
      {
        "id" : "Procedure.extension:Dokumentationsdatum",
        "path" : "Procedure.extension",
        "sliceName" : "Dokumentationsdatum",
        "short" : "Dokumentationsdatum",
        "comment" : "Datum, an dem die Prozedur dokumentiert wurde.  \n  Es handelt sich hierbei um das fachliche Dokumentationsdatum, nicht zu verwechseln mit dem Datum der technischen Anlage des Datensatzes im Primärsystem. \n  Diese beiden Daten *können* jedoch identisch sein.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Procedure.status",
        "path" : "Procedure.status",
        "short" : "Status",
        "comment" : "Zeigt den aktuellen Status der Prozedur an.     \n  **WICHTIGER Hinweis für Implementierer:  \n  * Alle server-seitigen Implementierungen MÜSSEN in der Lage sein, \n  die systemintern möglichen Statuswerte korrekt in FHIR abzubilden, mindestens jedoch die Werte `completed` und `unknown`.\n  * Alle client-seitigen Implementierungen MÜSSEN in der Lage sein, sämtliche Status-Codes zu interpretieren und dem Anwender in angemessener Form darstellen zu können, \n  beispielsweise durch Ausblenden/Durchstreichen von Prozeduren mit dem status `entered-in-error` und Ausgrauen von Prozeduren, die noch nicht stattgefunden haben, o.ä.",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.category",
        "path" : "Procedure.category",
        "short" : "Kategorie",
        "comment" : "Die Kategorisierung erfolgt vorzugsweise auf Basis von SNOMED CT. Für OPS-codierte Prozeduren MUSS die Kategorie angegeben werden: Sie kann ermittelt werden, \n  indem das erste Zeichen des OPS-Codes mit Hilfe einer [ConceptMap](http://fhir.de/ConceptMap/OPS-SNOMED-Category) auf die zutreffende SNOMED-Kategorie gemappt wird.\n  \n  **Begründung MS:** Die Kategorisierung dient der Verbesserung von Suche und Darstellung.",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.category.coding",
        "path" : "Procedure.category.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "system"
            }
          ],
          "rules" : "open"
        }
      },
      {
        "id" : "Procedure.category.coding:SNOMED-CT",
        "path" : "Procedure.category.coding",
        "sliceName" : "SNOMED-CT",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Coding",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/ISiKSnomedCTCoding"
            ]
          }
        ],
        "mustSupport" : true,
        "binding" : {
          "strength" : "preferred",
          "valueSet" : "https://gematik.de/fhir/isik/ValueSet/ProzedurenKategorieSCT"
        }
      },
      {
        "id" : "Procedure.code",
        "path" : "Procedure.code",
        "short" : "Prozeduren-Code",
        "comment" : "Prozeduren SOLLEN mindestens entweder mit einem OPS-Code oder einem SNOMED-Code aus dem angegebenen ValueSet codiert werden. \n  Ist keine Codierung möglich, MUSS statt dessen eine textuelle Beschreibung der Prozedur angegeben werden.  \n  **Begründung Pflichtfeld:** Ist *weder* eine Codierung *noch* eine textuelle Beschreibung vorhanden, besitzt diese Ressource keine medizinische Aussagefähigkeit.",
        "min" : 1,
        "constraint" : [
          {
            "key" : "sct-ops-1",
            "severity" : "error",
            "human" : "Falls die Prozedur kodiert vorliegt, SOLL mindestens ein OPS oder SNOMED-CT Code angegeben werden.",
            "expression" : "coding.exists() implies coding.where(system = 'http://snomed.info/sct').exists() or coding.where(system = 'http://fhir.de/CodeSystem/bfarm/ops').exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKProzedur"
          },
          {
            "key" : "proc-ISiK-3",
            "severity" : "error",
            "human" : "Entweder MUSS eine kodierte Prozedur vorliegen oder eine textuelle Beschreibung. Stattdessen nur Extensions hinzuzufügen (vgl. https://www.hl7.org/fhir/element.html - ele-1), ist explizit nicht erlaubt.",
            "expression" : "coding.exists().not() implies text.exists()",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKProzedur"
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Procedure.code.coding",
        "path" : "Procedure.code.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "system"
            }
          ],
          "rules" : "open"
        },
        "short" : "Codierte Darstellung der Prozedur",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.code.coding:OPS",
        "path" : "Procedure.code.coding",
        "sliceName" : "OPS",
        "short" : "OPS-codierte Darstellung der Prozedur",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Coding",
            "profile" : ["http://fhir.de/StructureDefinition/CodingOPS"]
          }
        ],
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://fhir.de/ValueSet/bfarm/ops"
        }
      },
      {
        "id" : "Procedure.code.coding:OPS.extension:Seitenlokalisation",
        "path" : "Procedure.code.coding.extension",
        "sliceName" : "Seitenlokalisation",
        "short" : "Seitenlokalisation",
        "comment" : "**Begründung MS:** Bei OPS-codierten Prozeduren an paarigen Organen oder Körperteilen müssen die Zusatzkennzeichen für die Seitigkeit (R, L oder B) angeben werden",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.code.coding:OPS.system",
        "path" : "Procedure.code.coding.system",
        "short" : "Namensraum des Prozeduren-Codes",
        "comment" : "Hier ist stets der Wert `http://fhir.de/CodeSystem/bfarm/ops` anzugeben.",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.code.coding:OPS.version",
        "path" : "Procedure.code.coding.version",
        "short" : "Die Jahresversion des OPS Kataloges. Angegeben wird immer die vierstellige Jahreszahl (z.B. `2017`)",
        "comment" : "**Begründung Pflichtfeld:** Bei Verwendung von OPS ist die Angabe der Version zwingend erforderlich. \n      Hierdurch wird der Tatsache Rechnung getragen, dass jede der jährlich neu erscheinenden Fassung von OPS ein neues Codesystem darstellt.",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.code.coding:OPS.code",
        "path" : "Procedure.code.coding.code",
        "short" : "OPS-Code",
        "comment" : "Hier ist der OPS-Code ohne jegliche Zusatzkennzeichen (z.B. Seitenlokalisation) oder Versionsnummern anzugeben.",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.code.coding:SNOMED-CT",
        "path" : "Procedure.code.coding",
        "sliceName" : "SNOMED-CT",
        "short" : "SNOMED-codierte Darstellung der Prozedur",
        "comment" : "**Hintergrund und Begründung zum Must-Support:** Das BfArM hat ein 'Zielbild für eine semantische Strategie' (https://www.bfarm.de/DE/Kodiersysteme/Services/Terminologieserver/Semantik-Strategie/_node.html) verfasst, in dem die Nutzung von international gängigen Basis-Terminologien vorgestellt wird. Dort wird als grundlegende Position dargestellt, dass basierend auf einer Basisterminologie weitere Use Cases bedient werden sollen. Bei Prozeduren wäre das damit eine klinische Dokumentation mit SNOMED CT als internationalem Kodiersystem und einer Ableitung davon zum OPS. Dies ist insbesondere auch wichtig für den Datentransfer in den European Health Data Space, in dem der OPS keine Rolle spielen wird.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Coding",
            "profile" : [
              "https://gematik.de/fhir/isik/StructureDefinition/ISiKSnomedCTCoding"
            ]
          }
        ],
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://gematik.de/fhir/isik/ValueSet/ProzedurenCodesSCT"
        }
      },
      {
        "id" : "Procedure.code.text",
        "path" : "Procedure.code.text",
        "short" : "Freitextiche Beschreibung der Prozedur",
        "comment" : "Die freitextliche Beschreibung kann ergänzend oder anstelle einer codierten Angabe der Prozedur erfolgen.",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.subject",
        "path" : "Procedure.subject",
        "short" : "Patientenbezug",
        "comment" : "**Begründung Must-Support:** Ein Patientenbezug der Prozedur MUSS stets zum Zwecke der Nachvollziehbarkeit und Datenintegrität vorliegen.",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.subject.reference",
        "path" : "Procedure.subject.reference",
        "short" : "Patienten-Link",
        "comment" : "**Begründung MS:** Die Verlinkung auf eine Patienten-Ressource dient der technischen Zuordnung der Dokumentation zu einem Patienten und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.\nIm ISik Kontext MUSS die referenzierte Ressource konform zu [ISiKPatient](https://gematik.de/fhir/isik/StructureDefinition/ISiKPatient) sein.\nJenseits von ISiK KÖNNEN weitere Instanzen mit anderen Profilen referenziert werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Procedure.encounter",
        "path" : "Procedure.encounter",
        "short" : "Aufenthaltsbezug",
        "comment" : "**Begründung Must-Support:** Ein Aufenthaltsbezug der Prozedur MUSS stets zum Zwecke der Nachvollziehbarkeit und Datenintegrität vorliegen.",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.encounter.reference",
        "path" : "Procedure.encounter.reference",
        "short" : "Encounter-Link",
        "comment" : "**Begründung Pflichtfeld:** Die Verlinkung auf eine Encounter-Ressource dient der technischen Zuordnung der Dokumentation zu einem Aufenthalt und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.\nIm ISik Kontext MUSS die referenzierte Ressource konform zu [ISiKKontaktGesundheitseinrichtung](https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung) sein.\nJenseits von ISiK KÖNNEN weitere Instanzen mit anderen Profilen referenziert werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Procedure.performed[x]",
        "path" : "Procedure.performed[x]",
        "short" : "Durchführungsdatum oder -Zeitraum",
        "comment" : "Es muss mindestens entweder ein (partielles) Durchführungsdatum oder der Beginn des Durchführungszeitraumes angegeben werden.\n  **Begründung Pflichtfeld:** Die zeitliche Einordnung einer Prozedur ist in vielen Fällen maßgeblich für deren medizinische Relevanz.",
        "min" : 1,
        "type" : [
          {
            "code" : "dateTime"
          },
          {
            "code" : "Period"
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Procedure.note",
        "path" : "Procedure.note",
        "short" : "Notizen",
        "comment" : "Ergänzende Hinweise und Anmerkungen zur Prozedur",
        "mustSupport" : true
      }
    ]
  }
}

```
