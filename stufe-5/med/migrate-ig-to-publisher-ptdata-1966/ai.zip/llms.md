# medikation.test.ig#0.0.1: Test Implementation Guide

## Pages

* [Bestätigungsrelevante Systeme](BestaetigungsrelevanteSysteme.md)
* [Informationsmodell](Informationsmodell.md)
* [Kompatibilität](Kompatibilitaet.md)
* [Akteure und Interaktionen](AkteureUndInteraktionen.md)
* [Einführung](Einfuehrung.md)
* [Use Cases und Informationsmodell](UseCasesUndInformationsmodell.md)
* [REST-API](RestApi.md)
* [Artifacts Summary](artifacts.md)
* [Übersicht Anwendungsfälle](UebersichtAnwendungsfaelle.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Release Notes](ReleaseNotes.md)

## Resources

### ValueSets

* [ISiKLocationPhysicalType](ValueSet-ISiKLocationPhysicalType.md)
* [SctRouteOfAdministration](ValueSet-SctRouteOfAdministration.md)

### Resource Profiles

* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKMedikament](StructureDefinition-ISiKMedikament.md)
* [ISiKMedikationsVerordnung](StructureDefinition-ISiKMedikationsVerordnung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ISiKTerminPriorityExtension](StructureDefinition-ISiKTerminPriorityExtension.md)

### CapabilityStatements

* [CapabilityStatement für Rolle &quot;LeistungserbringerRolle&quot;](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)
* [ISiK CapabilityStatement MedikamentRolle](CapabilityStatement-ISiKCapabilityStatementMedikamentRolle.md)
* [ISiK CapabilityStatement Medikationsverordnung Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungAkteur.md)
* [ISiK CapabilityStatement Medikationsverordnung Server Akteur](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungAkteur.md)
* [ISiK CapabilityStatement Medikationsverordnung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungRolle.md)
* [CapabilityStatement für Rolle &quot;StammdatenRolle&quot;](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)

### ImplementationGuides

* [Test Implementation Guide](index.md)

### MedicationRequests

* [ExampleISiKMedikationsVerordnung](MedicationRequest-ExampleISiKMedikationsVerordnung.md)
* [ExampleISiKMedikationsVerordnung2](MedicationRequest-ExampleISiKMedikationsVerordnung2.md)

### Medications

* [ExampleISiKMedikament1](Medication-ExampleISiKMedikament1.md)
* [ExampleISiKMedikament2](Medication-ExampleISiKMedikament2.md)
* [ExampleISiKMedikament3](Medication-ExampleISiKMedikament3.md)
* [ExampleISiKMedikament4](Medication-ExampleISiKMedikament4.md)
* [ExampleISiKMedikament5](Medication-ExampleISiKMedikament5.md)
* [ExampleISiKMedikament6](Medication-ExampleISiKMedikament6.md)
* [ExampleISiKMedikament7](Medication-ExampleISiKMedikament7.md)
* [ExampleISiKMedikament8](Medication-ExampleISiKMedikament8.md)
* [ExampleISiKMedikament9](Medication-ExampleISiKMedikament9.md)
* [ParacetamolInfusion](Medication-ParacetamolInfusion.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)

### Practitioners

* [PractitionerWalterArzt](Practitioner-PractitionerWalterArzt.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
