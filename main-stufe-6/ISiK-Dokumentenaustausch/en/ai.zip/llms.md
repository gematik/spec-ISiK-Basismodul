# dokumentenaustausch#6.0.0: ISiK Dokumentenaustausch Implementierungsleitfaden(en)

## Pages

* [Einführung](index.md)
* [Interaktion: Update von Metadaten](Update.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Release Notes](ReleaseNotes.md)
* [Interaktion: Dokumentenbereitstellung](Interaktion-Dokumentenbereitstellung.md)
* [Abgrenzung zu ISiK Basis bei Kommunikation strukturierter Daten](Abgrenzung-Basis.md)
* [Interaktion: Erzeugen von Metadaten](ErzeugenVonMetadaten.md)
* [Kompatibilität zu IHE-Profilen](Kompatibilitaet.md)
* [Interaktion: Dokumentenabfrage und -Zugriff](Dokumentenabfrage.md)
* [Akteure](Akteure.md)
* [FHIR-Artefakte](artifacts.md)
* [Interaktionen](Interaktionen.md)

## Resources

### CodeSystems

* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [Erweiterung von Encounter.type in ISiK](CodeSystem-ISiKEncounterTypeErweiterungCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)

### ValueSets

* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKConfidentialityCodes](ValueSet-ISiKConfidentialityCodes.md)
* [ISiKEncounterClassDE](ValueSet-ISiKEncounterClassDE.md)
* [ISiKEncounterTypeErweiterungVS](ValueSet-ISiKEncounterTypeErweiterungVS.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)

### Resource Profiles

* [ISiKBinary](StructureDefinition-ISiKBinary.md)
* [Erforderliche Metadaten für Dokumentenaustausch in ISiK](StructureDefinition-ISiKDokumentenMetadaten.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)

### CapabilityStatements

* [ISiK CapabilityStatement Dokumenten Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementDokumentenServerAkteur-expanded.md)
* [ISiK CapabilityStatement Dokumenten Server Akteur](CapabilityStatement-ISiKCapabilityStatementDokumentenServerAkteur.md)
* [ISiK CapabilityStatement Dokumentenverwaltung Rolle](CapabilityStatement-ISiKCapabilityStatementDokumentenverwaltungRolle.md)
* [ISiK CapabilityStatement Metadaten Erzeugen Rolle](CapabilityStatement-ISiKCapabilityStatementMetadatenErzeugenRolle.md)
* [ISiK CapabilityStatement Metadaten Update Rolle](CapabilityStatement-ISiKCapabilityStatementMetadatenUpdateRolle.md)
* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)

### DocumentReferences

* [dok-beispiel-client-with-binary-jpeg-example-short](DocumentReference-dok-beispiel-client-with-binary-jpeg-example-short.md)
* [dok-beispiel-client-with-binary-jpeg-example](DocumentReference-dok-beispiel-client-with-binary-jpeg-example.md)
* [dok-beispiel-client-with-binary-pdf-example-short](DocumentReference-dok-beispiel-client-with-binary-pdf-example-short.md)
* [dok-beispiel-client-with-binary-pdf-example](DocumentReference-dok-beispiel-client-with-binary-pdf-example.md)
* [dok-beispiel-server](DocumentReference-dok-beispiel-server.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)
* [isik-encounter-Sternenfall](Encounter-isik-encounter-Sternenfall.md)

### ImplementationGuides

* [ISiK Dokumentenaustausch Implementierungsleitfaden](ImplementationGuide-dokumentenaustausch.md)

### OperationDefinitions

* [Update document metadata](OperationDefinition-UpdateMetadata.md)

### Parameters

* [exp-params](Parameters-exp-params.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [IsikPatientTemplate](Patient-IsikPatientTemplate.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)
* [isik-patient-156722](Patient-isik-patient-156722.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
