# exp-params - ISiK Connect Implementierungsleitfaden v6.0.0

ISiK Connect Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **exp-params**

## Parameters: exp-params



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "exp-params",
  "parameter" : [{
    "name" : "displayLanguage",
    "valueCode" : "de-DE"
  }]
}

```
