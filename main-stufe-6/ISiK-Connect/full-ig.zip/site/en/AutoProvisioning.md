# Auto Provisioning von Zugriffsrechten auf Basis externer Authentifizierungsdienste - ISiK Connect Implementierungsleitfaden v6.0.0

ISiK Connect Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* **Auto Provisioning von Zugriffsrechten auf Basis externer Authentifizierungsdienste**

## Auto Provisioning von Zugriffsrechten auf Basis externer Authentifizierungsdienste

**Hinweis**: Der nachfolgende Abschnitt dient ausschließlich als Implementierungsunterstützung; es ergeben sich keine Anforderungen an umsetzende Systeme.

Die Umsetzung eines Auto-Provisioning, d.h. Ausführung einer automatischen Benutzerbereitstellung samt Rechten und Zugriff auf FHIR-Ressourcen, ist für Use Cases hilfreich, in denen der intersektorale IdP der gematik eingebunden wird, um Patienten über eine einheitliche Identität Zugriff auf Systeme zu ermöglichen. Dies ist zum Beispiel hilfreich für die Bereitstellung von Accounts für Patientenportale bei einer Buchung von Terminen oder der stationären Aufnahme im Krankenhaus.

Im SMART-on-FHIR-Workflow gibt es mehrere Abläufe, bei denen hierdurch sichergestellt sein muss, dass ein Benutzer sowohl im Autorisierungsserver als auch im angebundenen FHIR-Server - als Abbildung in Form einer Patient-, Practitioner- oder RelatedPerson-Ressource - mit allen relevanten Informationen vorhanden ist. Nur so können die nachfolgenden Schritte korrekt ausgeführt werden. Im Abschnitt ["Schritt 3: EHR evaluiert die Autorisierungsanfrage, Authentifizierung der Endnutzer"](Schritt3EvaluierungAutorisierungsanfragen.md) wird beschrieben, wie ein Identity Provider (IdP) in Kombination mit „Schritt 2: App bittet um Autorisierung“ per OpenID Connect Benutzerinformationen an den Client übermittelt. Für Clients, die den authorization_code-Flow verwenden, ist es in der Regel erforderlich, dass sich Benutzer aktiv authentifizieren (zum Beispiel per Benutzername/Passwort), um ein Access Token zu erhalten. Dieses Token ist in vielen Fällen direkt an den Benutzer gebunden. Dies kann z.B. mittels eines fhirUser- oder patient-Claim als Teil des Access Tokens implementiert werden. Hierdurch kann der FHIR-Server sicherstellen, dass Zugriffe auf Ressourcen mit den richtigen Einschränkungen erfolgen. Das geschieht nicht nur über definierte Scopes für den Client, sondern auch über zusätzliche benutzerspezifische Berechtigungen.

Für die Benutzerauthentifizierung bieten die meisten gängigen Autorisierungsserver die Möglichkeit, die Anmeldung an einen externen Identity Provider (IdP) weiterzuleiten. Nach einer erfolgreichen Authentifizierung stellt der Autorisierungsserver in der Regel ein signiertes Identity Token aus, über das eine verifizierte Benutzeridentität zusätzlich abgerufen werden kann. Ist ein Benutzer im System nicht registriert, also weder im Autorisierungsserver als Benutzer noch im FHIR-Server als Abbildung in Form einer Patient-, Practitioner- oder RelatedPerson-Ressource, können die relevanten Benutzerinformationen per Auto-Provisioning an die Systeme verteilt werden. Voraussetzung dafür ist, dass der Autorisierungsserver in der Lage ist, direkt mit dem FHIR-Server zu kommunizieren. Die Abfrage, ob ein bestimmter Benutzer als Ressource vorhanden ist bzw. die Anlage einer solchen Ressource wird nicht durch SMART-on-FHIR abgedeckt und ist durch die jeweiligen Autorisierungsserver proprietär umzusetzen.

