# ISiK Subscription - ISiK Terminplanung Implementierungsleitfaden v6.0.0

ISiK Terminplanung Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ISiK Subscription**

## Resource Profile: ISiK Subscription 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKSubscription | *Version*:6.0.0 |
| Active as of 2026-07-01 | *Computable Name*:ISiKSubscription |

 
ISiK Subscription 
**Motivation** 
Subscription ist eine FHIR Ressource, um als Client-System Benachrichtigungen über Events auf dem FHIR Server anzufragen. Der Subscription Mechanismus in FHIR R4 ist nicht geeignet, um alle relevanten Events (hier im Speziellen das Mergen von Patienten) zu unterstützen. Daher basiert das ISiK Subscription-Profil auf dem [Subscriptions R5 Backport Profil von HL7](https://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html). 
Um als Subsystem über ein Subscription-Event informiert zu werden, MUSS der FHIR Subscription Mechanismus gemäß des [Subscriptions R5 Backport IGs von HL7](https://hl7.org/fhir/uv/subscriptions-backport/STU1.1/index.html) vom Subscription Server Akteur unterstützt werden. 
**Kompatibilität** 
Das Profil ISiKSubscription basiert auf dem [Backport-Subscription Profil](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-backport-subscription.html). Der [SubscriptionStatus](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-backport-subscription-status-r4.html), sowie das [Subscription Notification Bundle](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-backport-subscription-notification-r4.html) werden unverändert direkt aus dem [Subscriptions R5 Backport IG](https://hl7.org/fhir/uv/subscriptions-backport/index.html) genutzt. 
Hinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden. 

**Usages:**

* Derived from this Profile: [ISiK Subscription Termine](StructureDefinition-ISiKSubscriptionTermin.md)
* Examples for this Profile: [Subscription/PatientMergeSubscriptionExample](Subscription-PatientMergeSubscriptionExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/terminplanung|current/StructureDefinition/StructureDefinition-ISiKSubscription.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-ISiKSubscription.csv), [Excel](../StructureDefinition-ISiKSubscription.xlsx), [Schematron](../StructureDefinition-ISiKSubscription.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKSubscription",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKSubscription",
  "version" : "6.0.0",
  "name" : "ISiKSubscription",
  "title" : "ISiK Subscription",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    }]
  }],
  "description" : "ISiK Subscription  \n\n**Motivation**\n\nSubscription ist eine FHIR Ressource, um als Client-System Benachrichtigungen über Events auf dem FHIR Server anzufragen. Der Subscription Mechanismus in FHIR R4 ist nicht geeignet, um alle relevanten Events (hier im Speziellen das Mergen von Patienten) zu unterstützen. Daher basiert das ISiK Subscription-Profil auf dem [Subscriptions R5 Backport Profil von HL7](https://hl7.org/fhir/uv/subscriptions-backport/STU1.1/StructureDefinition-backport-subscription.html).\n\nUm als Subsystem über ein Subscription-Event informiert zu werden, MUSS der FHIR Subscription Mechanismus gemäß des [Subscriptions R5 Backport IGs von HL7](https://hl7.org/fhir/uv/subscriptions-backport/STU1.1/index.html) vom Subscription Server Akteur unterstützt werden.\n\n**Kompatibilität**\n\nDas Profil ISiKSubscription basiert auf dem [Backport-Subscription Profil](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-backport-subscription.html).\nDer [SubscriptionStatus](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-backport-subscription-status-r4.html), sowie das [Subscription Notification Bundle](https://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition-backport-subscription-notification-r4.html) werden unverändert direkt aus dem [Subscriptions R5 Backport IG](https://hl7.org/fhir/uv/subscriptions-backport/index.html) genutzt.  \n\nHinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Subscription",
  "baseDefinition" : "http://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition/backport-subscription",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Subscription",
      "path" : "Subscription"
    },
    {
      "id" : "Subscription.id",
      "path" : "Subscription.id",
      "short" : "serverseitige, interne ID des Datensatzes",
      "comment" : "**bedingtes Pflichtfeld/bedingtes MS:** Alle von einem Server bereitgestellten Ressourcen MÜSSEN über eine `id` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `id`verfügen. ",
      "mustSupport" : true
    },
    {
      "id" : "Subscription.meta.versionId",
      "path" : "Subscription.meta.versionId",
      "short" : "Eindeutiger Name der serverseitigen Version des Datensatzes",
      "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über eine `versionID` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `versionID`verfügen. "
    },
    {
      "id" : "Subscription.meta.lastUpdated",
      "path" : "Subscription.meta.lastUpdated",
      "short" : "Zeitpunkt der letzten Änderung",
      "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über ein `lastUpdate` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über ein `lastUpdate`verfügen. "
    },
    {
      "id" : "Subscription.implicitRules",
      "path" : "Subscription.implicitRules",
      "short" : "Verweis auf die Regeln, nach denen die Ressource erstellt wurde",
      "comment" : "Begründung Constraint: In ISiK existiert kein Use-Case für dieses Element. Da es sich um ein Modifying Element handelt, wird es daher ausgeschlossen.\n  Darüber hinaus werden die Regeln als URI vorgehalten. Dies führt dazu, dass sich hinter der URI eine beliebige Menge an Regeln befinden kann; wodurch  nicht sichergestellt werden kann, dass alle Clients die Regeln korrekt interpretieren können.",
      "max" : "0"
    },
    {
      "id" : "Subscription.status",
      "path" : "Subscription.status",
      "short" : "Status",
      "comment" : "**Bedeutung:** Der Status der Subscription, der den Serverstatus der Subscription angibt. \n  Neue Subscriptions werden immer mit dem Status `requested` an den Server übergeben. \n  Der Server ändert im Anschluss den Status auf `active` oder im Fehlerfall auf `error`.",
      "mustSupport" : true
    },
    {
      "id" : "Subscription.reason",
      "path" : "Subscription.reason",
      "short" : "Grund der Subscription",
      "comment" : "**Bedeutung:** Beschreibung wieso diese Subscription erstellt wurde.",
      "mustSupport" : true
    },
    {
      "id" : "Subscription.criteria",
      "path" : "Subscription.criteria",
      "short" : "Canonical URL des SubscriptionTopic welches man abonnieren möchte.",
      "comment" : "Enthält eines der in ISiK vereinbarten Subscription Topics.",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://gematik.de/fhir/isik/ValueSet/ISiKSubscriptionTopicVS"
      }
    },
    {
      "id" : "Subscription.criteria.extension:filterCriteria",
      "path" : "Subscription.criteria.extension",
      "sliceName" : "filterCriteria",
      "short" : "Filterkriterium.",
      "comment" : "**Bedeutung:** Filterkriterium für die Subscription. Dieses Feld ist optional und kann genutzt werden, um die Subscription auf bestimmte Events zu filtern."
    },
    {
      "id" : "Subscription.criteria.extension:filterCriteria.value[x]",
      "path" : "Subscription.criteria.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Subscription.channel",
      "path" : "Subscription.channel",
      "short" : "Kommunikationskanal",
      "comment" : "**Bedeutung:** Kommunikationskanal über den die Subscription Benachrichtigungen gesendet werden sollen.",
      "mustSupport" : true
    },
    {
      "id" : "Subscription.channel.extension:heartbeatPeriod",
      "path" : "Subscription.channel.extension",
      "sliceName" : "heartbeatPeriod",
      "short" : "Heartbeat-Intervall",
      "comment" : "**Bedeutung:** Intervall in dem der Server prüft, ob der Kommunikationskanal noch aktiv ist.",
      "mustSupport" : true
    },
    {
      "id" : "Subscription.channel.extension:heartbeatPeriod.value[x]",
      "path" : "Subscription.channel.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Subscription.channel.type",
      "path" : "Subscription.channel.type",
      "short" : "Typ des Kommunikationskanals",
      "comment" : "**Bedeutung:** Der Typ des Kommunikationskanals, über den Subscription-Benachrichtigungen gesendet werden sollen.  \n    In ISiK MUSS der Wert `rest-hook` unterstützt werden, weitere Werte KÖNNEN unterstützt werden.",
      "mustSupport" : true
    },
    {
      "id" : "Subscription.channel.type.extension:customChannelType",
      "path" : "Subscription.channel.type.extension",
      "sliceName" : "customChannelType",
      "short" : "Custom Channel Type",
      "comment" : "**Bedeutung:** Custom Channel Type welcher in ISiK aktuell nicht unterstützt wird.",
      "max" : "0"
    },
    {
      "id" : "Subscription.channel.endpoint",
      "path" : "Subscription.channel.endpoint",
      "short" : "Endpunkt",
      "comment" : "**Bedeutung:** Adresse des Kommunikationskanals/ Endpunkts, an den Subscription-Benachrichtigungen gesendet werden sollen. Dies ist nur für rest-hook Subscriptions relevant.",
      "mustSupport" : true
    },
    {
      "id" : "Subscription.channel.payload",
      "path" : "Subscription.channel.payload",
      "short" : "Format der Nutzdaten",
      "comment" : "**Bedeutung:** Format in dem Subscription Notifications versendet werden sollen (JSON oder XML).",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/isik/ValueSet/FhirMimeTypeVS"
      }
    },
    {
      "id" : "Subscription.channel.payload.extension:content",
      "path" : "Subscription.channel.payload.extension",
      "sliceName" : "content",
      "short" : "Inhalt der Nutzdaten",
      "comment" : "**Bedeutung:** Ressourceninhalt, der in der Nutzlast der Benachrichtigung geliefert wird.  \n      ISiK-konforme Subscription-Notifications MÜSSEN `id-only` verwenden. Die Notification enthält die ID der geänderten Ressource, jedoch keine vollständigen Ressourcendaten. Der Client kann anhand der ID gezielt die aktuelle Version der Ressource abrufen (Pull-Prinzip)."
    },
    {
      "id" : "Subscription.channel.payload.extension:content.value[x]:valueCode",
      "path" : "Subscription.channel.payload.extension.value[x]",
      "sliceName" : "valueCode",
      "type" : [{
        "code" : "code"
      }],
      "fixedCode" : "id-only"
    },
    {
      "id" : "Subscription.channel.header",
      "path" : "Subscription.channel.header",
      "short" : "Falls eine REST-Enpunkt einen Authorization-Header benötigt, kann dieser hier gesetzt werden",
      "comment" : "**Bedeutung:** HTTP-Header, der dazu genutzt werden kann, einen Authorization-Header zu setzen (z.B. für HTTP Basic Authentication mit statischem Secret).\n    **Hinweise:** Dieses Feld ist Write-Only: Secrets können bei Erstellung/Aktualisierung übermittelt werden, MÜSSEN vom Server bei READ-Interaktionen jedoch maskiert werden (z.B. `Authorization: Basic ****last4`). In der Subscription DÜRFEN keine Klartext-Secrets dauerhaft gespeichert sein. Siehe [R4 Subscriptions](https://hl7.org/fhir/R4/subscription.html)",
      "mustSupport" : true
    }]
  }
}

```
