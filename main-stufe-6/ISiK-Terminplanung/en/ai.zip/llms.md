# terminplanung#6.0.0: ISiK Terminplanung Implementierungsleitfaden(en)

## Pages

* [Einführung](index.md)
* [Informationsmodell](Informationsmodell.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Release Notes](ReleaseNotes.md)
* [Kompatibilität zu anderen nationalen FHIR-basierten Spezifikationen](Kompatibilitaet.md)
* [Prozesse](Prozesse.md)
* [Akteure](Akteure.md)
* [Architekturoptionen](Architekturoptionen.md)
* [Artifacts Summary](artifacts.md)
* [Performance](Performance.md)
* [FHIR-Artefakte](artifacts_isik.md)
* [Operation: $book](Operations.md)
* [Use Cases und Kontext](UseCases.md)
* [Interaktionen](Interaktionen.md)

## Resources

### CodeSystems

* [TestKatalog](CodeSystem-CodeSystemExample.md)
* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [Erweiterung von Encounter.type in ISiK](CodeSystem-ISiKEncounterTypeErweiterungCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiK-SubscriptionTopic](CodeSystem-ISiKSubscriptionTopic.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)
* [MIME Types (Fragment)](CodeSystem-MimeTypeCS.md)
* [SubscriptionNotificationType](CodeSystem-subscription-notification-type.md)

### ValueSets

* [FhirMimeTypeVS](ValueSet-FhirMimeTypeVS.md)
* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKEncounterClassDE](ValueSet-ISiKEncounterClassDE.md)
* [ISiKEncounterTypeErweiterungVS](ValueSet-ISiKEncounterTypeErweiterungVS.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiKSubscriptionTopicAppointmentVS](ValueSet-ISiKSubscriptionTopicAppointmentVS.md)
* [ISiKSubscriptionTopic ValueSet](ValueSet-ISiKSubscriptionTopicVS.md)
* [ISiKTerminCancelationReason](ValueSet-ISiKTerminCancelationReason.md)
* [ISiKTerminPriority](ValueSet-ISiKTerminPriority.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)
* [TestValueSet](ValueSet-ISiKValueSetExample.md)
* [SubscriptionNotificationType](ValueSet-subscription-notification-type.md)

### Resource Profiles

* [R4 Topic-Based Subscription Notification Bundle](StructureDefinition-BackportSubscriptionNotificationR4Fixed.md)
* [R4 Backported R5 SubscriptionStatus](StructureDefinition-BackportSubscriptionStatusR4Fixed.md)
* [ISiKCodeSystem](StructureDefinition-ISiKCodeSystem.md)
* [ISiKKalender](StructureDefinition-ISiKKalender.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKMedizinischeBehandlungseinheit](StructureDefinition-ISiKMedizinischeBehandlungseinheit.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiK Subscription](StructureDefinition-ISiKSubscription.md)
* [ISiK Subscription Termine](StructureDefinition-ISiKSubscriptionTermin.md)
* [ISiKTermin](StructureDefinition-ISiKTermin.md)
* [ISiKTerminblock](StructureDefinition-ISiKTerminblock.md)
* [ISiKValueSet](StructureDefinition-ISiKValueSet.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)
* [ISiKTerminPriorityExtension](StructureDefinition-ISiKTerminPriorityExtension.md)

### Appointments

* [ISiKTerminExample](Appointment-ISiKTerminExample.md)
* [ISiKTerminExampleExtendedICU](Appointment-ISiKTerminExampleExtendedICU.md)

### CapabilityStatements

* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)
* [ISiK CapabilityStatement Termin-Repository Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementTerminRepositoryAkteur-expanded.md)
* [ISiK CapabilityStatement Termin-Repository Akteur](CapabilityStatement-ISiKCapabilityStatementTerminRepositoryAkteur.md)
* [ISiK CapabilityStatement Termin-Repository Rolle](CapabilityStatement-ISiKCapabilityStatementTerminRepositoryRolle.md)
* [CapabilityStatement für Rolle Termin Subscription](CapabilityStatement-ISiKCapabilityStatementTerminSubscriptionRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementTerminologieRolle](CapabilityStatement-ISiKCapabilityStatementTerminologieRolle.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)
* [isik-encounter-Sternenfall](Encounter-isik-encounter-Sternenfall.md)

### HealthcareServices

* [Allgemeine Beratungsstelle der Fachabteilung 0100](HealthcareService-ISiKMedizinischeBehandlungseinheitExample.md)

### ImplementationGuides

* [ISiK Terminplanung Implementierungsleitfaden](ImplementationGuide-terminplanung.md)

### OperationDefinitions

* [Book](OperationDefinition-ISiKAppointmentBookOperation.md)

### Parameters

* [exp-params](Parameters-exp-params.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [IsikPatientTemplate](Patient-IsikPatientTemplate.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)
* [isik-patient-156722](Patient-isik-patient-156722.md)

### Schedules

* [ISiKKalenderExample](Schedule-ISiKKalenderExample.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)

### Slots

* [ISiKTerminblockExample](Slot-ISiKTerminblockExample.md)

### Subscriptions

* [PatientMergeSubscriptionExample](Subscription-PatientMergeSubscriptionExample.md)
