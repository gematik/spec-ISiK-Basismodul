# medikation#6.0.0: ISiK Medikation Implementierungsleitfaden(en)

## Pages

* [Einführung](index.md)
* [Informationsmodell](Informationsmodell.md)
* [REST-API](RestApi.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Übersicht Anwendungsfälle](UebersichtAnwendungsfaelle.md)
* [Release Notes](ReleaseNotes.md)
* [Kompatibilität](Kompatibilitaet.md)
* [Anwendungsfall - Closed Loop Medikationsprozess](AnwendungsfallClosedLoopMedikationsprozess.md)
* [Artefakte](artifacts.md)
* [Akteure und Interaktionen](AkteureUndInteraktionen.md)
* [Infusionen](Infusionen.md)
* [Bedarfs](Bedarfsmedikation.md)

## Resources

### CodeSystems

* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [Erweiterung von Encounter.type in ISiK](CodeSystem-ISiKEncounterTypeErweiterungCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiK Medikationsart](CodeSystem-ISiKMedikationsartCS.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)

### ValueSets

* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKEncounterClassDE](ValueSet-ISiKEncounterClassDE.md)
* [ISiKEncounterTypeErweiterungVS](ValueSet-ISiKEncounterTypeErweiterungVS.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiKMedikationsartVS](ValueSet-ISiKMedikationsartVS.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)
* [Medikationslisten-Modes](ValueSet-MedikationsListeListModeVS.md)
* [SctRouteOfAdministration](ValueSet-SctRouteOfAdministration.md)

### Complex-type Profiles

* [ISiKASKCoding](StructureDefinition-ISiKASKCoding.md)
* [ISiKATCCoding](StructureDefinition-ISiKATCCoding.md)
* [ISiKCoding](StructureDefinition-ISiKCoding.md)
* [ISiKPZNCoding](StructureDefinition-ISiKPZNCoding.md)
* [ISiKSnomedCTCoding](StructureDefinition-ISiKSnomedCTCoding.md)
* [Medication Quantity](StructureDefinition-MedicationQuantity.md)
* [Medication Quantity Dose Form](StructureDefinition-MedicationQuantityDoseForm.md)

### Resource Profiles

* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKMedikament](StructureDefinition-ISiKMedikament.md)
* [ISiKMedikationsInformation](StructureDefinition-ISiKMedikationsInformation.md)
* [ISiK Medikationsliste](StructureDefinition-ISiKMedikationsListe.md)
* [ISiKMedikationsVerabreichung](StructureDefinition-ISiKMedikationsVerabreichung.md)
* [ISiKMedikationsVerordnung](StructureDefinition-ISiKMedikationsVerordnung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)
* [ISiKRolleImKrankenhaus](StructureDefinition-ISiKRolleImKrankenhaus.md)

### Extensions

* [ISiK Accepted Risk](StructureDefinition-ExtensionISiKAcceptedRisk.md)
* [ISiK Behandlungsziel](StructureDefinition-ExtensionISiKBehandlungsziel.md)
* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ISiK Medikationsart](StructureDefinition-ExtensionISiKMedikationsart.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)
* [ISiK Selbstmedikation](StructureDefinition-ExtensionISiKSelbstmedikation.md)
* [Dosage AsNeededFor](StructureDefinition-extension-Dosage.asNeededFor.md)

### CapabilityStatements

* [CapabilityStatement für Rolle LeistungserbringerRolle](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)
* [ISiK CapabilityStatement MedikamentRolle](CapabilityStatement-ISiKCapabilityStatementMedikamentRolle.md)
* [ISiK CapabilityStatement Medikament WRITE Rolle](CapabilityStatement-ISiKCapabilityStatementMedikamentWRITERolle.md)
* [ISiK CapabilityStatement Medikationsinformation Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementMedikationInformationAkteur-expanded.md)
* [ISiK CapabilityStatement Medikationsinformation Server Akteur](CapabilityStatement-ISiKCapabilityStatementMedikationInformationAkteur.md)
* [ISiK CapabilityStatement Medikation Server - Medikationsinformation](CapabilityStatement-ISiKCapabilityStatementMedikationInformationRolle.md)
* [ISiK CapabilityStatement Medikationsinformation WRITE Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationInformationWRITERolle.md)
* [ISiK CapabilityStatement Medikationsverabreichung Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungAkteur-expanded.md)
* [ISiK CapabilityStatement Medikationsverabreichung Server Akteur](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungAkteur.md)
* [ISiK CapabilityStatement Medikationsverabreichung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungRolle.md)
* [ISiK CapabilityStatement Medikationsverabreichung WRITE Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungWRITERolle.md)
* [ISiK CapabilityStatement Medikationsverordnung Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungAkteur-expanded.md)
* [ISiK CapabilityStatement Medikationsverordnung Server Akteur](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungAkteur.md)
* [ISiK CapabilityStatement Medikationsverordnung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungRolle.md)
* [ISiK CapabilityStatement Medikationsverordnung WRITE Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungWRITERolle.md)
* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)
* [isik-encounter-Sternenfall](Encounter-isik-encounter-Sternenfall.md)

### ImplementationGuides

* [ISiK Medikation Implementierungsleitfaden](ImplementationGuide-medikation.md)

### Lists

* [ExampleISiKMedikationsListe](List-ExampleISiKMedikationsListe.md)
* [ExampleISiKMedikationsListeParkinson](List-ExampleISiKMedikationsListeParkinson.md)

### MedicationAdministrations

* [ExampleISiKMedikationsVerabreichung](MedicationAdministration-ExampleISiKMedikationsVerabreichung.md)
* [ExampleISiKMedikationsVerabreichung2](MedicationAdministration-ExampleISiKMedikationsVerabreichung2.md)
* [ExampleISiKMedikationsVerabreichung3](MedicationAdministration-ExampleISiKMedikationsVerabreichung3.md)
* [ExampleISiKMedikationsVerabreichung4](MedicationAdministration-ExampleISiKMedikationsVerabreichung4.md)

### MedicationRequests

* [ExampleISiKMedikationsVerordnung](MedicationRequest-ExampleISiKMedikationsVerordnung.md)
* [ExampleISiKMedikationsVerordnung2](MedicationRequest-ExampleISiKMedikationsVerordnung2.md)
* [ExampleISiKMedikationsVerordnungBedarfsmedikation](MedicationRequest-ExampleISiKMedikationsVerordnungBedarfsmedikation.md)

### MedicationStatements

* [ExampleISiKMedikationsInformation1](MedicationStatement-ExampleISiKMedikationsInformation1.md)
* [ExampleISiKMedikationsInformation2](MedicationStatement-ExampleISiKMedikationsInformation2.md)
* [ExampleISiKMedikationsInformation3](MedicationStatement-ExampleISiKMedikationsInformation3.md)
* [ExampleISiKMedikationsInformation4](MedicationStatement-ExampleISiKMedikationsInformation4.md)
* [ExampleISiKMedikationsInformation5](MedicationStatement-ExampleISiKMedikationsInformation5.md)
* [ExampleISiKMedikationsInformation6](MedicationStatement-ExampleISiKMedikationsInformation6.md)
* [ExampleISiKMedikationsInformationParkinson1](MedicationStatement-ExampleISiKMedikationsInformationParkinson1.md)
* [ExampleISiKMedikationsInformationParkinson2](MedicationStatement-ExampleISiKMedikationsInformationParkinson2.md)
* [ExampleISiKMedikationsInformationParkinson3](MedicationStatement-ExampleISiKMedikationsInformationParkinson3.md)
* [ExampleISiKMedikationsInformationParkinson4](MedicationStatement-ExampleISiKMedikationsInformationParkinson4.md)
* [ExampleISiKMedikationsInformationParkinson5](MedicationStatement-ExampleISiKMedikationsInformationParkinson5.md)

### Medications

* [ExampleISiKMedikament1](Medication-ExampleISiKMedikament1.md)
* [ExampleISiKMedikament2](Medication-ExampleISiKMedikament2.md)
* [ExampleISiKMedikament3](Medication-ExampleISiKMedikament3.md)
* [ExampleISiKMedikament4](Medication-ExampleISiKMedikament4.md)
* [ExampleISiKMedikament5](Medication-ExampleISiKMedikament5.md)
* [ExampleISiKMedikament6](Medication-ExampleISiKMedikament6.md)
* [ExampleISiKMedikament7](Medication-ExampleISiKMedikament7.md)
* [ExampleISiKMedikament8](Medication-ExampleISiKMedikament8.md)
* [ExampleISiKMedikament9](Medication-ExampleISiKMedikament9.md)
* [ParacetamolInfusion](Medication-ParacetamolInfusion.md)

### Parameters

* [exp-params](Parameters-exp-params.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [IsikPatientTemplate](Patient-IsikPatientTemplate.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)
* [isik-patient-156722](Patient-isik-patient-156722.md)

### PractitionerRoles

* [RolleImKrankenhausAllgemeinchirurgieBeispiel](PractitionerRole-RolleImKrankenhausAllgemeinchirurgieBeispiel.md)
* [RolleImKrankenhausInnereMedizinBeispiel](PractitionerRole-RolleImKrankenhausInnereMedizinBeispiel.md)

### Practitioners

* [PractitionerWalterArzt](Practitioner-PractitionerWalterArzt.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
