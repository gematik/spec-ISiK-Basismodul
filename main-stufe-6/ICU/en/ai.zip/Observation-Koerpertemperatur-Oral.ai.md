# Koerpertemperatur-Oral - ISiK ICU v6.0.0

ISiK ICU

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Koerpertemperatur-Oral**

## Observation: Koerpertemperatur-Oral

Profile: [SD MII ICU Koerpertemperatur unter der Zunge](StructureDefinition-sd-mii-icu-koerpertemperatur-unter-der-zunge.md)

**status**: Final

**category**: Vital Signs

**code**: Orale Temperatur

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**effective**: 2019-12-23 09:30:10+0100 --> 2019-12-23 10:30:10+0100

**value**: 37 degree Celsius (Details: UCUM codeCel = 'Cel')

**bodySite**: Mouth region structure



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "Koerpertemperatur-Oral",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/sd-mii-icu-koerpertemperatur-unter-der-zunge"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "8310-5"
    },
    {
      "system" : "http://snomed.info/sct",
      "code" : "415945006",
      "display" : "Orale Temperatur"
    },
    {
      "system" : "http://loinc.org",
      "code" : "8329-5"
    },
    {
      "system" : "http://loinc.org",
      "code" : "8331-1",
      "display" : "Oral temperature"
    },
    {
      "system" : "urn:iso:std:iso:11073:10101",
      "code" : "188424",
      "display" : "Oral temperature"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "effectivePeriod" : {
    "start" : "2019-12-23T09:30:10+01:00",
    "end" : "2019-12-23T10:30:10+01:00"
  },
  "valueQuantity" : {
    "value" : 37,
    "unit" : "degree Celsius",
    "system" : "http://unitsofmeasure.org",
    "code" : "Cel"
  },
  "bodySite" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "123851003",
      "display" : "Mouth region structure"
    }]
  }
}

```
