# Prozesse und Workflows - ISiK ICU v6.0.0

ISiK ICU

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* **Prozesse und Workflows**

## Prozesse und Workflows

### Prozess Überleitung - Vorannahmen

Vorannahmen zu den unten modellierten Workflows sind, dass die betroffenen Patienten einen Zugang- oder Entlassungsprozess im Kontext der Intensivversorgung durchlaufen haben, durchlaufen, oder in naher Zukunft durchlaufen werden.

Die Illustration möglicher bidirektionaler Überleitungs-Prozesse (analog zum [spezifischen Zulassungsprozess hier](https://breathe.ersjournals.com/content/16/2/200062)) erscheint in diesem Kontext nicht zielführend.

### Workflow - Support-Prozess zur Datenübermittlung bei Überleitung

Zur Abbildung des bidirektionalen Überleitungsprozesses zwischen einer Intensiv- und einer Normalstation können KIS und PDMS jeweils die Rolle des KIS und Client einnehmen.

Der Workflow dient im Wesentlichen dazu, verschiedene Nutzungsmöglichkeiten der REST-Schnittstelle zur abfragebasierten Datenkommunikation im Rahmen der Workflow-Unterstützung darzustellen.

Für Festlegungen zu REST-Abfragen siehe den [Abschnitt zur REST-API im Basismodul](https://gemspec.gematik.de/ig/fhir/isik/basis/6.0.0-rc1/UebergreifendeFestlegungen_Rest.html).

#### Abfrage zeitlich folgend - Diagramm

Folgende Diagramme illustrieren die Fälle, bei denen Daten zeitlich nach der Überleitung abgefragt werden (mittels HTTP GET).

Folgendes Diagramm Illustriert den Workflow zu **UC-VIT-ICU-NORM-001** als BPMN-Prozess:

Abbildung: Nachträgliche Blutdruck-Abfrage aus Normalstation
**Hinweis:** hier agiert das KIS als Client.

Folgendes Diagramm Illustriert den Workflow zu **UC-VIT-ICU-NORM-002** als BPMN-Prozess:

Abbildung: Nachträgliche Blutdruck-Abfrage aus Intensivstation
#### Übernahme zeitlich vorgelagert - Diagramm

Denkbar sind auch Workflows, bei denen erhobene Daten aus einem System vor der Verlegung übermittelt werden. Siehe z.B. den Workflow zu **UC-VIT-ICU-NORM-003** als BPMN-Prozess:

Abbildung: Vorgelagerte Übermittlung an Intensivstation
Eine Abfrage per HTTP GET allein reicht nicht aus, um die benötigten Daten rechtzeitig zu übermitteln. Stattdessen muss eine Vorab-Übermittlung durch einen anderen Mechanismus erfolgen. Sobald diese angestoßen wurde, kann das PDMS die vollständigen Daten per GET abrufen. An dieser Stelle werden keine weiteren Festlegungen zur vorgelagerten Übermittlung der Daten erhoben und es wird keine direkte Schreiboperation auf FHIR-Basis des KIS im PDMS für diesen Fall gefordert. Die Vorab-Übermittlung könnte durch verschiedene Mechanismen unterstützt werden:

* FHIR Subscription (vgl. im ISiK Kontext [Patient merge Notification](https://gemspec.gematik.de/ig/fhir/isik/subscriptions/6.0.0-rc1/Patientenzusammenfuehrung.html)
* Create-Interaktion (POST) (vgl. im ISiK Kontext [REST-API](https://gemspec.gematik.de/ig/fhir/isik/basis/6.0.0-rc1/UebergreifendeFestlegungen_Rest.html))
* HL7 v2 Messaging
* Rückübermittelung als FHIR Document per [ISiKBerichtSubSysteme](https://gemspec.gematik.de/ig/fhir/isik/basis/6.0.0-rc1/StructureDefinition-ISiKBerichtSubSysteme.html)
* etc.

