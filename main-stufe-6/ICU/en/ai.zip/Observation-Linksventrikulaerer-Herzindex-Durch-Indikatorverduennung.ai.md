# Linksventrikulaerer-Herzindex-Durch-Indikatorverduennung - ISiK ICU v6.0.0

ISiK ICU

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Linksventrikulaerer-Herzindex-Durch-Indikatorverduennung**

## Observation: Linksventrikulaerer-Herzindex-Durch-Indikatorverduennung

Profile: [SD MII ICU Linksventrikulaerer Herzindex durch Indikatorverduennung](StructureDefinition-sd-mii-icu-linksventri-herzindex-durch-indikatorverduennung.md)

**status**: Final

**category**: Vital Signs

**code**: Left ventricular Cardiac index by Indicator dilution

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**effective**: 2019-12-23 09:30:10+0100 --> 2019-12-23 10:30:10+0100

**value**: 3 liter per minute and square meter (Details: UCUM codeL/min/m2 = 'L/min/m2')



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "Linksventrikulaerer-Herzindex-Durch-Indikatorverduennung",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/sd-mii-icu-linksventri-herzindex-durch-indikatorverduennung"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "8751-0",
      "display" : "Left ventricular Cardiac index by Indicator dilution"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "effectivePeriod" : {
    "start" : "2019-12-23T09:30:10+01:00",
    "end" : "2019-12-23T10:30:10+01:00"
  },
  "valueQuantity" : {
    "value" : 3,
    "unit" : "liter per minute and square meter",
    "system" : "http://unitsofmeasure.org",
    "code" : "L/min/m2"
  }
}

```
