# ExampleISiKLaboruntersuchungGFR1 - ISiK Labor Implementierungsleitfaden v6.0.0

ISiK Labor Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ExampleISiKLaboruntersuchungGFR1**

## Observation: ExampleISiKLaboruntersuchungGFR1

Profile: [ISiKLaboruntersuchungGFR](StructureDefinition-ISiKLaboruntersuchungGFR.md)

**status**: Final

**category**: Laboratory

**code**: Glomerular filtration rate

**subject**: [Patient/PatientinMusterfrau](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.6.0&canonical=http://fhir.org/packages/de.basisprofil.r4/Patient/PatientinMusterfrau)

**effective**: 2021-09-01 12:00:00+0000

**performer**: [Practitioner/PractitionerWalterArzt](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.6.0&canonical=http://fhir.org/packages/de.basisprofil.r4/Practitioner/PractitionerWalterArzt)

**value**: 100 milliliter pro Minute pro Körperoberfläche von 1,73 m2 (Details: UCUM codemL/min/(1.73) = 'mL/min/(1.73)')

### ReferenceRanges

| | |
| :--- | :--- |
| - | **High** |
| * | 100 milliliter pro Minute pro Körperoberfläche von 1,73 m2 (Details: UCUM codemL/min/(1.73) = 'mL/min/(1.73)') |



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ExampleISiKLaboruntersuchungGFR1",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/ISiKLaboruntersuchungGFR"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "laboratory"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "98980-6"
    },
    {
      "system" : "http://snomed.info/sct",
      "code" : "80274001",
      "display" : "Glomerular filtration rate"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "effectiveDateTime" : "2021-09-01T12:00:00Z",
  "performer" : [{
    "reference" : "Practitioner/PractitionerWalterArzt"
  }],
  "valueQuantity" : {
    "value" : 100,
    "unit" : "milliliter pro Minute pro Körperoberfläche von 1,73 m2",
    "system" : "http://unitsofmeasure.org",
    "code" : "mL/min/(1.73)"
  },
  "referenceRange" : [{
    "high" : {
      "value" : 100,
      "unit" : "milliliter pro Minute pro Körperoberfläche von 1,73 m2",
      "system" : "http://unitsofmeasure.org",
      "code" : "mL/min/(1.73)"
    }
  }]
}

```
