# Szenario 2: Kreuz-Stern-Diagnose - ISiK Basis Implementierungsleitfaden v6.0.0

ISiK Basis Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* **Szenario 2: Kreuz-Stern-Diagnose**

## Szenario 2: Kreuz-Stern-Diagnose

### Szenario 2: Kreuz-Stern Diagnose

* volljährige, hauptversicherte Patientin
* stationärer Aufenthalt
* Kreuz-Stern-Diagnose (ICD-10) als Krankenhaus-Hauptdiagnose

#### Ressourcen-Graph

**Abbildung:**
#### Instanzen: Personen

[Patientin](Patient-SZ2Patient.md)

#### Instanzen: Diagnosen

[Primärdiagnose](Condition-SZ2Primaerdiagnose.md)

[Sekundärdiagnose](Condition-SZ2Sekundaerdiagnose.md)

#### Instanzen: Versicherungsverhältnisse

[Versicherung gesetzlich](Coverage-SZ2VersicherungGesetzlich.md)

#### Instanzen: Besuche

[Stationärer](Encounter-SZ2Encounter.md)

#### Instanzen: Abrechnungsfall

[DRG-Abrechnungsfall](Account-SZ2DRGFall.md)

