# ISiKAbrechnungsfallAmbulant - ISiK Basis Implementierungsleitfaden v6.0.0

ISiK Basis Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiKAbrechnungsfallAmbulant**

## Resource Profile: ISiKAbrechnungsfallAmbulant 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKAbrechnungsfallAmbulant | *Version*:6.0.0 |
| Active as of 2026-07-01 | *Computable Name*:ISiKAbrechnungsfallAmbulant |

 
Dieses Profil spezifiziert die Anforderungen an die Abbildung von ambulanten Abrechnungsfällen im Krankenhauskontext. Es handelt sich dabei um eine Spezialisierung des ISiK Abrechnungsfall-Profils, das allgemeine Anforderungen an die Abbildung von Abrechnungsfällen definiert. 
Ambulante-Abrechnungsfall-Angaben unterscheiden sich von stationären im Krankenhaus im Wesentlichen durch die Angabe von: 
* die Extenion `AbrechnungsDiagnoseProzedurAmbulant` wurde ergänzt, um die Angabe von abrechnungsrelevanten Diagnosen und Prozeduren zu ermöglichen, ohne dass diese in Haupt- und Nebendiagnosen aufgeteilt werden müssen. Eine Aufteilung ist im ambulanten Kontext nicht üblich, aber da es dennoch in der Praxis vorkommen kann, wurde die ursprüngliche Extension `AbrechnungsDiagnoseProzedur` nicht ausgeschlossen, sondern die neue Extension als Ergänzung hinzugefügt.
* die Angabe einer Scheinnummer als Identifier. Amulante Fälle werden meist über die Existenz eines so genannten Scheins definiert. Die Scheinnummer ist eine Nummer, die innerhalb einer Einrichtung diesen Schein eindeutig identifiziert. Da es häufig auch noch eine klassische Fallnummer gibt, sind beide Identifier vorgesehen und kommen auch vor.
* die Angabe eines `servicePeriod` als Gültigkeitszeitraum des ambulanten Abrechnungsfalls, da es sich hierbei um punktuelle Kontakte handelt und der Zeitraum der Gültigkeit nicht direkt aus den zugeordneten Encountern ableitbar ist.
* die Angabe eines `owner`, um die Ambulanz als verantwortliche Organisation zu dokumentieren.
 

**Usages:**

* Examples for this Profile: [Account/AbrechnungsfallAmbulantMvzImKrankenhaus](Account-AbrechnungsfallAmbulantMvzImKrankenhaus.md)
* CapabilityStatements using this Profile: [CapabilityStatement für Rolle ISiKCapabilityStatementAmbulanteStammdatenRolle](CapabilityStatement-ISiKCapabilityStatementAmbulanteStammdatenRolle.md) and [Akteur ISiKCapabilityStatementBasisServerAkteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur-expanded.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/basis|current/StructureDefinition/StructureDefinition-ISiKAbrechnungsfallAmbulant.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-ISiKAbrechnungsfallAmbulant.csv), [Excel](../StructureDefinition-ISiKAbrechnungsfallAmbulant.xlsx), [Schematron](../StructureDefinition-ISiKAbrechnungsfallAmbulant.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKAbrechnungsfallAmbulant",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKAbrechnungsfallAmbulant",
  "version" : "6.0.0",
  "name" : "ISiKAbrechnungsfallAmbulant",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    }]
  }],
  "description" : "Dieses Profil spezifiziert die Anforderungen an die Abbildung von ambulanten Abrechnungsfällen im Krankenhauskontext. Es handelt sich dabei um eine Spezialisierung des ISiK Abrechnungsfall-Profils, das allgemeine Anforderungen an die Abbildung von Abrechnungsfällen definiert.\n\nAmbulante-Abrechnungsfall-Angaben unterscheiden sich von stationären im Krankenhaus im Wesentlichen durch die Angabe von:\n\n- die Extenion `AbrechnungsDiagnoseProzedurAmbulant` wurde ergänzt, um die Angabe von abrechnungsrelevanten Diagnosen und Prozeduren zu ermöglichen, ohne dass diese in Haupt- und Nebendiagnosen aufgeteilt werden müssen. Eine Aufteilung ist im ambulanten Kontext nicht üblich, aber da es dennoch in der Praxis vorkommen kann, wurde die ursprüngliche Extension `AbrechnungsDiagnoseProzedur` nicht ausgeschlossen, sondern die neue Extension als Ergänzung hinzugefügt.\n- die Angabe einer Scheinnummer als Identifier. Amulante Fälle werden meist über die Existenz eines so genannten Scheins definiert. Die Scheinnummer ist eine Nummer, die innerhalb einer Einrichtung diesen Schein eindeutig identifiziert. Da es häufig auch noch eine klassische Fallnummer gibt, sind beide Identifier vorgesehen und kommen auch vor.\n- die Angabe eines `servicePeriod` als Gültigkeitszeitraum des ambulanten Abrechnungsfalls, da es sich hierbei um punktuelle Kontakte handelt und der Zeitraum der Gültigkeit nicht direkt aus den zugeordneten Encountern ableitbar ist.\n- die Angabe eines `owner`, um die Ambulanz als verantwortliche Organisation zu dokumentieren.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Account",
  "baseDefinition" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKAbrechnungsfall",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Account",
      "path" : "Account"
    },
    {
      "id" : "Account.extension:AbrechnungsDiagnoseProzedur",
      "path" : "Account.extension",
      "sliceName" : "AbrechnungsDiagnoseProzedur",
      "comment" : "Im ambulanten Kontext ist es üblich, abrechnungsrelevante Diagnosen und Prozeduren anzugeben, ohne sie in Haupt- und Nebendiagnosen aufzuteilen. Da dies in der praxis trotzdem teilweise passiert, ist die Nutzung dieser Extension hier nicht ausgeschlossen."
    },
    {
      "id" : "Account.extension:AbrechnungsDiagnoseProzedurAmbulant",
      "path" : "Account.extension",
      "sliceName" : "AbrechnungsDiagnoseProzedurAmbulant",
      "short" : "Abrechnungsdiagnose /-prozedur",
      "comment" : "Diese Extension ermöglicht es, Diagnosen und Prozeduren als abrechnungsrelevant im Abrechnungskontext zu kennzeichnen, unabhängig von der *medizinischen* Relevanz, die in `Encounter.diagnosis` erfolgt.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/ISiKExtensionAbrechnungsDiagnoseProzedurAmbulant"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Scheinnummer",
      "path" : "Account.identifier",
      "sliceName" : "Scheinnummer",
      "short" : "Nummer des Scheins",
      "comment" : "Die Scheinnummer ist eine Nummer, die in der ambulanten Versorgung in Deutschland verwendet wird. Da im Krankenhaus und in den zum Einsatz kommenden Primärsystemen auch ambulante Leistungen erbracht und dokumentieert werden, kann es also vorkommen, dass neben einer Fallnummer auch eine Scheinnummer vorliegt. Diese ist allerdings vom System selber vergeben und wie die Fall- bzw. Patientennummer nicht eindeutig über Systemgrenzen hinweg.\n  \n  **Hinweis:**Im Kontext eines ambulanten BG Falls gibt es keine Scheinnummer.",
      "min" : 0,
      "max" : "1",
      "patternIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/isik/CodeSystem/ISiKIdentifierTypeErweiterungCS",
            "code" : "ASN"
          }]
        }
      },
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Scheinnummer.type",
      "path" : "Account.identifier.type",
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Scheinnummer.type.coding",
      "path" : "Account.identifier.type.coding",
      "short" : "Codierte Darstellung des Identifier-Typs"
    },
    {
      "id" : "Account.identifier:Scheinnummer.type.coding.system",
      "path" : "Account.identifier.type.coding.system",
      "short" : "Codier-Schema",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Scheinnummer.type.coding.code",
      "path" : "Account.identifier.type.coding.code",
      "short" : "Code",
      "comment" : "Hier ist stets der Wert `ASN` anzugeben.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Scheinnummer.system",
      "path" : "Account.identifier.system",
      "short" : "Namensraum des Identifiers",
      "comment" : "Hier ist stets der eindeutige Name (URL) des Namensraums anzugeben, \n    aus dem der Identifier stammt. \n    Hinweise zur Festlegung der URLs für lokale Namensräume sind in den \n    [Deutschen Basisprofilen](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Terminologie-Namensraeume?version=current) beschrieben.  \n    **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher.",
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Scheinnummer.value",
      "path" : "Account.identifier.value",
      "comment" : "Enthält den eigentlichen Wert des Identifiers.  \n    **Begründung Pflichtfeld:** Ist der Wert nicht bekannt, sollte der gesamte Slice weggelassen werden.",
      "mustSupport" : true
    },
    {
      "id" : "Account.servicePeriod",
      "path" : "Account.servicePeriod",
      "short" : "Gültigkeitszeitraum des Abrechnungsfalls",
      "comment" : "**Begründung MS:** Im Kontext der Abbildung von ambulanten Behandlungen im Krankenhaus ist die Angabe eines Gültigkeitszeitraum notwendig, da es sich hierbei um punktuelle Kontakte handelt und der Zeitraum der Gültigkeit nicht direkt aus den zugeordneten Encountern ableitbar ist.",
      "mustSupport" : true
    },
    {
      "id" : "Account.owner",
      "path" : "Account.owner",
      "short" : "Managende (abrechnende)Organisation",
      "comment" : "**Begründung MS:** Bei einer ambulanten Behandlung im Krankenhaus ist es wichtig, die Ambulanz als verantwortliche Organisation zu dokumentieren. Aus diesem Grund wurde hier ein MS ergänzt.\n  \n  **Hinweis:** Bei ambulanten Fällen steht nicht automatisch das Krankenhaus als abrechnende Organisation gegenüber dem Kostenträger auf der Rechnung. Deshlab ist es im ambulanten Kontext besonders wichtig, hier die Organisation anzugeben.",
      "mustSupport" : true
    },
    {
      "id" : "Account.owner.reference",
      "path" : "Account.owner.reference",
      "short" : "Organisation-Link",
      "mustSupport" : true
    },
    {
      "id" : "Account.owner.identifier",
      "path" : "Account.owner.identifier",
      "short" : "Identifier der managenden Organisation (Ambulanz)",
      "comment" : "Hier sind verschiedene im ambulanten Kontext vorkommende Identifier denkbar. Zur Orientierung wird im ISiK Kontext auf die Identifier einer [KBV Base Organization](https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Organization) verwiesen, da diese bereits die relevanten Identifier für die ambulante Versorgung enthält.",
      "mustSupport" : true
    },
    {
      "id" : "Account.owner.display",
      "path" : "Account.owner.display",
      "short" : "Name der managenden Organisation (Ambulanz)",
      "comment" : "Hier ist der Name der managenden Organisation anzugeben, beispielsweise die Ambulanz, die für die Behandlung verantwortlich ist.",
      "mustSupport" : true
    }]
  }
}

```
