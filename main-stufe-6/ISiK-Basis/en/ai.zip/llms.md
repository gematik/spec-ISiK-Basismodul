# basis#6.0.0: ISiK Basis Implementierungsleitfaden(en)

## Pages

* [Einführung](index.md)
* [Kompatibilität der gematik-Spezifikation](KompatibilitaetDerGematikSpezifikation_Andere.md)
* [Herstellung von Patienten- und Besuchskontext](Patient-Besuch-Kontext.md)
* [Datenübermittlung aus Subsystemen](Datenuebermittlung-aus-Subsystemen.md)
* [Abbildung des Konstrukts "Fall"](Abbildung-des-Konstrukts-Fall.md)
* [Umgang mit FHIR-Artefakten](UebergreifendeFestlegungen_FHIR_Artefakte.md)
* [Release Notes](ReleaseNotes.md)
* [Szenario 2: Kreuz-Stern-Diagnose](Szenario-2-Kreuz-Stern-Diagnose.md)
* [Must-Support-Flags](UebergreifendeFestlegungen_Must-Support-Flags.md)
* [Methodik](UebergreifendeFestlegungen_Methodik.md)
* [Bestätigungsrelevante Systeme](UebergreifendeFestlegungen_BestaetigungsrelevanteSysteme.md)
* [Motivation](Motivation.md)
* [Beispielszenarien](Index_Beispielszenarien.md)
* [Kompatibilität der gematik-Spezifikation HL7 Europe](KompatibilitaetDerGematikSpezifikation_HL7Europe.md)
* [Akteurs- und Rollenmodell](Erlaeuterung-Akteurs-und-Rollenmodell.md)
* [Performance](UebergreifendeFestlegungen_Performance.md)
* [FHIR-Artefakte](artifacts.md)
* [Repräsentationsformate](UebergreifendeFestlegungen_Repraesentationsformate.md)
* [Allgemeine Hinweise zu Suchparametern](UebergreifendeFestlegungen_Suchparameter.md)
* [REST-API](UebergreifendeFestlegungen_Rest.md)
* [Kompatibilität der gematik-Spezifikation IHE](KompatibilitaetDerGematikSpezifikation_IHE.md)
* [Umgang mit fehlenden Daten](UebergreifendeFestlegungen_UmgangFehlendeDaten.md)
* [Szenario 1: DRG-Fall, Kind mit Wahlleistung](Szenario-1-DRG-Fall-Kind-mit-Wahlleistung.md)
* [Festlegungen](Index_Festlegungen.md)

## Resources

### CodeSystems

* [TestKatalog](CodeSystem-CodeSystemExample.md)
* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [Erweiterung von Encounter.type in ISiK](CodeSystem-ISiKEncounterTypeErweiterungCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)

### ValueSets

* [DiagnosesSCT](ValueSet-DiagnosesSCT.md)
* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKEncounterClassDE](ValueSet-ISiKEncounterClassDE.md)
* [ISiKEncounterTypeErweiterungVS](ValueSet-ISiKEncounterTypeErweiterungVS.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)
* [TestValueSet](ValueSet-ISiKValueSetExample.md)
* [ProzedurenCodesSCT](ValueSet-ProzedurenCodesSCT.md)
* [ProzedurenKategorieSCT](ValueSet-ProzedurenKategorieSCT.md)
* [Schwangerschaft Erwarteter Entbindungstermin Methode](ValueSet-SchwangerschaftEtMethodeVS.md)
* [Schwangerschaftsstatus Valueset](ValueSet-SchwangerschaftsstatusVS.md)
* [Stillstatus LOINC Antwortoptionen](ValueSet-StillstatusVS.md)
* [Current Smoking Status - IPS](ValueSet-current-smoking-status-uv-ips.md)

### Complex-type Profiles

* [ISiKASKCoding](StructureDefinition-ISiKASKCoding.md)
* [ISiKATCCoding](StructureDefinition-ISiKATCCoding.md)
* [ISiKCoding](StructureDefinition-ISiKCoding.md)
* [ISiKICD10GMCoding](StructureDefinition-ISiKICD10GMCoding.md)
* [ISiKLoincCoding](StructureDefinition-ISiKLoincCoding.md)
* [ISiKSnomedCTCoding](StructureDefinition-ISiKSnomedCTCoding.md)

### Resource Profiles

* [ISiKAbrechnungsfall](StructureDefinition-ISiKAbrechnungsfall.md)
* [ISiKAbrechnungsfallAmbulant](StructureDefinition-ISiKAbrechnungsfallAmbulant.md)
* [ISiK Alkohol Abusus](StructureDefinition-ISiKAlkoholAbusus.md)
* [ISiKAllergieUnvertraeglichkeit](StructureDefinition-ISiKAllergieUnvertraeglichkeit.md)
* [ISiKAngehoeriger](StructureDefinition-ISiKAngehoeriger.md)
* [ISiKBerichtBundle](StructureDefinition-ISiKBerichtBundle.md)
* [ISiKBerichtSubSysteme](StructureDefinition-ISiKBerichtSubSysteme.md)
* [ISiKCodeSystem](StructureDefinition-ISiKCodeSystem.md)
* [ISiKDiagnose](StructureDefinition-ISiKDiagnose.md)
* [ISiKImplantat](StructureDefinition-ISiKImplantat.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKLebensZustand](StructureDefinition-ISiKLebensZustand.md)
* [ISiKOrganisation](StructureDefinition-ISiKOrganisation.md)
* [ISiKOrganisationFachabteilung](StructureDefinition-ISiKOrganisationFachabteilung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)
* [ISiKProzedur](StructureDefinition-ISiKProzedur.md)
* [ISiK Raucherstatus](StructureDefinition-ISiKRaucherStatus.md)
* [ISiKRolleImKrankenhaus](StructureDefinition-ISiKRolleImKrankenhaus.md)
* [ISiK Schwangerschaft - Erwarteter Entbindungstermin](StructureDefinition-ISiKSchwangerschaftErwarteterEntbindungstermin.md)
* [ISiK Schwangerschaftsstatus](StructureDefinition-ISiKSchwangerschaftsstatus.md)
* [ISiKStandort](StructureDefinition-ISiKStandort.md)
* [ISiKStandortBettenstellplatz](StructureDefinition-ISiKStandortBettenstellplatz.md)
* [ISiKStandortRaum](StructureDefinition-ISiKStandortRaum.md)
* [ISiKStillstatus](StructureDefinition-ISiKStillstatus.md)
* [ISiKValueSet](StructureDefinition-ISiKValueSet.md)
* [ISiKVersicherungsverhaeltnisGesetzlich](StructureDefinition-ISiKVersicherungsverhaeltnisGesetzlich.md)
* [ISiKVersicherungsverhaeltnisSelbstzahler](StructureDefinition-ISiKVersicherungsverhaeltnisSelbstzahler.md)
* [ISiKVersicherungsverhaeltnisSonstige](StructureDefinition-ISiKVersicherungsverhaeltnisSonstige.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)
* [Fallbezogene Abrechnungsrelevanz von Diagnosen und Prozeduren](StructureDefinition-ISiKExtensionAbrechnungsDiagnoseProzedurAmbulant.md)

### Accounts

* [AbrechnungsfallAmbulantMvzImKrankenhaus](Account-AbrechnungsfallAmbulantMvzImKrankenhaus.md)
* [AbrechnungsfallDRG](Account-AbrechnungsfallDRG.md)
* [AbrechnungsfallGonarthrose](Account-AbrechnungsfallGonarthrose.md)
* [SZ1DRGFall](Account-SZ1DRGFall.md)
* [SZ2DRGFall](Account-SZ2DRGFall.md)

### AllergyIntolerances

* [ISiKAllergieUnvertraeglichkeitBeispiel1](AllergyIntolerance-ISiKAllergieUnvertraeglichkeitBeispiel1.md)

### Bundles

* [BundleExampleIntensivstation](Bundle-BundleExampleIntensivstation.md)
* [ISiKBundle-Example](Bundle-ISiKBundle-Example.md)

### CapabilityStatements

* [CapabilityStatement für Rolle ISiKCapabilityStatementAmbulanteStammdatenRolle](CapabilityStatement-ISiKCapabilityStatementAmbulanteStammdatenRolle.md)
* [CapabilityStatement für Rolle AufbaustrukturRolle](CapabilityStatement-ISiKCapabilityStatementAufbaustrukturRolle.md)
* [Akteur ISiKCapabilityStatementBasisServerAkteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur-expanded.md)
* [Akteur ISiKCapabilityStatementBasisServerAkteur](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementCompositionKonsumentenRolle](CapabilityStatement-ISiKCapabilityStatementCompositionKonsumentenRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementErweiterteStammdatenRolle](CapabilityStatement-ISiKCapabilityStatementErweiterteStammdatenRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementGesundheitsstatusRolle](CapabilityStatement-ISiKCapabilityStatementGesundheitsstatusRolle.md)
* [CapabilityStatement für Rolle ImplantatRolle](CapabilityStatement-ISiKCapabilityStatementImplantatRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementKlinischeRolle](CapabilityStatement-ISiKCapabilityStatementKlinischeRolle.md)
* [CapabilityStatement für Rolle LeistungserbringerRolle](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)
* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementTerminologieRolle](CapabilityStatement-ISiKCapabilityStatementTerminologieRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementVersicherungsverhaeltnisRolle](CapabilityStatement-ISiKCapabilityStatementVersicherungsverhaeltnisRolle.md)

### Compositions

* [Blutdruckmessung vom 3.5.2022](Composition-CompositionExampleBlutdruck.md)

### Conditions

* [AkuteInfektionDerOberenAtemwege](Condition-AkuteInfektionDerOberenAtemwege.md)
* [AltersbedingteKreislaufstoerung](Condition-AltersbedingteKreislaufstoerung.md)
* [BehandlungsDiagnoseFreitext](Condition-BehandlungsDiagnoseFreitext.md)
* [Example-condition-ausrufezeichen-primaer](Condition-Example-condition-ausrufezeichen-primaer.md)
* [Example-condition-ausrufezeichen-sekundaer](Condition-Example-condition-ausrufezeichen-sekundaer.md)
* [Example-condition-kreuz-stern-primaer](Condition-Example-condition-kreuz-stern-primaer.md)
* [Example-condition-kreuz-stern-sekundaer](Condition-Example-condition-kreuz-stern-sekundaer.md)
* [PrimaereGonarthroseMinimal](Condition-PrimaereGonarthroseMinimal.md)
* [PrimaereGonarthroseNormal](Condition-PrimaereGonarthroseNormal.md)
* [SZ2Primaerdiagnose](Condition-SZ2Primaerdiagnose.md)
* [SZ2Sekundaerdiagnose](Condition-SZ2Sekundaerdiagnose.md)

### Coverages

* [CoverageGesetzlich](Coverage-CoverageGesetzlich.md)
* [CoveragePrivat](Coverage-CoveragePrivat.md)
* [CoverageSonstige](Coverage-CoverageSonstige.md)
* [SZ1VersicherungGesetzlich](Coverage-SZ1VersicherungGesetzlich.md)
* [SZ1VersicherungSelbstzahler](Coverage-SZ1VersicherungSelbstzahler.md)
* [SZ2VersicherungGesetzlich](Coverage-SZ2VersicherungGesetzlich.md)

### Devices

* [ISiKImplantatHerzschrittmacher](Device-ISiKImplantatHerzschrittmacher.md)
* [ISiKImplantatHueftprothese](Device-ISiKImplantatHueftprothese.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)
* [isik-encounter-Sternenfall](Encounter-isik-encounter-Sternenfall.md)

### ImplementationGuides

* [ISiK Basis Implementierungsleitfaden](ImplementationGuide-basis.md)

### Locations

* [BettenstellplatzStandortBeispiel](Location-BettenstellplatzStandortBeispiel.md)
* [Krankenhaus Standort](Location-KrankenhausStandortBeispiel.md)
* [RaumStandortBeispiel](Location-RaumStandortBeispiel.md)
* [Station A](Location-StationICUStandortBeispiel.md)
* [Station A](Location-StationPediaICUStandortBeispiel.md)
* [Station A](Location-StationStandortBeispiel.md)
* [Intensivstation Anaesthesie](Location-isik-station-anaesthesie.md)

### Observations

* [ISiKAlkoholAbususBeispiel](Observation-ISiKAlkoholAbususBeispiel.md)
* [ISiKRaucherStatusBeispiel](Observation-ISiKRaucherStatusBeispiel.md)
* [ISiKSchwangerschaftErwarteterEntbindungsterminBeispiel](Observation-ISiKSchwangerschaftErwarteterEntbindungsterminBeispiel.md)
* [ISiKSchwangerschaftsstatusBeispiel](Observation-ISiKSchwangerschaftsstatusBeispiel.md)
* [ISiKStillstatusBeispiel](Observation-ISiKStillstatusBeispiel.md)

### Organizations

* [Allgemeinchirurgie](Organization-AbteilungAllgemeinchirurgieOrganisationBeispiel.md)
* [Klinik für Intensivmedizin und Anästhesiologie](Organization-KlinikIntensivAnaesthesieOrganisationBeispiel.md)
* [Klinik Pädiatrie](Organization-KlinikPaediatrieOrganisationBeispiel.md)
* [Uniklinik Entenhausen](Organization-KrankenhausOrganisationBeispiel.md)

### Parameters

* [exp-params](Parameters-exp-params.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [IsikPatientTemplate](Patient-IsikPatientTemplate.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)
* [isik-patient-156722](Patient-isik-patient-156722.md)

### PractitionerRoles

* [RolleImKrankenhausAllgemeinchirurgieBeispiel](PractitionerRole-RolleImKrankenhausAllgemeinchirurgieBeispiel.md)
* [RolleImKrankenhausInnereMedizinBeispiel](PractitionerRole-RolleImKrankenhausInnereMedizinBeispiel.md)

### Practitioners

* [PractitionerWalterArzt](Practitioner-PractitionerWalterArzt.md)

### Procedures

* [Appendektomie](Procedure-Appendektomie.md)

### RelatedPeople

* [ISiKAngehoerigerMustermann](RelatedPerson-ISiKAngehoerigerMustermann.md)
* [SZ1Mutter](RelatedPerson-SZ1Mutter.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
* [form](SearchParameter-Location-form.md)
