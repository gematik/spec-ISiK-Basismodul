# ISiKAlkoholAbususBeispiel - ISiK Basis Implementierungsleitfaden v6.0.0

ISiK Basis Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiKAlkoholAbususBeispiel**

## Observation: ISiKAlkoholAbususBeispiel

Profile: [ISiK Alkohol Abusus](StructureDefinition-ISiKAlkoholAbusus.md)

**status**: Final

**code**: Schädlicher Gebrauch von Alkohol

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**encounter**: [Encounter: extension = ; identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Operation; serviceType = Innere Medizin; period = 2021-02-12 --> 2021-02-13](Encounter-Fachabteilungskontakt.md)

**effective**: 2024-01-01

**value**: Ja



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ISiKAlkoholAbususBeispiel",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/ISiKAlkoholAbusus"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/11000274103/version/20251115",
      "code" : "15167005",
      "display" : "Schädlicher Gebrauch von Alkohol"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.77",
      "code" : "74043-1",
      "display" : "Alcohol use disorder"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "encounter" : {
    "reference" : "Encounter/Fachabteilungskontakt"
  },
  "effectiveDateTime" : "2024-01-01",
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v2-0532",
      "code" : "Y",
      "display" : "Ja"
    }]
  }
}

```
