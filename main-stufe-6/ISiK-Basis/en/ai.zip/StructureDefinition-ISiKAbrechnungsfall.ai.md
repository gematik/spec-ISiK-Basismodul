# ISiKAbrechnungsfall - ISiK Basis Implementierungsleitfaden v6.0.0

ISiK Basis Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiKAbrechnungsfall**

## Resource Profile: ISiKAbrechnungsfall 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKAbrechnungsfall | *Version*:6.0.0 |
| Active as of 2026-07-01 | *Computable Name*:ISiKAbrechnungsfall |

 
Dieses Profil ermöglicht die Gruppierung von medizinischen Leistungen zu einem gemeinsamen Abrechnungskontext.
 Zugleich dient es im Kontext von ISiK derzeit im Wesentlichen der Abbildung einer Fallnummer, über die im Krankenhaus unterschiedliche Prozesse - auch administrativer Natur - abgewickelt werden. Das Profil wurde **nicht** primär zum Zweck der Abbildung von Abrechnungsprozessen definiert. 
**Motivation** 
Komplementär zum Datenobjekt 'Kontakt - Encounter' können Fälle, im Sinne einer Gruppierung von medizinischen Leistungen innerhalb eines gemeinsamen Kontextes, zu einem Abrechnungsfall zusammengefasst werden. Ein solcher Abrechnungsfall kann mehrere Kontakte umfassen (z.B. vorstationärer Besuch, stationärer Aufenthalt und nachstationärer Besuch). 
Gemeinsam mit dem Einrichtungskontakt bildet der Abrechnungsfall einen wichtigen Einstiegspunkt in die Dokumentation der Behandlungsleistungen der Patienten. Als Bindeglied zwischen den Kontakten und dem Versicherungsverhältnis erfolgt eine feingranulare Auflistung, in welchen Zeiträumen ein Behandlungskontext zwischen einer Gesundheitseinrichtung und der Patienten bestand. Zudem werden Diagnosen abschließend / nachträglich dokumentiert, sodass eine Übersicht von relevanten (DRG)-Diagnosen ermöglicht wird, ohne die Gesamtheit aller Kontakte betrachten zu müssen. 
In FHIR wird der Abrechnungsfall mit der `Account`-Ressource repräsentiert. 
Weitere Hinweise zu den Abgrenzungen der Begrifflichkeiten Fall und Kontakt finden sie unter [Fall-Begriff in ISiK](https://gemspec.gematik.de/ig/fhir/isik/basis/6.0.0-rc1/Abbildung-des-Konstrukts-Fall.html). 
**Kompatibilität** 
* zum Zeitpunkt der Veröffentlichung sind keine abweichenden Modellierungen der Account-Ressource bekannt.
 
Hinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden. 

**Usages:**

* Derived from this Profile: [ISiKAbrechnungsfallAmbulant](StructureDefinition-ISiKAbrechnungsfallAmbulant.md)
* Examples for this Profile: [Account/AbrechnungsfallDRG](Account-AbrechnungsfallDRG.md), [Account/AbrechnungsfallGonarthrose](Account-AbrechnungsfallGonarthrose.md), [Account/SZ1DRGFall](Account-SZ1DRGFall.md) and [Account/SZ2DRGFall](Account-SZ2DRGFall.md)
* CapabilityStatements using this Profile: [Akteur ISiKCapabilityStatementBasisServerAkteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur-expanded.md) and [CapabilityStatement für Rolle ISiKCapabilityStatementVersicherungsverhaeltnisRolle](CapabilityStatement-ISiKCapabilityStatementVersicherungsverhaeltnisRolle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/basis|current/StructureDefinition/StructureDefinition-ISiKAbrechnungsfall.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-ISiKAbrechnungsfall.csv), [Excel](../StructureDefinition-ISiKAbrechnungsfall.xlsx), [Schematron](../StructureDefinition-ISiKAbrechnungsfall.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKAbrechnungsfall",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKAbrechnungsfall",
  "version" : "6.0.0",
  "name" : "ISiKAbrechnungsfall",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    }]
  }],
  "description" : "Dieses Profil ermöglicht die Gruppierung von medizinischen Leistungen zu einem gemeinsamen Abrechnungskontext.  \nZugleich dient es im Kontext von ISiK derzeit im Wesentlichen der Abbildung einer Fallnummer, über die im Krankenhaus unterschiedliche Prozesse - auch administrativer Natur - abgewickelt werden. Das Profil wurde *nicht* primär zum Zweck der Abbildung von Abrechnungsprozessen definiert. \n\n**Motivation**\n\nKomplementär zum Datenobjekt 'Kontakt - Encounter' können Fälle, im Sinne einer Gruppierung von medizinischen Leistungen \ninnerhalb eines gemeinsamen Kontextes, zu einem Abrechnungsfall zusammengefasst werden.\nEin solcher Abrechnungsfall kann mehrere Kontakte umfassen (z.B. vorstationärer Besuch, stationärer Aufenthalt und nachstationärer Besuch).  \n\nGemeinsam mit dem Einrichtungskontakt bildet der Abrechnungsfall einen wichtigen Einstiegspunkt in die Dokumentation der Behandlungsleistungen der Patienten.\nAls Bindeglied zwischen den Kontakten und dem Versicherungsverhältnis erfolgt eine feingranulare Auflistung, \nin welchen Zeiträumen ein Behandlungskontext zwischen einer Gesundheitseinrichtung und der Patienten bestand.\nZudem werden Diagnosen abschließend / nachträglich dokumentiert, sodass eine Übersicht von relevanten (DRG)-Diagnosen ermöglicht wird, \nohne die Gesamtheit aller Kontakte betrachten zu müssen.\n\nIn FHIR wird der Abrechnungsfall mit der `Account`-Ressource repräsentiert.\n\nWeitere Hinweise zu den Abgrenzungen der Begrifflichkeiten Fall und Kontakt finden sie unter [Fall-Begriff in ISiK](https://gemspec.gematik.de/ig/fhir/isik/basis/6.0.0-rc1/Abbildung-des-Konstrukts-Fall.html).\n\n**Kompatibilität**\n\n* zum Zeitpunkt der Veröffentlichung sind keine abweichenden Modellierungen der Account-Ressource bekannt.\n\nHinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Account",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Account",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Account",
      "path" : "Account"
    },
    {
      "id" : "Account.id",
      "path" : "Account.id",
      "short" : "serverseitige, interne ID des Datensatzes",
      "comment" : "**bedingtes Pflichtfeld/bedingtes MS:** Alle von einem Server bereitgestellten Ressourcen MÜSSEN über eine `id` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `id`verfügen. ",
      "mustSupport" : true
    },
    {
      "id" : "Account.meta.versionId",
      "path" : "Account.meta.versionId",
      "short" : "Eindeutiger Name der serverseitigen Version des Datensatzes",
      "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über eine `versionID` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `versionID`verfügen. "
    },
    {
      "id" : "Account.meta.lastUpdated",
      "path" : "Account.meta.lastUpdated",
      "short" : "Zeitpunkt der letzten Änderung",
      "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über ein `lastUpdate` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über ein `lastUpdate`verfügen. "
    },
    {
      "id" : "Account.implicitRules",
      "path" : "Account.implicitRules",
      "short" : "Verweis auf die Regeln, nach denen die Ressource erstellt wurde",
      "comment" : "Begründung Constraint: In ISiK existiert kein Use-Case für dieses Element. Da es sich um ein Modifying Element handelt, wird es daher ausgeschlossen.\n  Darüber hinaus werden die Regeln als URI vorgehalten. Dies führt dazu, dass sich hinter der URI eine beliebige Menge an Regeln befinden kann; wodurch  nicht sichergestellt werden kann, dass alle Clients die Regeln korrekt interpretieren können.",
      "max" : "0"
    },
    {
      "id" : "Account.extension",
      "path" : "Account.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "mustSupport" : true
    },
    {
      "id" : "Account.extension:AbrechnungsDiagnoseProzedur",
      "path" : "Account.extension",
      "sliceName" : "AbrechnungsDiagnoseProzedur",
      "short" : "Abrechnungsdiagnose /-prozedur",
      "comment" : "Insbesondere bei Abrechnungen im DRG-Kontext muss eine Diagnose als Hauptdiagnose und \n  ggf. weitere Diagnosen als abrechnungsrelevante Nebendiagnosen klassifiziert werden. Diese Extension ermöglicht es, diese Qualifikation im Abrechnungskontext vorzunehmen, \n  unabhängig von der *medizinischen* Relevanz, die in `Encounter.diagnosis` erfolgt.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://fhir.de/StructureDefinition/ExtensionAbrechnungsDiagnoseProzedur"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Account.extension:AbrechnungsDiagnoseProzedur.extension:Use",
      "path" : "Account.extension.extension",
      "sliceName" : "Use",
      "mustSupport" : true
    },
    {
      "id" : "Account.extension:AbrechnungsDiagnoseProzedur.extension:Referenz",
      "path" : "Account.extension.extension",
      "sliceName" : "Referenz",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier",
      "path" : "Account.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "short" : "Eindeutiger Identifier",
      "comment" : "Über die mit MS gekennzeichneten Slices hinaus können weitere Identifier vorkommen, ohne, dass eine ISiK Inkompatibilität besteht. Verarbeitet werden müssen aber nur die folgenden Slices.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Abrechnungsnummer",
      "path" : "Account.identifier",
      "sliceName" : "Abrechnungsnummer",
      "short" : "Abrechnungsfallnummer",
      "comment" : "Im DRG-Kontext werden häufig sämtliche Besuche (`Encounter`), die unter einen gemeinsamen Abrechnungskontext zusammengefasst werden, \n  unter einer 'Fallnummer' geführt. In dieser Konstellation sind die Begriffe 'Fallnummer' und 'Abrechnungsfallnummer' gleichbedeutend.  \n  Dies ist insbesondere im Kontext des Mappings zwischen HL7 V2 und HL7 FHIR zu beachten, da es in V2 Usus ist, \n  die Fallnummer (eigentlich Identifier des Abrechnungsfalles) im `PV1`-Segment (Patient Visit) zu übermitteln. \n  Es handelt sich dabei jedoch *nicht* um den Identifier des Besuchs (`Encounter`) sondern den des Abrechnungsfalles (`Account`), \n  da der Identifier oft für die Gruppierung mehrerer Besuche (z.B. vorstationär + stationär + nachstationär) mit gemeinsamem (DRG)-Kontext verwendet wird.  \n  Die Abrechnungsfallnummer in `Account.identifier` muss identisch sein mit dem Identifier, \n  der bei den Encountern, die unter diesem Account gruppiert werden, unter `Encounter.account.identifier` angegeben ist.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-abrechnungsnummer"]
      }],
      "patternIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "AN"
          }]
        }
      },
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Abrechnungsnummer.type",
      "path" : "Account.identifier.type",
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Abrechnungsnummer.type.coding",
      "path" : "Account.identifier.type.coding",
      "short" : "Codierte Darstellung des Identifier-Typs"
    },
    {
      "id" : "Account.identifier:Abrechnungsnummer.type.coding.system",
      "path" : "Account.identifier.type.coding.system",
      "short" : "Codier-Schema",
      "comment" : "Hier ist stets der Wert `http://terminology.hl7.org/CodeSystem/v2-0203` anzugeben.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Abrechnungsnummer.type.coding.code",
      "path" : "Account.identifier.type.coding.code",
      "short" : "Code",
      "comment" : "Hier ist stets der Wert `AN` anzugeben.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Abrechnungsnummer.system",
      "path" : "Account.identifier.system",
      "short" : "Namensraum des Identifiers",
      "comment" : "Hier ist stets der eindeutige Name (URL) des Namensraums anzugeben, \n    aus dem der Identifier stammt. \n    Hinweise zur Festlegung der URLs für lokale Namensräume sind in den \n    [Deutschen Basisprofilen](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Terminologie-Namensraeume?version=current) beschrieben.  \n    **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher.",
      "mustSupport" : true
    },
    {
      "id" : "Account.identifier:Abrechnungsnummer.value",
      "path" : "Account.identifier.value",
      "comment" : "Enthält den eigentlichen Wert des Identifiers.  \n    **Begründung Pflichtfeld:** Ist der Wert nicht bekannt, sollte der gesamte Slice weggelassen werden.",
      "mustSupport" : true
    },
    {
      "id" : "Account.status",
      "path" : "Account.status",
      "short" : "Status",
      "comment" : "Zeigt den aktuellen Status der Ressource an.     \n  **WICHTIGER Hinweis für Implementierer:**    \n  * Alle server-seitigen Implementierungen MÜSSEN in der Lage sein, \n  die systemintern möglichen Statuswerte korrekt in FHIR abzubilden, mindestens jedoch `active` und `inactive`.\n  * Alle client-seitigen Implementierungen MÜSSEN in der Lage sein, sämtliche Status-Codes zu interpretieren und dem Anwender in angemessener Form darstellen zu können, \n  beispielsweise durch Ausblenden/Durchstreichen von Ressourcen mit dem status `entered-in-error` und Ausgrauen von Ressourcen, die einen Plan- oder Entwurfs-Status haben.",
      "mustSupport" : true
    },
    {
      "id" : "Account.subject",
      "path" : "Account.subject",
      "short" : "Patientenbezug",
      "comment" : "**Begründung Pflichtfeld:** Ein Patientenbezug des Falls muss stets zum Zwecke der Nachvollziehbarkeit und Datenintegrität vorliegen.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Account.subject.reference",
      "path" : "Account.subject.reference",
      "short" : "Patienten-Link",
      "comment" : "**Begründung Pflichtfeld:** Die Verlinkung auf eine Patienten-Ressource dient der technischen Zuordnung der Dokumentation zu einem Patienten und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.\nIm ISik Kontext MUSS die referenzierte Ressource konform zu [ISiKPatient](https://gematik.de/fhir/isik/StructureDefinition/ISiKPatient) sein.\nJenseits von ISiK KÖNNEN weitere Instanzen mit anderen Profilen referenziert werden.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Account.coverage",
      "path" : "Account.coverage",
      "short" : "Versicherungs-/Zahlungsverhältnis",
      "comment" : "Auflistung aller Versicherungs- und oder (Selbst-/Fremd-)zahlerverhältnisse, die zur Abrechnung der in diesem Kontext erbrachten Leistungen herangezogen werden können.",
      "mustSupport" : true
    },
    {
      "id" : "Account.coverage.extension",
      "path" : "Account.coverage.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "mustSupport" : true
    },
    {
      "id" : "Account.coverage.extension:Abrechnungsart",
      "path" : "Account.coverage.extension",
      "sliceName" : "Abrechnungsart",
      "short" : "Abrechnungsart",
      "comment" : "Art der Abrechnung, für die das Versicherungsverhältnis herangezogen wird. Die Abrechnungsart bezieht sich auf die Hauptversicherung über die der Fall abgerechnet wird. Bei initialen Fallanlage kann es vorkommen, dass die Abrechnungsart noch nicht bekannt ist (z.B. Unklare Versicherungszugehörigkeit, Rückfragen an den Kostenträger, Ungeklärte Zusatzleistungen). Sobald bekannt, SOLL angegeben werden, in welcher Abrechnungsart die Abrechnung erfolgt.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://fhir.de/StructureDefinition/ExtensionAbrechnungsart"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Account.coverage.coverage",
      "path" : "Account.coverage.coverage",
      "mustSupport" : true
    },
    {
      "id" : "Account.coverage.coverage.reference",
      "path" : "Account.coverage.coverage.reference",
      "short" : "Coverage-Link",
      "comment" : "**Begründung Pflichtfeld:** Die Verlinkung auf eine Coverage-Ressource dient der technischen Zuordnung zwischen Abrechnungsfall und Versicherungsverhältnis\n    und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Account.coverage.priority",
      "path" : "Account.coverage.priority",
      "short" : "Priorität",
      "comment" : "**Begründung des MS:** Wenn ein Primärsystem mehrere Kostenträger angibt, \n    sollte für lesende Systeme ersichtlich sein, welches der Hauptkostenträger ist. Hierbei ist die Priorisierung aufsteigend zu interpretieren. Demnach hat der Kostenträger mit der priority 1 die höchste Priorität, der mit priority 2 die zweithöchste Priorität etc.      \n    **Historie:**  \n    Diskussionstand der ISIK-Arbeitsgruppe vom 28.5.: Die Abbildung über einen Integer ist wünschenswert. \n    Eine binäre Einteilung in Hauptkostenträger (1) und alle anderen (2) wird der Komplexität der Priorisierung zur Kostenträgerschaft nicht gerecht. \n    Eine Ausdifferenzierung ist wünschenswert und sollte angestrebt werden.",
      "mustSupport" : true
    }]
  }
}

```
