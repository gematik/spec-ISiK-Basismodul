# ISiKRaucherStatusBeispiel - ISiK Basis Implementierungsleitfaden v6.0.0

ISiK Basis Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiKRaucherStatusBeispiel**

## Observation: ISiKRaucherStatusBeispiel

Profile: [ISiK Raucherstatus](StructureDefinition-ISiKRaucherStatus.md)

**status**: Final

**code**: Raucher

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**encounter**: [Encounter: extension = ; identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Operation; serviceType = Innere Medizin; period = 2021-02-12 --> 2021-02-13](Encounter-Fachabteilungskontakt.md)

**effective**: 2024-01-01

**value**: Former smoker



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ISiKRaucherStatusBeispiel",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/ISiKRaucherStatus"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/11000274103/version/20251115",
      "code" : "77176002",
      "display" : "Raucher"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.77",
      "code" : "72166-2",
      "display" : "Raucherstatus"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "encounter" : {
    "reference" : "Encounter/Fachabteilungskontakt"
  },
  "effectiveDateTime" : "2024-01-01",
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "version" : "2.77",
      "code" : "LA15920-4",
      "display" : "Former smoker"
    }]
  }
}

```
