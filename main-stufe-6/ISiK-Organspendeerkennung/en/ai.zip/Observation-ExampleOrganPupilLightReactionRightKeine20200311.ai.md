# ExampleOrganPupilLightReactionRightKeine20200311 - ISiK Organspendeerkennung v6.0.0

ISiK Organspendeerkennung

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ExampleOrganPupilLightReactionRightKeine20200311**

## Observation: ExampleOrganPupilLightReactionRightKeine20200311

Profile: [MII PR ICU Untersuchung Pupillenlichtreaktion Direkt](StructureDefinition-mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt.md)

**status**: Final

**category**: Exam

**code**: Pupil afferent light reaction

**subject**: [Aelin Sternenfall (official) Unknown, DoB: ( Medical record number)](Patient-isik-patient-156722.md)

**effective**: 2020-03-11 20:17:06+0100

**value**: Not reactive to light

**note**: 

> 

Quelle: right pupil reaction = keine


**bodySite**: Structure of pupil of right eye



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ExampleOrganPupilLightReactionRightKeine20200311",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "exam",
      "display" : "Exam"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "45832002",
      "display" : "Pupil afferent light reaction"
    }]
  },
  "subject" : {
    "reference" : "Patient/isik-patient-156722"
  },
  "effectiveDateTime" : "2020-03-11T20:17:06+01:00",
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "LA25442-7",
      "display" : "Not reactive to light"
    }]
  },
  "note" : [{
    "text" : "Quelle: right pupil reaction = keine"
  }],
  "bodySite" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "52378001",
      "display" : "Structure of pupil of right eye"
    }]
  }
}

```
