# MII VS ICU Code Observation Beatmung LOINC - ISiK Organspendeerkennung v6.0.0

ISiK Organspendeerkennung

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **MII VS ICU Code Observation Beatmung LOINC**

## ValueSet: MII VS ICU Code Observation Beatmung LOINC 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/ValueSet/mii-vs-icu-code-observation-beatmung-loinc | *Version*:6.0.0 |
| Active as of 2026-07-01 | *Computable Name*:MII_VS_ICU_Code_Observation_Beatmung_LOINC |

 
Dieses ValueSet enthält Codes für die im Kontext einer Beatmung verwendeten Parameter. 
Die Datenstruktur wurde dem laufenden Stand der Entwicklung des MII ICU Module entnommen - https://github.com/medizininformatik-initiative/kerndatensatzmodul-intensivmedizin/blob/master/input/fsh/valuesets - Details zur Kompatibilität mit dem ISiK Package der Stufe 6 wurden angepasst und Metadaten des Ursprungsschemas zum Teil entfernt. Stand 16.03.2026 

 **References** 

* [MII PR ICU Parameter von Beatmung](StructureDefinition-mii-pr-vent-icu-parameter-von-beatmung.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-icu-code-observation-beatmung-loinc",
  "url" : "https://gematik.de/fhir/isik/ValueSet/mii-vs-icu-code-observation-beatmung-loinc",
  "version" : "6.0.0",
  "name" : "MII_VS_ICU_Code_Observation_Beatmung_LOINC",
  "title" : "MII VS ICU Code Observation Beatmung LOINC",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    }]
  }],
  "description" : "Dieses ValueSet enthält Codes für die im Kontext einer Beatmung verwendeten Parameter.\n\nDie Datenstruktur wurde dem laufenden Stand der Entwicklung des MII ICU Module entnommen - https://github.com/medizininformatik-initiative/kerndatensatzmodul-intensivmedizin/blob/master/input/fsh/valuesets - Details zur Kompatibilität mit dem ISiK Package der Stufe 6 wurden angepasst und Metadaten des Ursprungsschemas zum Teil entfernt. Stand 16.03.2026",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "50984-4",
        "display" : "Horowitz index in Arterial blood"
      },
      {
        "code" : "33438-3",
        "display" : "Breath rate mechanical --on ventilator"
      },
      {
        "code" : "19839-0",
        "display" : "Breath rate spontaneous --on ventilator"
      },
      {
        "code" : "19840-8",
        "display" : "Breath rate spontaneous and mechanical --on ventilator"
      },
      {
        "code" : "76334-2",
        "display" : "Inspiratory time setting Ventilator"
      },
      {
        "code" : "76187-4",
        "display" : "Expiratory hold time setting Ventilator"
      },
      {
        "code" : "75931-6",
        "display" : "Inspiration/Expiration time Ratio"
      },
      {
        "code" : "20112-9",
        "display" : "Tidal volume setting Ventilator"
      },
      {
        "code" : "76222-9",
        "display" : "Tidal volume Ventilator --on ventilator"
      },
      {
        "code" : "20116-0",
        "display" : "Tidal volume.spontaneous --on ventilator"
      },
      {
        "code" : "76009-0",
        "display" : "Inspired minute Volume during Mechanical ventilation"
      },
      {
        "code" : "20118-6",
        "display" : "Tidal volume.spontaneous+mechanical --on ventilator"
      },
      {
        "code" : "76190-8",
        "display" : "High pressure hold time setting Ventilator"
      },
      {
        "code" : "76229-4",
        "display" : "Low pressure hold time setting Ventilator"
      },
      {
        "code" : "76275-7",
        "display" : "Inspiratory flow setting Ventilator"
      },
      {
        "code" : "60794-5",
        "display" : "Inspiratory gas flow Respiratory system airway --on ventilator"
      },
      {
        "code" : "60792-9",
        "display" : "Expiratory gas flow Respiratory system airway --on ventilator"
      },
      {
        "code" : "19994-3",
        "display" : "Oxygen/Total gas setting [Volume Fraction] Ventilator"
      },
      {
        "code" : "71835-3",
        "display" : "Oxygen/Gas total [Pure volume fraction] Inhaled gas"
      },
      {
        "code" : "3147-6",
        "display" : "Oxygen [Partial pressure] in Exhaled gas"
      },
      {
        "code" : "76530-5",
        "display" : "Mean pressure Respiratory system airway --on ventilator"
      },
      {
        "code" : "76531-3",
        "display" : "Pressure.max Respiratory system airway --on ventilator"
      },
      {
        "code" : "60827-3",
        "display" : "Dynamic lung compliance"
      },
      {
        "code" : "76248-4",
        "display" : "PEEP Respiratory system --on ventilator"
      },
      {
        "code" : "76154-4",
        "display" : "Airway pressure delta --on ventilator"
      },
      {
        "code" : "20056-8",
        "display" : "Airway pressure --at mean expiratory flow on ventilator"
      },
      {
        "code" : "20060-0",
        "display" : "Airway pressure --at zero inspiratory flow on ventilator"
      },
      {
        "code" : "19891-1",
        "display" : "Carbon dioxide [Partial pressure] in Exhaled gas --at end expiration"
      },
      {
        "code" : "20079-0",
        "display" : "Pressure support setting Ventilator"
      }]
    }]
  }
}

```
