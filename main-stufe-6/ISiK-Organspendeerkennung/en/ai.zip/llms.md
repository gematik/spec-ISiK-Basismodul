# organspendeerkennung#6.0.0: ISiK Organspendeerkennung(en)

## Pages

* [Einführung](index.md)
* [Prozesse und Workflows](ProzesseUndWorkflows.md)
* [Release Notes](ReleaseNotes.md)
* [Akteure](Akteure.md)
* [Festlegungen](Festlegungen.md)
* [FHIR-Artefakte](artifacts.md)
* [Use Cases und Anwendungskontexte](Index_UseCaseAnwendung.md)

## Resources

### CodeSystems

* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [Erweiterung von Encounter.type in ISiK](CodeSystem-ISiKEncounterTypeErweiterungCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)

### ValueSets

* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKEncounterClassDE](ValueSet-ISiKEncounterClassDE.md)
* [ISiKEncounterTypeErweiterungVS](ValueSet-ISiKEncounterTypeErweiterungVS.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiK Labor Methode](ValueSet-ISiKLaborMethodeVS.md)
* [ISiK Laborbereich](ValueSet-ISiKLaborbereichVS.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)
* [ObservationCodesSerumnatrium](ValueSet-ObservationCodesSerumnatrium.md)
* [ObservationUnitsSerumnatrium](ValueSet-ObservationUnitsSerumnatrium.md)
* [ProzedurenCodesSCT](ValueSet-ProzedurenCodesSCT.md)
* [ProzedurenKategorieSCT](ValueSet-ProzedurenKategorieSCT.md)
* [ProzedurenReanimationCodesOPS](ValueSet-ProzedurenReanimationCodesOPS.md)
* [ProzedurenReanimationCodesSCT](ValueSet-ProzedurenReanimationCodesSCT.md)
* [MII VS ICU BodySite Observation Beatmung](ValueSet-mii-vs-icu-body-site-observation-beatmung.md)
* [MII VS ICU BodySite Observation Pupillenbefund](ValueSet-mii-vs-icu-bodysite-observation-pupillenbefund.md)
* [MII VS ICU Category Procedure Beatmung SNOMED](ValueSet-mii-vs-icu-category-procedure-beatmung-snomed.md)
* [MII VS ICU Code Observation Beatmung ISO11073](ValueSet-mii-vs-icu-code-observation-beatmung-loinc-iso11073.md)
* [MII VS ICU Code Observation Beatmung LOINC](ValueSet-mii-vs-icu-code-observation-beatmung-loinc.md)
* [MII VS ICU Code Observation Beatmung SNOMED](ValueSet-mii-vs-icu-code-observation-beatmung-snomed.md)
* [MII VS ICU Code Observation Pupillengroesse](ValueSet-mii-vs-icu-code-observation-pupillengroesse.md)
* [MII VS ICU Code Observation Pupillenlichtreaktion](ValueSet-mii-vs-icu-code-observation-pupillenlichtreaktion.md)
* [MII VS ICU Code Observation Pupillensymmetrie](ValueSet-mii-vs-icu-code-observation-pupillensymmetrie.md)
* [MII VS ICU Code Observation Pupillenform LOINC](ValueSet-mii-vs-icu-code-oservation-pupillenform-loinc.md)
* [MII VS ICU Code Procedure Beatmung SNOMED](ValueSet-mii-vs-icu-code-procedure-beatmung-snomed.md)
* [MII VS ICU Score RASS](ValueSet-mii-vs-icu-score-rass.md)
* [VS MII ICU BodySite Observation Monitoring und Vitaldaten](ValueSet-vs-mii-icu-bodysite-observation-monitoring-und-vitaldaten.md)
* [VS MII ICU Code Monitoring und Vitaldaten [ISO11073]](ValueSet-vs-mii-icu-code-monitoring-und-vitaldaten-iso11073.md)
* [VS MII ICU Code Monitoring und Vitaldaten [LOINC]](ValueSet-vs-mii-icu-code-monitoring-und-vitaldaten-loinc.md)
* [VS MII ICU Code Monitoring und Vitaldaten [sct]](ValueSet-vs-mii-icu-code-monitoring-und-vitaldaten-snomed.md)

### Complex-type Profiles

* [ISiKCoding](StructureDefinition-ISiKCoding.md)
* [ISiKLoincCoding](StructureDefinition-ISiKLoincCoding.md)
* [ISiKSnomedCTCoding](StructureDefinition-ISiKSnomedCTCoding.md)

### Resource Profiles

* [ISiKGCS](StructureDefinition-ISiKGCS.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKLaboruntersuchung](StructureDefinition-ISiKLaboruntersuchung.md)
* [ISiKLaboruntersuchungSerumnatrium](StructureDefinition-ISiKLaboruntersuchungSerumnatrium.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKProzedur](StructureDefinition-ISiKProzedur.md)
* [ISiK Prozedur Beatmung](StructureDefinition-ISiKProzedurBeatmung.md)
* [ISiK Prozedur Reanimation](StructureDefinition-ISiKProzedurReanimation.md)
* [ISiKStandort](StructureDefinition-ISiKStandort.md)
* [MII PR ICU MUV zerebraler Perfusionsdruck](StructureDefinition-mii-pr-icu-muv-zerebraler-perfusionsdruck.md)
* [MII PR ICU Score RASS](StructureDefinition-mii-pr-icu-score-rass.md)
* [MII PR ICU Untersuchung Pupillenbefund](StructureDefinition-mii-pr-icu-untersuchung-pupillenbefund.md)
* [MII PR ICU Untersuchung Pupillenform](StructureDefinition-mii-pr-icu-untersuchung-pupillenform.md)
* [MII PR ICU Untersuchung Pupillengroesse](StructureDefinition-mii-pr-icu-untersuchung-pupillengroesse.md)
* [MII PR ICU Untersuchung Pupillenlichtreaktion Direkt](StructureDefinition-mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt.md)
* [MII PR ICU Untersuchung Pupillenlichtreaktion Indirekt](StructureDefinition-mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt.md)
* [MII PR ICU Untersuchung Pupillensymmetrie](StructureDefinition-mii-pr-icu-untersuchung-pupillensymmetrie.md)
* [MII PR ICU Spontane Atemfrequenz Beatmet](StructureDefinition-mii-pr-icu-vent-spontane-atemfrequenz-beatmet.md)
* [MII PR ICU Spontanes Atemzugvolumen](StructureDefinition-mii-pr-icu-vent-spontanes-atemzugvolumen.md)
* [MII PR ICU Unterstuezungsdruck Beatmung](StructureDefinition-mii-pr-icu-vent-unterstuezungsdruck-beatmung.md)
* [MII PR ICU Parameter von Beatmung](StructureDefinition-mii-pr-vent-icu-parameter-von-beatmung.md)
* [SD MII ICU Intrakranieller Druck ICP](StructureDefinition-sd-mii-icu-intrakranieller-druck-icp.md)
* [SD MII ICU Monitoring und Vitaldaten](StructureDefinition-sd-mii-icu-monitoring-und-vitaldaten.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)

### CapabilityStatements

* [CapabilityStatement für Rolle ISiKCapabilityStatementErweiterteStammdatenRolle](CapabilityStatement-ISiKCapabilityStatementErweiterteStammdatenRolle.md)
* [ISiK CapabilityStatement Organspendeerkennung Server (Expanded)](CapabilityStatement-ISiKCapabilityStatementOrganspendeerkennungSourceAkteur-expanded.md)
* [ISiK CapabilityStatement Organspendeerkennung Server](CapabilityStatement-ISiKCapabilityStatementOrganspendeerkennungSourceAkteur.md)
* [ISiK CapabilityStatement Organspendeerkennung Source Rolle](CapabilityStatement-ISiKCapabilityStatementOrganspendeerkennungSourceRolle.md)
* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)
* [isik-encounter-Sternenfall](Encounter-isik-encounter-Sternenfall.md)

### ImplementationGuides

* [ISiK Organspendeerkennung](ImplementationGuide-organspendeerkennung.md)

### Locations

* [Krankenhaus Standort](Location-KrankenhausStandortBeispiel.md)
* [Station A](Location-StationICUStandortBeispiel.md)
* [Station A](Location-StationPediaICUStandortBeispiel.md)
* [Station A](Location-StationStandortBeispiel.md)
* [Intensivstation Anaesthesie](Location-isik-station-anaesthesie.md)

### Observations

* [ExampleISiKLaboruntersuchungMaximal](Observation-ExampleISiKLaboruntersuchungMaximal.md)
* [ExampleISiKLaboruntersuchungSerumnatrium1](Observation-ExampleISiKLaboruntersuchungSerumnatrium1.md)
* [ExampleOrganPupilLightReactionLeft20200311](Observation-ExampleOrganPupilLightReactionLeft20200311.md)
* [ExampleOrganPupilLightReactionLeftPrompt20200311](Observation-ExampleOrganPupilLightReactionLeftPrompt20200311.md)
* [ExampleOrganPupilLightReactionLeftVerzogert20200311](Observation-ExampleOrganPupilLightReactionLeftVerzogert20200311.md)
* [ExampleOrganPupilLightReactionRight20200311](Observation-ExampleOrganPupilLightReactionRight20200311.md)
* [ExampleOrganPupilLightReactionRightKeine20200311](Observation-ExampleOrganPupilLightReactionRightKeine20200311.md)
* [ExampleOrganRASS20200311](Observation-ExampleOrganRASS20200311.md)
* [ExampleOrganSerumNatrium202003110104](Observation-ExampleOrganSerumNatrium202003110104.md)
* [ExampleOrganSerumNatrium202003110159](Observation-ExampleOrganSerumNatrium202003110159.md)
* [ExampleOrganSerumNatrium202003110306](Observation-ExampleOrganSerumNatrium202003110306.md)
* [ISiKGCSExample](Observation-ISiKGCSExample.md)
* [ISiKGCSMaxExample](Observation-ISiKGCSMaxExample.md)
* [ISiKGCSMinExample](Observation-ISiKGCSMinExample.md)
* [Intrakranieller-Druck-ICP](Observation-Intrakranieller-Druck-ICP.md)

### Parameters

* [exp-params](Parameters-exp-params.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [IsikPatientTemplate](Patient-IsikPatientTemplate.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)
* [isik-patient-156722](Patient-isik-patient-156722.md)

### Procedures

* [Appendektomie](Procedure-Appendektomie.md)
* [ExampleOrganVentilationMode20200311](Procedure-ExampleOrganVentilationMode20200311.md)
* [ExampleOrganVentilationModeASV](Procedure-ExampleOrganVentilationModeASV.md)
* [ExampleOrganVentilationModeBiLev](Procedure-ExampleOrganVentilationModeBiLev.md)
* [ExampleOrganVentilationModeNIV](Procedure-ExampleOrganVentilationModeNIV.md)
* [ExampleOrganVentilationModePCMod](Procedure-ExampleOrganVentilationModePCMod.md)
* [ExampleOrganVentilationModePSIMV](Procedure-ExampleOrganVentilationModePSIMV.md)
* [ExampleOrganVentilationModeSPNMod](Procedure-ExampleOrganVentilationModeSPNMod.md)
* [ExampleOrganVentilationModeStMod](Procedure-ExampleOrganVentilationModeStMod.md)
* [ExampleOrganVentilationModenC](Procedure-ExampleOrganVentilationModenC.md)
* [ReanimationBeispiel](Procedure-ReanimationBeispiel.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
