# Einführung - AMTS ISiK Implementierungsleitfaden v6.0.0

AMTS ISiK Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* **Einführung**

## Einführung

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/ImplementationGuide/amts | *Version*:6.0.0 |
| Active as of 2026-09-15 | *Computable Name*:AMTSISiKImplementationGuide |

Realm: Deutschland

-------

### Motivation AMTS Implementation Guide

Die Arzneimittel-Therapiesicherheit ist ein wesentlicher Bestandteil einer qualitativ hochwertigen Patientenversorgung, da Medikationsfehler sowie nicht berücksichtigte Risiken wie Wechselwirkungen, Allergien oder Kontraindikationen erhebliche gesundheitliche Schäden verursachen können. Ein Implementierungsleitfaden im ISiK-Kontext schafft die notwendige Grundlage, um sicherheitsrelevante Informationen standardisiert, interoperabel und systemübergreifend verfügbar zu machen. Dadurch können potenzielle Risiken frühzeitig erkannt, klinische Entscheidungen gezielt unterstützt und die Sicherheit der Arzneimitteltherapie nachhaltig verbessert werden.

Dieser Implementierungsleitfaden beschreibt die an der Schnittstelle verfügbaren Informationen für eine sichere Arzneimitteltherapie. Das beinhaltet die Vermeidung sämtlicher unerwünschter und potenziell gefährlicher Reaktionen eines individuellen Patienten im Zuge der Einnahme einer verordneten Medikation. Ein intuitives Beispiel dafür ist eine Penicillinallergie des Patienten.

Durch diesen Implementierungsleitfaden werden die bereitgestellten Ressourcen der ISiK-Landschaft erweitert, sodass eine Vielzahl an Funktionen möglich ist, mit denen eine Medikation individuell durch die Informationssysteme beurteilt oder angepasst werden kann. Die bedeutendsten abzudeckenden Use Cases sind Wechselwirkungen, Allergien und Kontraindikationen, die vor einer Abgabe identifiziert werden sollten. So lässt sich dann z.B. erkennen, ob ein Medikament in einem bestimmten Behandlungsfall nicht als sicher einzustufen ist. Mit den verfügbaren Informationen könnte potenziell auch ein individuell besser geeignetes Medikament vorgeschlagen werden.

#### Ziele

Ziele des vorliegenden IG sind:

1. Die Identifikation und Beschreibung relevanter Anwendungsfälle.
1. Die Identifikation und nachfolgende Spezifikation neuer, notwendiger (oder zu erweiternder) Ressourcen als Informationsträger für die AMTS Bewertung.
1. Die Schaffung eines Implementierungsleitfadens zur Bereitstellung ebendieser AMTS-relevanten Informationen.

Die genauere Zielstellung kann unter Einbeziehung der Stakeholder in der Evolution von ISiK erweitert oder verändert werden.

#### Out-of-scope

Aufgrund technischer Beschränkungen oder eines vorerst unnötigen Aufwands gibt es auch Aspekte, die aktuell noch außen vor bleiben müssen:

1. Die Schaffung, Abstimmung und Spezifikation eines vollständigen[ISiK Labor Moduls](https://gemspec.gematik.de/ig/fhir/isik/labor/6.0.0-rc1/index.html).
1. Medical Knowledge Management: Eine medizinische Wissensdatenbank ohne Patientenbezug, in der zum Beispiel Informationen zu bekannten Nebenwirkungen, Wechselwirkungen oder Kontra-Indikationen gespeichert werden (z.B. FHIR-R5 Ressource**ClinicalUseDefinition**). Leider stehen entsprechende Ressourcen erst in R5 zur Verfügung und es gibt kein einheitliches Bild wo eine solche Medical Knowledge Datenbank in der deutschen Gesundheitslandschaft (und in der Telematik Infrastruktur) zu verorten wäre.
1. Die Einbeziehung eines Therapieziels (FHIR-R4 Ressource**Goal**), da dies sehr komplex ist und ein erheblicher Abstimmungsaufwand mit sich brächte.
1. Die Einbeziehung eines Therapieplans (FHIR-R4 Ressource**Careplan**), da dieser ein neues Fachfeld braucht. Dieses Feld (Onkologie) würde ein neues ISiK Modul sowie IG begründen und benötigt eine eigene Arbeitsgruppe in einer zukünftigen Stufe.

Einige dieser Aspekte sind bereits im Backlog für kommende ISiK Entwicklungsstufen aufgenommen.

### Interoperabler Datenaustausch durch Informationssysteme im Krankenhaus (ISiK)

Die gematik wurde vom Gesetzgeber beauftragt, im Benehmen mit der Deutschen Krankenhausgesellschaft (DKG) und den maßgeblichen Bundesverbänden der Industrie im Gesundheitswesen, verbindliche Standards für den Austausch von Gesundheitsdaten mit Informationssystemen im Krankenhaus zu erarbeiten. Dieser FHIR ImplementationGuide (IG) beschreibt die für diesen Zweck entwickelten FHIR Profile und das [REST](https://de.wikipedia.org/wiki/Representational_State_Transfer)-basierte Application Programming Interface (API). Die REST-API wird im Wesentlichen [vom FHIR Standard vorgegeben](https://www.hl7.org/fhir/R4/http.html). Dieser Leitfaden konkretisiert die ISiK-relevanten Funktionen der Standard-REST-API und trifft inhaltliche Festlegungen zu den ISiK-relevanten Ressourcen in Form von Ressourcen-Profilen.

Hersteller bestätigungsrelevanter Systeme sollen durch diesen IG in die Lage versetzt werden, eine konforme Implementierung zu erstellen und das Bestätigungsverfahren der gematik erfolgreich zu absolvieren.

Weitere Informationen siehe [§373 SGB V](https://www.gesetze-im-internet.de/sgb_5/__373.html).

Hinweis: Sowohl für die Implementierung der ISiK-Spezifikation als auch für den Betrieb eines Produktes, das die ISiK-Spezifikation implementiert, ist eine SNOMED-CT-Lizenz notwendig. Diese kann beim [National Release Center für SNOMED CT in Deutschland](https://www.bfarm.de/DE/Kodiersysteme/Terminologien/SNOMED-CT/_node.html) beantragt werden.

**Kontakt**

Bringen Sie allgemeine Fragen und Anmerkungen gerne über unser Anfrageportal ein: [Anfragen ISiK + ISiP](https://service.gematik.de/servicedesk/customer/portal/16)

Falls Sie keinen Zugang zum Anfrageportal haben und dieses nutzen wollen, senden Sie uns bitte eine Nachricht an die Adresse isik [ at ] gematik.de mit dem Betreff "Portalzugang".

**Herausgeber**

gematik GmbH

[Impressum](https://www.gematik.de/impressum/)

**Gender-Hinweis**

Zugunsten des Leseflusses wird in dieser Publikation meist die männliche Form verwendet. Wir bitten, dies nicht als Zeichen einer geschlechtsspezifischen Wertung zu deuten. Diese Variante deckt auch alle weiteren Geschlechter, neben männlich und weiblich, ab.

