# ISiKPersonImGesundheitsberuf - AMTS ISiK Implementierungsleitfaden v6.0.0

AMTS ISiK Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ISiKPersonImGesundheitsberuf**

## Resource Profile: ISiKPersonImGesundheitsberuf 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKPersonImGesundheitsberuf | *Version*:6.0.0 |
| Active as of 2026-07-01 | *Computable Name*:ISiKPersonImGesundheitsberuf |

 
Dieses Profil ermöglicht die Abbildung von Personen, die in Gesundheitsberufen tätig sind, in ISiK-Szenarien. **Motivation**: Das Profil ISIKPersonImGesundheitsberuf bildet Personen ab, die als medizinische Leistungserbringer oder Fachexperten tätig sind. In den ISiK-FHIR-Profilen können PersonImGesundheitsberuf bspw. als Ausführende einer Prozedur auftreten, im Element `performer` der Procedure-Ressource, oder als Person, die eine Diagnose stellt, im Element `asserter` der Condition-Ressource. 
In FHIR werden PersonImGesundheitsberuf mit der [`Practitioner`](https://hl7.org/fhir/R4/practitioner.html)-Ressource repräsentiert. Für das Profil ISIKPersonImGesundheitsberuf wird Kompatibilität mit den folgenden Profilen angestrebt. Es kann jedoch nicht sichergestellt werden, dass Instanzen, die gegen ISIKPersonImGesundheitsberuf valide sind, auch gegen diese Profile validieren: 
* [Profil KBV_PR_Base_Practitioner der KBV-Basisprofile](https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Practitioner).
* [Profil HiGHmed_IC_Practitioner, Medizininformatik-Initiative - HiGHmed Use Case Infection Control der Medizininformatik-Initiative ](https://simplifier.net/medizininformatikinitiative-highmed-ic/highmed-ic-practitioner)
 
Gegen folgende Profile ist das Profil ISiKPersonImGesundheitsberuf unmittelbar kompatibel: 
* [Profil TIPractitioner der gematik](https://gematik.de/fhir/ti/StructureDefinition/ti-practitioner)
 
Hinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden. 

**Usages:**

* Examples for this Profile: [Practitioner/PractitionerWalterArzt](Practitioner-PractitionerWalterArzt.md)
* CapabilityStatements using this Profile: [ISiK CapabilityStatement AMTS Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementAMTSAkteur-expanded.md) and [CapabilityStatement für Rolle LeistungserbringerRolle](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/amts|current/StructureDefinition/StructureDefinition-ISiKPersonImGesundheitsberuf.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-ISiKPersonImGesundheitsberuf.csv), [Excel](../StructureDefinition-ISiKPersonImGesundheitsberuf.xlsx), [Schematron](../StructureDefinition-ISiKPersonImGesundheitsberuf.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKPersonImGesundheitsberuf",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKPersonImGesundheitsberuf",
  "version" : "6.0.0",
  "name" : "ISiKPersonImGesundheitsberuf",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    }]
  }],
  "description" : "Dieses Profil ermöglicht die Abbildung von Personen, die in Gesundheitsberufen tätig sind, in ISiK-Szenarien.\n**Motivation**: Das Profil ISIKPersonImGesundheitsberuf bildet Personen ab, die als medizinische Leistungserbringer oder Fachexperten tätig sind. In den ISiK-FHIR-Profilen können PersonImGesundheitsberuf bspw. als Ausführende einer Prozedur auftreten, im Element `performer` der Procedure-Ressource, oder als Person, die eine Diagnose stellt, im Element `asserter` der Condition-Ressource.\n\nIn FHIR werden PersonImGesundheitsberuf mit der [`Practitioner`](https://hl7.org/fhir/R4/practitioner.html)-Ressource\n repräsentiert.\n Für das Profil ISIKPersonImGesundheitsberuf wird Kompatibilität mit den folgenden Profilen angestrebt. Es kann jedoch nicht sichergestellt werden, dass Instanzen, die gegen ISIKPersonImGesundheitsberuf valide sind, auch gegen diese Profile validieren:\n* [Profil KBV_PR_Base_Practitioner der KBV-Basisprofile](https://fhir.kbv.de/StructureDefinition/KBV_PR_Base_Practitioner).\n* [Profil HiGHmed_IC_Practitioner, Medizininformatik-Initiative - HiGHmed Use Case Infection Control der  Medizininformatik-Initiative ](https://simplifier.net/medizininformatikinitiative-highmed-ic/highmed-ic-practitioner)\n\nGegen folgende Profile ist das Profil ISiKPersonImGesundheitsberuf unmittelbar kompatibel:\n\n* [Profil TIPractitioner der gematik](https://gematik.de/fhir/ti/StructureDefinition/ti-practitioner)  \n\nHinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Practitioner",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Practitioner",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Practitioner",
      "path" : "Practitioner",
      "constraint" : [{
        "key" : "prac-de-1",
        "severity" : "error",
        "human" : "Die amtliche Differenzierung der Geschlechtsangabe 'other' darf nur gefüllt sein, wenn das Geschlecht 'other' angegeben ist",
        "expression" : "gender='other' or gender.extension('http://fhir.de/StructureDefinition/gender-amtlich-de').empty()",
        "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKPersonImGesundheitsberuf"
      }]
    },
    {
      "id" : "Practitioner.id",
      "path" : "Practitioner.id",
      "short" : "serverseitige, interne ID des Datensatzes",
      "comment" : "**bedingtes Pflichtfeld/bedingtes MS:** Alle von einem Server bereitgestellten Ressourcen MÜSSEN über eine `id` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `id`verfügen. ",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.meta.versionId",
      "path" : "Practitioner.meta.versionId",
      "short" : "Eindeutiger Name der serverseitigen Version des Datensatzes",
      "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über eine `versionID` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `versionID`verfügen. "
    },
    {
      "id" : "Practitioner.meta.lastUpdated",
      "path" : "Practitioner.meta.lastUpdated",
      "short" : "Zeitpunkt der letzten Änderung",
      "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über ein `lastUpdate` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über ein `lastUpdate`verfügen. "
    },
    {
      "id" : "Practitioner.implicitRules",
      "path" : "Practitioner.implicitRules",
      "short" : "Verweis auf die Regeln, nach denen die Ressource erstellt wurde",
      "comment" : "Begründung Constraint: In ISiK existiert kein Use-Case für dieses Element. Da es sich um ein Modifying Element handelt, wird es daher ausgeschlossen.\n  Darüber hinaus werden die Regeln als URI vorgehalten. Dies führt dazu, dass sich hinter der URI eine beliebige Menge an Regeln befinden kann; wodurch  nicht sichergestellt werden kann, dass alle Clients die Regeln korrekt interpretieren können.",
      "max" : "0"
    },
    {
      "id" : "Practitioner.identifier",
      "path" : "Practitioner.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "comment" : "Eindeutiger Identifier der Person",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:Arztnummer",
      "path" : "Practitioner.identifier",
      "sliceName" : "Arztnummer",
      "short" : "Lebenslange Arztnummer",
      "comment" : " Im Krankenhaus ist die lebenslange Arztnummer der Ärzte bekannt und MUSS zur eindeutigen Identifikation eines Arztes bereitgestellt werden.\n**Hinweise:** Siehe [Beschreibung der Deutschen Basisprofile](https://ig.fhir.de/basisprofile-de/1.2.0/LebenslangeArztnummerLANR-Identifier.html)\nWährend die Deutschen Basisprofile hier die Abkürzung LANR verwenden, ist im KBV-Kontext das Akronym ANR gebräuchlich. Die Bezeichnung des Slices hat jedoch keinerlei Auswirkungen auf die Kompatibilität.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-lanr"]
      }],
      "patternIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "LANR"
          }]
        }
      },
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:Arztnummer.type",
      "path" : "Practitioner.identifier.type",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:EFN",
      "path" : "Practitioner.identifier",
      "sliceName" : "EFN",
      "short" : "Einheitliche Fortbildungsnummer für Ärzte in Deutschland",
      "comment" : "In einzelnen KIS wird keine EFN geführt, da sie aus Compliance-Gründen ausschließlich in HR-Systemen vorgehalten wird. Eine fehlende EFN soll im Testsystem daher als warningOnly bewertet werden.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-efn"]
      }],
      "patternIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "DN"
          }]
        }
      },
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:EFN.type",
      "path" : "Practitioner.identifier.type",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:TelematikId",
      "path" : "Practitioner.identifier",
      "sliceName" : "TelematikId",
      "short" : "Telematik-ID",
      "comment" : "**Begründung MS:** Zur Verknüpfung der Practitioner-Instanz mit Diensten der Telematikinfrastruktur SOLL die Telematik-ID des HBA angegeben werden.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-telematik-id"]
      }],
      "patternIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "PRN"
          }]
        }
      },
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:TelematikId.type",
      "path" : "Practitioner.identifier.type",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:Mitarbeiterkennzeichen",
      "path" : "Practitioner.identifier",
      "sliceName" : "Mitarbeiterkennzeichen",
      "short" : "Mitarbeiterkennzeichen",
      "comment" : "Für interne Kennzeichnung von Personen KANN ein institutionsbezogenes Mitarbeiterkennzeichen angegeben werden.\n  \n  Begründung MS: Nicht immer gibt es eine offizielle Kennzeichnung, von Personen. Damit eine interne Kennzeichnung möglich ist, bietet dieser Slice die Möglichkeit, ein internes Mitarbeiterkennzeichen anzugeben.",
      "min" : 0,
      "max" : "1",
      "patternIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "EN"
          }]
        }
      },
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:Mitarbeiterkennzeichen.type",
      "path" : "Practitioner.identifier.type",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:Mitarbeiterkennzeichen.system",
      "path" : "Practitioner.identifier.system",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:Mitarbeiterkennzeichen.value",
      "path" : "Practitioner.identifier.value",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name",
      "path" : "Practitioner.name",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "comment" : "Namen der Person",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name:Name",
      "path" : "Practitioner.name",
      "sliceName" : "Name",
      "short" : "Vollständiger Name",
      "comment" : "Der Name der Person im Gesundheitsberuf MUSS in konkreten Anwendungen angezeigt werden können. Es MUSS möglich sein, nach diesem Namen zu suchen.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "HumanName",
        "profile" : ["http://fhir.de/StructureDefinition/humanname-de-basis"]
      }],
      "patternHumanName" : {
        "use" : "official"
      },
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name:Name.use",
      "path" : "Practitioner.name.use",
      "short" : "Verwendungszweck",
      "comment" : "Hier ist stets der Wert `official` anzugeben.\n      **Begründung Pflichtfeld:** Dient als Unterscheidungs- und Auswahlkriterium",
      "min" : 1,
      "fixedCode" : "official",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name:Name.family",
      "path" : "Practitioner.name.family",
      "short" : "Nachname",
      "comment" : "Vollständiger Nachname bzw. Familienname der Person, einschließlich Namensvorsätze und -zusätze.\n      **Begründung Pflichtfeld:** Ein offizieller Name ist nur zulässig, wenn der Nachname und mindestens ein Vorname angegeben sind.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name:Name.given",
      "path" : "Practitioner.name.given",
      "comment" : "Kann mehrfach verwendet werden, um den Rufnamen sowie weitere Vornamen, Mittelnamen oder Mittel-Initialen abzubilden.\n      **Begründung Pflichtfeld:** Ein offizieller Name ist nur zulässig, wenn der Nachname und mindestens ein Vorname angegeben sind.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name:Name.prefix",
      "path" : "Practitioner.name.prefix",
      "short" : "Präfix",
      "comment" : "Präfix, z. B. akademischer Titel oder militärischer Rang",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name:Geburtsname",
      "path" : "Practitioner.name",
      "sliceName" : "Geburtsname",
      "short" : "Geburtsname",
      "comment" : "Ist der Geburtsname der Person im Gesundheitsberuf bekannt und weicht er vom aktuellen Namen ab, KANN er zusätzlich angegeben werden.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "HumanName",
        "profile" : ["http://fhir.de/StructureDefinition/humanname-de-basis"]
      }],
      "patternHumanName" : {
        "use" : "maiden"
      }
    },
    {
      "id" : "Practitioner.name:Geburtsname.use",
      "path" : "Practitioner.name.use",
      "min" : 1,
      "fixedCode" : "maiden",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name:Geburtsname.family",
      "path" : "Practitioner.name.family",
      "min" : 1
    },
    {
      "id" : "Practitioner.name:Geburtsname.given",
      "path" : "Practitioner.name.given",
      "max" : "0"
    },
    {
      "id" : "Practitioner.name:Geburtsname.prefix",
      "path" : "Practitioner.name.prefix",
      "max" : "0"
    },
    {
      "id" : "Practitioner.telecom.system",
      "path" : "Practitioner.telecom.system",
      "min" : 1
    },
    {
      "id" : "Practitioner.telecom.value",
      "path" : "Practitioner.telecom.value",
      "min" : 1
    },
    {
      "id" : "Practitioner.address",
      "path" : "Practitioner.address",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "comment" : "Zur Unterscheidung von Postfach- und Straßenadressen, zur getrennten Angabe von Straßenname und Hausnummer sowie zur Angabe von Stadtteilen können Implementierungen die im deutschen Basisprofil zur Adresse (http://fhir.de/StructureDefinition/address-de-basis) beschriebenen Erweiterungen unterstützen.\r\nDiese Differenzierungen sind im Rahmen dieser Spezifikation jedoch nicht verpflichtend.",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift",
      "path" : "Practitioner.address",
      "sliceName" : "Strassenanschrift",
      "short" : "Straßenanschrift",
      "comment" : "Ist eine Adresse bekannt, unter der die Person im Gesundheitsberuf erreichbar ist, MUSS sie bereitgestellt werden. Diese kann zur Unterscheidung von Personen herangezogen werden. Die Ausdifferenzierung der Adresse in die Adressbestandteile erfolgt in Hinblick auf eine einheitliche Verwendung von Adressen.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Address",
        "profile" : ["http://fhir.de/StructureDefinition/address-de-basis"]
      }],
      "patternAddress" : {
        "type" : "both"
      },
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.extension:Stadtteil",
      "path" : "Practitioner.address.extension",
      "sliceName" : "Stadtteil",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.type",
      "path" : "Practitioner.address.type",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.line",
      "path" : "Practitioner.address.line",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.line.extension:Strasse",
      "path" : "Practitioner.address.line.extension",
      "sliceName" : "Strasse",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.line.extension:Hausnummer",
      "path" : "Practitioner.address.line.extension",
      "sliceName" : "Hausnummer",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.line.extension:Adresszusatz",
      "path" : "Practitioner.address.line.extension",
      "sliceName" : "Adresszusatz",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.line.extension:Postfach",
      "path" : "Practitioner.address.line.extension",
      "sliceName" : "Postfach",
      "max" : "0"
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.city",
      "path" : "Practitioner.address.city",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.postalCode",
      "path" : "Practitioner.address.postalCode",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Strassenanschrift.country",
      "path" : "Practitioner.address.country",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Postfach",
      "path" : "Practitioner.address",
      "sliceName" : "Postfach",
      "short" : "Postfachanschrift",
      "comment" : "Ist eine Adresse bekannt, unter der die Person im Gesundheitsberuf erreichbar ist, MUSS sie bereitgestellt werden. Diese kann zur Unterscheidung von Personen herangezogen werden. Die Ausdifferenzierung der Adresse in die Adressbestandteile erfolgt in Hinblick auf eine einheitliche Verwendung von Adressen.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Address",
        "profile" : ["http://fhir.de/StructureDefinition/address-de-basis"]
      }],
      "patternAddress" : {
        "type" : "postal"
      },
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Postfach.type",
      "path" : "Practitioner.address.type",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Postfach.line",
      "path" : "Practitioner.address.line",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Postfach.line.extension:Strasse",
      "path" : "Practitioner.address.line.extension",
      "sliceName" : "Strasse",
      "max" : "0"
    },
    {
      "id" : "Practitioner.address:Postfach.line.extension:Hausnummer",
      "path" : "Practitioner.address.line.extension",
      "sliceName" : "Hausnummer",
      "max" : "0"
    },
    {
      "id" : "Practitioner.address:Postfach.line.extension:Adresszusatz",
      "path" : "Practitioner.address.line.extension",
      "sliceName" : "Adresszusatz",
      "max" : "0"
    },
    {
      "id" : "Practitioner.address:Postfach.line.extension:Postfach",
      "path" : "Practitioner.address.line.extension",
      "sliceName" : "Postfach",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Postfach.city",
      "path" : "Practitioner.address.city",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Postfach.postalCode",
      "path" : "Practitioner.address.postalCode",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.address:Postfach.country",
      "path" : "Practitioner.address.country",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.gender",
      "path" : "Practitioner.gender",
      "short" : "Administratives Geschlecht",
      "comment" : "Ist das Geschlecht der Person im Gesundheitsberuf bekannt, MUSS es bereitgestellt werden. Für die Angabe 'divers' ist in Practitioner.gender der FHIR-Code `other` zu verwenden. Die administrative deutsche Differenzierung erfolgt ergänzend über die GenderOtherDE-Extension.",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.gender.extension",
      "path" : "Practitioner.gender.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Practitioner.gender.extension:Geschlecht-Administrativ",
      "path" : "Practitioner.gender.extension",
      "sliceName" : "Geschlecht-Administrativ",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://fhir.de/StructureDefinition/gender-amtlich-de"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.gender.extension:Geschlecht-Administrativ.value[x]",
      "path" : "Practitioner.gender.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.qualification.code",
      "path" : "Practitioner.qualification.code",
      "comment" : "Zur Kodierung der Qualifikation ist das entsprechende [ValueSet der KBV](https://fhir.kbv.de/ValueSet/KBV_VS_Base_Practitioner_Speciality) zu empfehlen."
    }]
  }
}

```
