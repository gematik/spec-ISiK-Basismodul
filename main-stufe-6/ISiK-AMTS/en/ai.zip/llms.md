# amts#6.0.0: AMTS ISiK Implementierungsleitfaden(en)

## Pages

* [Einführung](index.md)
* [Release Notes](ReleaseNotes.md)
* [Stakeholder, User und weitere Systeme](Akteure.md)
* [Festlegungen](Festlegungen.md)
* [Artifacts Summary](artifacts.md)
* [FHIR-Artefakte](artifacts-isik.md)
* [Use Cases](UseCases.md)

## Resources

### CodeSystems

* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [Erweiterung von Encounter.type in ISiK](CodeSystem-ISiKEncounterTypeErweiterungCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiK Medikationsart](CodeSystem-ISiKMedikationsartCS.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)

### ValueSets

* [DiagnosesSCT](ValueSet-DiagnosesSCT.md)
* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKEncounterClassDE](ValueSet-ISiKEncounterClassDE.md)
* [ISiKEncounterTypeErweiterungVS](ValueSet-ISiKEncounterTypeErweiterungVS.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiK Labor Methode](ValueSet-ISiKLaborMethodeVS.md)
* [ISiK Laborbereich](ValueSet-ISiKLaborbereichVS.md)
* [ISiKMedikationsartVS](ValueSet-ISiKMedikationsartVS.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)
* [Medikationslisten-Modes](ValueSet-MedikationsListeListModeVS.md)
* [ObservationCodesCRP](ValueSet-ObservationCodesCRP.md)
* [ObservationCodesGFR](ValueSet-ObservationCodesGFR.md)
* [ObservationCodesHb](ValueSet-ObservationCodesHb.md)
* [ObservationCodesPCT](ValueSet-ObservationCodesPCT.md)
* [ObservationCodesSerumkreatinin](ValueSet-ObservationCodesSerumkreatinin.md)
* [ObservationCodesSerumnatrium](ValueSet-ObservationCodesSerumnatrium.md)
* [ObservationCodesTSH](ValueSet-ObservationCodesTSH.md)
* [ObservationCodesThrombozyten](ValueSet-ObservationCodesThrombozyten.md)
* [ObservationCodesTroponin](ValueSet-ObservationCodesTroponin.md)
* [ObservationUnitsCRP](ValueSet-ObservationUnitsCRP.md)
* [ObservationUnitsGFR](ValueSet-ObservationUnitsGFR.md)
* [ObservationUnitsHb](ValueSet-ObservationUnitsHb.md)
* [ObservationUnitsPCT](ValueSet-ObservationUnitsPCT.md)
* [ObservationUnitsSerumkreatinin](ValueSet-ObservationUnitsSerumkreatinin.md)
* [ObservationUnitsSerumnatrium](ValueSet-ObservationUnitsSerumnatrium.md)
* [ObservationUnitsTSH](ValueSet-ObservationUnitsTSH.md)
* [ObservationUnitsThrombozyten](ValueSet-ObservationUnitsThrombozyten.md)
* [ObservationUnitsTroponin](ValueSet-ObservationUnitsTroponin.md)
* [ProzedurenCodesSCT](ValueSet-ProzedurenCodesSCT.md)
* [ProzedurenKategorieSCT](ValueSet-ProzedurenKategorieSCT.md)
* [Schwangerschaft Erwarteter Entbindungstermin Methode](ValueSet-SchwangerschaftEtMethodeVS.md)
* [Schwangerschaftsstatus Valueset](ValueSet-SchwangerschaftsstatusVS.md)
* [SctRouteOfAdministration](ValueSet-SctRouteOfAdministration.md)
* [Stillstatus LOINC Antwortoptionen](ValueSet-StillstatusVS.md)
* [Current Smoking Status - IPS](ValueSet-current-smoking-status-uv-ips.md)

### Complex-type Profiles

* [ISiKASKCoding](StructureDefinition-ISiKASKCoding.md)
* [ISiKATCCoding](StructureDefinition-ISiKATCCoding.md)
* [ISiKCoding](StructureDefinition-ISiKCoding.md)
* [ISiKICD10GMCoding](StructureDefinition-ISiKICD10GMCoding.md)
* [ISiKLoincCoding](StructureDefinition-ISiKLoincCoding.md)
* [ISiKPZNCoding](StructureDefinition-ISiKPZNCoding.md)
* [ISiKSnomedCTCoding](StructureDefinition-ISiKSnomedCTCoding.md)
* [Medication Quantity](StructureDefinition-MedicationQuantity.md)
* [Medication Quantity Dose Form](StructureDefinition-MedicationQuantityDoseForm.md)

### Resource Profiles

* [ISiK AMTS-Bewertung](StructureDefinition-ISiKAMTSBewertung.md)
* [ISiK Alkohol Abusus](StructureDefinition-ISiKAlkoholAbusus.md)
* [ISiKAllergieUnvertraeglichkeit](StructureDefinition-ISiKAllergieUnvertraeglichkeit.md)
* [ISiKDiagnose](StructureDefinition-ISiKDiagnose.md)
* [ISiKKoerpergewicht](StructureDefinition-ISiKKoerpergewicht.md)
* [ISiKKoerpergroesse](StructureDefinition-ISiKKoerpergroesse.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKLaboruntersuchung](StructureDefinition-ISiKLaboruntersuchung.md)
* [ISiKLaboruntersuchungCRP](StructureDefinition-ISiKLaboruntersuchungCRP.md)
* [ISiKLaboruntersuchungGFR](StructureDefinition-ISiKLaboruntersuchungGFR.md)
* [ISiKLaboruntersuchungHb](StructureDefinition-ISiKLaboruntersuchungHb.md)
* [ISiKLaboruntersuchungPCT](StructureDefinition-ISiKLaboruntersuchungPCT.md)
* [ISiKLaboruntersuchungSerumkreatinin](StructureDefinition-ISiKLaboruntersuchungSerumkreatinin.md)
* [ISiKLaboruntersuchungSerumnatrium](StructureDefinition-ISiKLaboruntersuchungSerumnatrium.md)
* [ISiKLaboruntersuchungTSH](StructureDefinition-ISiKLaboruntersuchungTSH.md)
* [ISiKLaboruntersuchungThrombozyten](StructureDefinition-ISiKLaboruntersuchungThrombozyten.md)
* [ISiKLaboruntersuchungTroponin](StructureDefinition-ISiKLaboruntersuchungTroponin.md)
* [ISiKLebensZustand](StructureDefinition-ISiKLebensZustand.md)
* [ISiKMedikament](StructureDefinition-ISiKMedikament.md)
* [ISiKMedikationsInformation](StructureDefinition-ISiKMedikationsInformation.md)
* [ISiK Medikationsliste](StructureDefinition-ISiKMedikationsListe.md)
* [ISiKMedikationsVerabreichung](StructureDefinition-ISiKMedikationsVerabreichung.md)
* [ISiKMedikationsVerordnung](StructureDefinition-ISiKMedikationsVerordnung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)
* [ISiKProzedur](StructureDefinition-ISiKProzedur.md)
* [ISiK Raucherstatus](StructureDefinition-ISiKRaucherStatus.md)
* [ISiKRolleImKrankenhaus](StructureDefinition-ISiKRolleImKrankenhaus.md)
* [ISiK Schwangerschaft - Erwarteter Entbindungstermin](StructureDefinition-ISiKSchwangerschaftErwarteterEntbindungstermin.md)
* [ISiK Schwangerschaftsstatus](StructureDefinition-ISiKSchwangerschaftsstatus.md)
* [ISiKStillstatus](StructureDefinition-ISiKStillstatus.md)

### Extensions

* [ISiK Accepted Risk](StructureDefinition-ExtensionISiKAcceptedRisk.md)
* [ISiK Behandlungsziel](StructureDefinition-ExtensionISiKBehandlungsziel.md)
* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ISiK Medikationsart](StructureDefinition-ExtensionISiKMedikationsart.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)
* [ISiK Selbstmedikation](StructureDefinition-ExtensionISiKSelbstmedikation.md)
* [Dosage AsNeededFor](StructureDefinition-extension-Dosage.asNeededFor.md)

### AllergyIntolerances

* [ISiKAllergieUnvertraeglichkeitBeispiel1](AllergyIntolerance-ISiKAllergieUnvertraeglichkeitBeispiel1.md)

### CapabilityStatements

* [ISiK CapabilityStatement AMTS Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementAMTSAkteur-expanded.md)
* [ISiK CapabilityStatement AMTS Akteur](CapabilityStatement-ISiKCapabilityStatementAMTSAkteur.md)
* [ISiK CapabilityStatement AMTS Rolle](CapabilityStatement-ISiKCapabilityStatementAMTSRolle.md)
* [ISiK CapabilityStatement AMTS WRITE Rolle](CapabilityStatement-ISiKCapabilityStatementAMTSWRITERolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementGesundheitsstatusRolle](CapabilityStatement-ISiKCapabilityStatementGesundheitsstatusRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementKlinischeRolle](CapabilityStatement-ISiKCapabilityStatementKlinischeRolle.md)
* [ISiK CapabilityStatement Labor Minimal Rolle](CapabilityStatement-ISiKCapabilityStatementLaborMinimalRolle.md)
* [CapabilityStatement für Rolle LeistungserbringerRolle](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)
* [ISiK CapabilityStatement MedikamentRolle](CapabilityStatement-ISiKCapabilityStatementMedikamentRolle.md)
* [ISiK CapabilityStatement Medikament WRITE Rolle](CapabilityStatement-ISiKCapabilityStatementMedikamentWRITERolle.md)
* [ISiK CapabilityStatement Medikation Server - Medikationsinformation](CapabilityStatement-ISiKCapabilityStatementMedikationInformationRolle.md)
* [ISiK CapabilityStatement Medikationsinformation WRITE Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationInformationWRITERolle.md)
* [ISiK CapabilityStatement Medikationsverabreichung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungRolle.md)
* [ISiK CapabilityStatement Medikationsverabreichung WRITE Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungWRITERolle.md)
* [ISiK CapabilityStatement Medikationsverordnung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungRolle.md)
* [ISiK CapabilityStatement Medikationsverordnung WRITE Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungWRITERolle.md)
* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)

### Conditions

* [AkuteInfektionDerOberenAtemwege](Condition-AkuteInfektionDerOberenAtemwege.md)
* [AltersbedingteKreislaufstoerung](Condition-AltersbedingteKreislaufstoerung.md)
* [BehandlungsDiagnoseFreitext](Condition-BehandlungsDiagnoseFreitext.md)
* [Example-condition-ausrufezeichen-primaer](Condition-Example-condition-ausrufezeichen-primaer.md)
* [Example-condition-ausrufezeichen-sekundaer](Condition-Example-condition-ausrufezeichen-sekundaer.md)
* [Example-condition-kreuz-stern-primaer](Condition-Example-condition-kreuz-stern-primaer.md)
* [Example-condition-kreuz-stern-sekundaer](Condition-Example-condition-kreuz-stern-sekundaer.md)
* [PrimaereGonarthroseMinimal](Condition-PrimaereGonarthroseMinimal.md)
* [PrimaereGonarthroseNormal](Condition-PrimaereGonarthroseNormal.md)
* [SZ2Primaerdiagnose](Condition-SZ2Primaerdiagnose.md)
* [SZ2Sekundaerdiagnose](Condition-SZ2Sekundaerdiagnose.md)

### Encounters

* [Fachabteilungskontakt](Encounter-Fachabteilungskontakt.md)
* [FachabteilungskontaktBettenverlegung](Encounter-FachabteilungskontaktBettenverlegung.md)
* [FachabteilungskontaktEntlassung](Encounter-FachabteilungskontaktEntlassung.md)
* [FachabteilungskontaktFachbereichswechsel1](Encounter-FachabteilungskontaktFachbereichswechsel1.md)
* [FachabteilungskontaktFachbereichswechsel2](Encounter-FachabteilungskontaktFachbereichswechsel2.md)
* [FachabteilungskontaktMinimal2](Encounter-FachabteilungskontaktMinimal2.md)
* [FachabteilungskontaktNormal](Encounter-FachabteilungskontaktNormal.md)
* [FachabteilungskontaktStationaereAufnahme](Encounter-FachabteilungskontaktStationaereAufnahme.md)
* [FachabteilungskontaktStationswechsel1](Encounter-FachabteilungskontaktStationswechsel1.md)
* [FachabteilungskontaktStationswechsel2](Encounter-FachabteilungskontaktStationswechsel2.md)
* [SZ1Nachstationaer](Encounter-SZ1Nachstationaer.md)
* [SZ1Stationaer](Encounter-SZ1Stationaer.md)
* [SZ1Vorstationaer](Encounter-SZ1Vorstationaer.md)
* [SZ2Encounter](Encounter-SZ2Encounter.md)
* [isik-encounter-Sternenfall](Encounter-isik-encounter-Sternenfall.md)

### ImplementationGuides

* [AMTS ISiK Implementierungsleitfaden](ImplementationGuide-amts.md)

### Lists

* [ExampleISiKMedikationsListe](List-ExampleISiKMedikationsListe.md)
* [ExampleISiKMedikationsListeParkinson](List-ExampleISiKMedikationsListeParkinson.md)

### MedicationAdministrations

* [ExampleISiKMedikationsVerabreichung](MedicationAdministration-ExampleISiKMedikationsVerabreichung.md)
* [ExampleISiKMedikationsVerabreichung2](MedicationAdministration-ExampleISiKMedikationsVerabreichung2.md)
* [ExampleISiKMedikationsVerabreichung3](MedicationAdministration-ExampleISiKMedikationsVerabreichung3.md)
* [ExampleISiKMedikationsVerabreichung4](MedicationAdministration-ExampleISiKMedikationsVerabreichung4.md)

### MedicationRequests

* [ExampleISiKMedikationsVerordnung](MedicationRequest-ExampleISiKMedikationsVerordnung.md)
* [ExampleISiKMedikationsVerordnung2](MedicationRequest-ExampleISiKMedikationsVerordnung2.md)
* [ExampleISiKMedikationsVerordnungBedarfsmedikation](MedicationRequest-ExampleISiKMedikationsVerordnungBedarfsmedikation.md)

### MedicationStatements

* [ExampleISiKMedikationsInformation1](MedicationStatement-ExampleISiKMedikationsInformation1.md)
* [ExampleISiKMedikationsInformation2](MedicationStatement-ExampleISiKMedikationsInformation2.md)
* [ExampleISiKMedikationsInformation3](MedicationStatement-ExampleISiKMedikationsInformation3.md)
* [ExampleISiKMedikationsInformation4](MedicationStatement-ExampleISiKMedikationsInformation4.md)
* [ExampleISiKMedikationsInformation5](MedicationStatement-ExampleISiKMedikationsInformation5.md)
* [ExampleISiKMedikationsInformation6](MedicationStatement-ExampleISiKMedikationsInformation6.md)
* [ExampleISiKMedikationsInformationParkinson1](MedicationStatement-ExampleISiKMedikationsInformationParkinson1.md)
* [ExampleISiKMedikationsInformationParkinson2](MedicationStatement-ExampleISiKMedikationsInformationParkinson2.md)
* [ExampleISiKMedikationsInformationParkinson3](MedicationStatement-ExampleISiKMedikationsInformationParkinson3.md)
* [ExampleISiKMedikationsInformationParkinson4](MedicationStatement-ExampleISiKMedikationsInformationParkinson4.md)
* [ExampleISiKMedikationsInformationParkinson5](MedicationStatement-ExampleISiKMedikationsInformationParkinson5.md)

### Medications

* [ExampleISiKMedikament1](Medication-ExampleISiKMedikament1.md)
* [ExampleISiKMedikament2](Medication-ExampleISiKMedikament2.md)
* [ExampleISiKMedikament3](Medication-ExampleISiKMedikament3.md)
* [ExampleISiKMedikament4](Medication-ExampleISiKMedikament4.md)
* [ExampleISiKMedikament5](Medication-ExampleISiKMedikament5.md)
* [ExampleISiKMedikament6](Medication-ExampleISiKMedikament6.md)
* [ExampleISiKMedikament7](Medication-ExampleISiKMedikament7.md)
* [ExampleISiKMedikament8](Medication-ExampleISiKMedikament8.md)
* [ExampleISiKMedikament9](Medication-ExampleISiKMedikament9.md)
* [ParacetamolInfusion](Medication-ParacetamolInfusion.md)

### Observations

* [ExampleISiKLaboruntersuchungCRP1](Observation-ExampleISiKLaboruntersuchungCRP1.md)
* [ExampleISiKLaboruntersuchungGFR1](Observation-ExampleISiKLaboruntersuchungGFR1.md)
* [ExampleISiKLaboruntersuchungHb1](Observation-ExampleISiKLaboruntersuchungHb1.md)
* [ExampleISiKLaboruntersuchungMaximal](Observation-ExampleISiKLaboruntersuchungMaximal.md)
* [ExampleISiKLaboruntersuchungPCT1](Observation-ExampleISiKLaboruntersuchungPCT1.md)
* [ExampleISiKLaboruntersuchungSerumkreatinin1](Observation-ExampleISiKLaboruntersuchungSerumkreatinin1.md)
* [ExampleISiKLaboruntersuchungSerumnatrium1](Observation-ExampleISiKLaboruntersuchungSerumnatrium1.md)
* [ExampleISiKLaboruntersuchungTSH1](Observation-ExampleISiKLaboruntersuchungTSH1.md)
* [ExampleISiKLaboruntersuchungThrombozyten1](Observation-ExampleISiKLaboruntersuchungThrombozyten1.md)
* [ExampleISiKLaboruntersuchungTroponin1](Observation-ExampleISiKLaboruntersuchungTroponin1.md)
* [ExampleOrganSerumNatrium202003110104](Observation-ExampleOrganSerumNatrium202003110104.md)
* [ExampleOrganSerumNatrium202003110159](Observation-ExampleOrganSerumNatrium202003110159.md)
* [ExampleOrganSerumNatrium202003110306](Observation-ExampleOrganSerumNatrium202003110306.md)
* [ExtractedObservationKoerpergewicht](Observation-ExtractedObservationKoerpergewicht.md)
* [ExtractedObservationKoerpergroesse](Observation-ExtractedObservationKoerpergroesse.md)
* [ISiKAlkoholAbususBeispiel](Observation-ISiKAlkoholAbususBeispiel.md)
* [ISiKKoerpergewichtExample](Observation-ISiKKoerpergewichtExample.md)
* [ISiKKoerpergewichtMaxExample](Observation-ISiKKoerpergewichtMaxExample.md)
* [ISiKKoerpergewichtMinExample](Observation-ISiKKoerpergewichtMinExample.md)
* [ISiKKoerpergroesseExample](Observation-ISiKKoerpergroesseExample.md)
* [ISiKKoerpergroesseMaxExample](Observation-ISiKKoerpergroesseMaxExample.md)
* [ISiKKoerpergroesseMinExample](Observation-ISiKKoerpergroesseMinExample.md)
* [ISiKRaucherStatusBeispiel](Observation-ISiKRaucherStatusBeispiel.md)
* [ISiKSchwangerschaftErwarteterEntbindungsterminBeispiel](Observation-ISiKSchwangerschaftErwarteterEntbindungsterminBeispiel.md)
* [ISiKSchwangerschaftsstatusBeispiel](Observation-ISiKSchwangerschaftsstatusBeispiel.md)
* [ISiKStillstatusBeispiel](Observation-ISiKStillstatusBeispiel.md)

### Parameters

* [exp-params](Parameters-exp-params.md)

### Patients

* [DorisQuelle](Patient-DorisQuelle.md)
* [DorisZiel](Patient-DorisZiel.md)
* [IsikPatientTemplate](Patient-IsikPatientTemplate.md)
* [PatientinMinimal](Patient-PatientinMinimal.md)
* [PatientinMusterfrau](Patient-PatientinMusterfrau.md)
* [PatientinNormal](Patient-PatientinNormal.md)
* [SZ1Patient](Patient-SZ1Patient.md)
* [SZ2Patient](Patient-SZ2Patient.md)
* [isik-patient-156722](Patient-isik-patient-156722.md)

### PractitionerRoles

* [RolleImKrankenhausAllgemeinchirurgieBeispiel](PractitionerRole-RolleImKrankenhausAllgemeinchirurgieBeispiel.md)
* [RolleImKrankenhausInnereMedizinBeispiel](PractitionerRole-RolleImKrankenhausInnereMedizinBeispiel.md)

### Practitioners

* [PractitionerWalterArzt](Practitioner-PractitionerWalterArzt.md)

### Procedures

* [Appendektomie](Procedure-Appendektomie.md)

### RiskAssessments

* [ExampleISiKAMTSBewertung1](RiskAssessment-ExampleISiKAMTSBewertung1.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
