# ISiKGCS - ISiK Vitalparameter Implementierungsleitfaden v6.0.0

ISiK Vitalparameter Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ISiKGCS**

## Resource Profile: ISiKGCS 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKGCS | *Version*:6.0.0 |
| Active as of 2026-07-01 | *Computable Name*:ISiKGCS |

 
Dieses Profil spezifiziert die Minimalanforderungen für die Bereitstellung von Informationen über den Glasgow Coma Scale (GCS) Score eines Patienten im Rahmen der interoperablen Kommunikation gemäß den Vorgaben der ISiK. 
**Motivation** 
Die Erfassung und Überwachung des Bewusstseinszustands anhand des GCS ist essenziell für die Beurteilung neurologischer Funktionen, die Überwachung von Patienten mit Schädel-Hirn-Trauma oder anderen neurologischen Erkrankungen sowie die Unterstützung klinischer Entscheidungen. 
In FHIR wird der GCS-Score mit der Observation-Ressource repräsentiert, wobei die einzelnen Komponenten der Skala - Augenöffnung, verbale Reaktion und motorische Reaktion - als Component-Elemente abgebildet werden. 
**Kompatibilität** 
Das Profil ISiKGCS ist vom Profil [ScoreDE_GCS](http://fhir.de/StructureDefinition/observation-de-score-gcs) aus den deutschen Basisprofilen abgeleitet. 

**Usages:**

* Examples for this Profile: [Observation/ISiKGCSExample](Observation-ISiKGCSExample.md), [Observation/ISiKGCSMaxExample](Observation-ISiKGCSMaxExample.md) and [Observation/ISiKGCSMinExample](Observation-ISiKGCSMinExample.md)
* CapabilityStatements using this Profile: [ISiK CapabilityStatement Vital Sign Standard Source Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementVitalSignStandardSourceAkteur-expanded.md) and [ISiK CapabilityStatement VitalSign Standard Source Rolle](CapabilityStatement-ISiKCapabilityStatementVitalSignStandardSourceRolle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/vitalparameter|current/StructureDefinition/StructureDefinition-ISiKGCS.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-ISiKGCS.csv), [Excel](../StructureDefinition-ISiKGCS.xlsx), [Schematron](../StructureDefinition-ISiKGCS.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKGCS",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKGCS",
  "version" : "6.0.0",
  "name" : "ISiKGCS",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gematik.de"
    }]
  }],
  "description" : "Dieses Profil spezifiziert die Minimalanforderungen für die Bereitstellung von Informationen über den Glasgow Coma Scale (GCS) Score eines Patienten im Rahmen der interoperablen Kommunikation gemäß den Vorgaben der ISiK.\n\n**Motivation**\n\nDie Erfassung und Überwachung des Bewusstseinszustands anhand des GCS ist essenziell für die Beurteilung neurologischer Funktionen, die Überwachung von Patienten mit Schädel-Hirn-Trauma oder anderen neurologischen Erkrankungen sowie die Unterstützung klinischer Entscheidungen.\n\nIn FHIR wird der GCS-Score mit der Observation-Ressource repräsentiert, wobei die einzelnen Komponenten der Skala - Augenöffnung, verbale Reaktion und motorische Reaktion - als Component-Elemente abgebildet werden.\n\n**Kompatibilität**\n\nDas Profil ISiKGCS ist vom Profil [ScoreDE_GCS](http://fhir.de/StructureDefinition/observation-de-score-gcs) aus den deutschen Basisprofilen abgeleitet.",
  "fhirVersion" : "4.0.1",
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://fhir.de/StructureDefinition/observation-de-score-gcs",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.id",
      "path" : "Observation.id",
      "short" : "serverseitige, interne ID des Datensatzes",
      "comment" : "**bedingtes Pflichtfeld/bedingtes MS:** Alle von einem Server bereitgestellten Ressourcen MÜSSEN über eine `id` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `id`verfügen. ",
      "mustSupport" : true
    },
    {
      "id" : "Observation.meta.versionId",
      "path" : "Observation.meta.versionId",
      "short" : "Eindeutiger Name der serverseitigen Version des Datensatzes",
      "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über eine `versionID` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `versionID`verfügen. "
    },
    {
      "id" : "Observation.meta.lastUpdated",
      "path" : "Observation.meta.lastUpdated",
      "short" : "Zeitpunkt der letzten Änderung",
      "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über ein `lastUpdate` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über ein `lastUpdate`verfügen. "
    },
    {
      "id" : "Observation.implicitRules",
      "path" : "Observation.implicitRules",
      "short" : "Verweis auf die Regeln, nach denen die Ressource erstellt wurde",
      "comment" : "Begründung Constraint: In ISiK existiert kein Use-Case für dieses Element. Da es sich um ein Modifying Element handelt, wird es daher ausgeschlossen.\n  Darüber hinaus werden die Regeln als URI vorgehalten. Dies führt dazu, dass sich hinter der URI eine beliebige Menge an Regeln befinden kann; wodurch  nicht sichergestellt werden kann, dass alle Clients die Regeln korrekt interpretieren können.",
      "max" : "0"
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "short" : "Untersuchungsstatus",
      "comment" : "**WICHTIGER Hinweis für Implementierer:**  \n* Alle server-seitigen Implementierungen MÜSSEN in der Lage sein, die systemintern möglichen Statuswerte korrekt in FHIR abzubilden, mindestens jedoch `final`.\n* Alle client-seitigen Implementierungen MÜSSEN in der Lage sein, sämtliche Status-Codes zu interpretieren und dem Anwender in angemessener Form darstellen zu können, beispielsweise durch Ausblenden/Durchstreichen von Ressourcen mit dem status `entered-in-error` und Ausgrauen von Ressourcen, die einen Plan- oder Entwurfs-Status haben.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "short" : "Untersuchungskategorie",
      "comment" : "Motivation MS: Dieses Feld erlaubt die Sortierung und Abfrage anhand der Kategorie der Untersuchung",
      "mustSupport" : true
    },
    {
      "id" : "Observation.category:survey",
      "path" : "Observation.category",
      "sliceName" : "survey",
      "short" : "Untersuchungskategorie",
      "comment" : "Motivation MS: Dieses Feld erlaubt die Sortierung und Abfrage anhand der Kategorie der Untersuchung",
      "mustSupport" : true
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "short" : "Code",
      "comment" : "Motivation MS: Die Observation wird anhand des Codes identifiziert.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.coding",
      "path" : "Observation.code.coding",
      "short" : "Coding",
      "comment" : "Motivation MS: Semantische Kodierung",
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.coding:loinc",
      "path" : "Observation.code.coding",
      "sliceName" : "loinc",
      "short" : "LOINC Kodierung",
      "comment" : "Motivation MS: Kodierung des Vitalparameters mittels LOINC.",
      "type" : [{
        "code" : "Coding",
        "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/ISiKLoincCoding"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.coding:snomed",
      "path" : "Observation.code.coding",
      "sliceName" : "snomed",
      "short" : "SNOMED CT Kodierung",
      "comment" : "Motivation MS: Kodierung des Vitalparameters mittels SNOMED CT.",
      "type" : [{
        "code" : "Coding",
        "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/ISiKSnomedCTCoding"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.coding:IEEE11073",
      "path" : "Observation.code.coding",
      "sliceName" : "IEEE11073",
      "min" : 0,
      "max" : "1",
      "patternCoding" : {
        "system" : "urn:iso:std:iso:11073:10101",
        "code" : "153728"
      }
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "short" : "Patient",
      "comment" : "**Motivation MS:** Die Verlinkung auf eine Patienten-Ressource dient der technischen Zuordnung der Dokumentation zu einem Patienten und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.\nIm ISik Kontext MUSS die referenzierte Ressource konform zu [ISiKPatient](https://gematik.de/fhir/isik/StructureDefinition/ISiKPatient) sein.\nJenseits von ISiK KÖNNEN weitere Instanzen mit anderen Profilen referenziert werden.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.encounter",
      "path" : "Observation.encounter",
      "short" : "Aufenthaltsbezug",
      "comment" : "Motivation MS: Der Behandlungskontext ist für die Interpretation der Untersuchungsergebnisse relevant",
      "mustSupport" : true
    },
    {
      "id" : "Observation.encounter.reference",
      "path" : "Observation.encounter.reference",
      "short" : "Encounter-Link",
      "comment" : "**Begründung Pflichtfeld:** Die Verlinkung auf eine Encounter-Ressource dient der technischen Zuordnung der Dokumentation zu einem Aufenthalt und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.\n**WICHTIGER Hinweis für Implementierer:** Die Zuordnung MUSS auf einen Encounter der Ebene \"Abteilungskontakt\" (siehe hierzu Basismodul > UseCases > Abbildung des Konstruktes \"Fall\") erfolgen.  \nBei der Auswahl des Encounters ist zu beachten, dass unter einer (Abrechnungs-)\"Fallnummer\" (hier: `Encounter.account`) unter Umständen mehrere Encounter gruppiert sein können (z.B. stationärer Besuch mit mehreren vor- und nachstationären Aufenthalten.)\nIm ISik Kontext MUSS die referenzierte Ressource konform zu [ISiKKontaktGesundheitseinrichtung](https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung) sein.\nJenseits von ISiK KÖNNEN weitere Instanzen mit anderen Profilen referenziert werden.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "short" : "Datum und Uhrzeit der Untersuchung",
      "comment" : "Motivation MS: Das Datum und die Uhrzeit der Untersuchung sind für die Interpretation der Untersuchungsergebnisse relevant",
      "mustSupport" : true
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "short" : "Untersuchender",
      "comment" : "Motivation MS: Dieses Feld stellt präzisierende Angaben zum Zweck der Qualitätsbewertung bereit",
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "short" : "Untersuchungsergebnis",
      "comment" : "Motivation MS: Der Wert des Vitalparameters ist das zentrale Ergebnis der Untersuchung",
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].value",
      "path" : "Observation.value[x].value",
      "short" : "Wert",
      "comment" : "Motivation MS: Eine Quantity soll einen Wert enthalten",
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].unit",
      "path" : "Observation.value[x].unit",
      "short" : "Einheit",
      "comment" : "Motivation MS: Eine Quantity soll eine Einheit enthalten",
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].system",
      "path" : "Observation.value[x].system",
      "short" : "CodeSystem aus dem die Einheit stammt",
      "comment" : "Motivation MS: Eine Quantity soll ein System, mit dem die Einheit kodiert wird, enthalten",
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].code",
      "path" : "Observation.value[x].code",
      "short" : "Code der Einheit",
      "comment" : "Motivation MS: Eine Quantity soll einen Code der die Einheit kodiert enthalten",
      "mustSupport" : true
    },
    {
      "id" : "Observation.dataAbsentReason",
      "path" : "Observation.dataAbsentReason",
      "short" : "Grund für fehlende Untersuchungsergebnisse",
      "comment" : "Motivation MS: Dieses Feld erlaubt die Angabe von Gründen für fehlende Untersuchungsergebnisse",
      "mustSupport" : true
    },
    {
      "id" : "Observation.method",
      "path" : "Observation.method",
      "short" : "Untersuchungsmethode",
      "comment" : "**Einschränkung der übergreifenden MS-Definition:**  \nVerfügt ein bestätigungsrelevantes System nicht über die Datenstruktur zur Hinterlegung der Untersuchungsmethode, so MUSS dieses System die Information NICHT abbilden\n\n\n  Motivation zum eingeschränkten MS: Dieses Feld stellt präzisierende Angaben zum Zweck der Qualitätsbewertung bereit. Allerdings rechtfertigt der Stand der Umsetzung in gängigen Systemen eine Implementierungspflicht (MS) für die Schnittstelle nicht.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.device",
      "path" : "Observation.device",
      "short" : "Gerät",
      "comment" : "**Einschränkung der übergreifenden MS-Definition:**  \n  Verfügt ein bestätigungsrelevantes System nicht über die Datenstruktur zur Hinterlegung des Geräts, mittels dessen der Parameter erhoben worden ist, so MUSS dieses System die Information NICHT abbilden.\n\n  Motivation zum eingeschränkten MS: Dieses Feld stellt präzisierende Angaben zum Zweck der Qualitätsbewertung bereit. Allerdings rechtfertigt der Stand der Umsetzung in gängigen Systemen eine Implementierungspflicht (MS) für die Schnittstelle nicht.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component",
      "path" : "Observation.component",
      "short" : "Vitalparameter-Komponente",
      "comment" : "Motivation MS: Erfassung der Komponenten eines Vitalparameters",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component.code",
      "path" : "Observation.component.code",
      "short" : "Code",
      "comment" : "Motivation MS: Die Komponente wird anhand des Codes identifiziert.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component.code.coding",
      "path" : "Observation.component.code.coding",
      "short" : "Coding",
      "comment" : "Motivation MS: Semantische Kodierung",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component.value[x]",
      "path" : "Observation.component.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "short" : "Wert der Komponente",
      "comment" : "Motivation MS: Der Wert der Komponente ist ein Ergebnis der Untersuchung",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component.value[x]:valueCodeableConcept",
      "path" : "Observation.component.value[x]",
      "sliceName" : "valueCodeableConcept",
      "short" : "Kodiertes Ergebnis",
      "comment" : "Motivation MS: Kodierung der Ergebnisse der GCS-Komponenten.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.component.value[x]:valueCodeableConcept.coding",
      "path" : "Observation.component.value[x].coding",
      "short" : "Coding",
      "comment" : "Motivation MS: Semantische Kodierung.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component.value[x]:valueCodeableConcept.coding.system",
      "path" : "Observation.component.value[x].coding.system",
      "short" : "System",
      "comment" : "Motivation MS: URL des CodeSystems des kodierten Wertes.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component.value[x]:valueCodeableConcept.coding.code",
      "path" : "Observation.component.value[x].coding.code",
      "short" : "Code",
      "comment" : "Motivation MS: Kodierter Wert aus einem CodeSystem.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Eye",
      "path" : "Observation.component",
      "sliceName" : "Eye",
      "short" : "Augenöffnungsreflex",
      "comment" : "Motivation MS: Kodierung des Augenöffnungsreflexes.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Eye.code",
      "path" : "Observation.component.code",
      "short" : "Code",
      "comment" : "Motivation MS: Die Komponente wird anhand des Codes identifiziert.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Eye.code.coding",
      "path" : "Observation.component.code.coding",
      "short" : "Coding",
      "comment" : "Motivation MS: Semantische Kodierung",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Eye.value[x]",
      "path" : "Observation.component.value[x]",
      "short" : "Kodiertes Ergebnis",
      "comment" : "Motivation MS: Kodierung der Ergebnisse der GCS-Komponenten.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Eye.value[x].coding",
      "path" : "Observation.component.value[x].coding",
      "short" : "Coding",
      "comment" : "Motivation MS: Semantische Kodierung.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Eye.value[x].coding.system",
      "path" : "Observation.component.value[x].coding.system",
      "short" : "System",
      "comment" : "Motivation MS: URL des CodeSystems des kodierten Wertes.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Eye.value[x].coding.code",
      "path" : "Observation.component.value[x].coding.code",
      "short" : "Code",
      "comment" : "Motivation MS: Kodierter Wert aus einem CodeSystem.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Motor",
      "path" : "Observation.component",
      "sliceName" : "Motor",
      "short" : "Motorische Reaktion",
      "comment" : "Motivation MS: Kodierung der motorischen Reaktion.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Motor.code",
      "path" : "Observation.component.code",
      "short" : "Code",
      "comment" : "Motivation MS: Die Komponente wird anhand des Codes identifiziert.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Motor.code.coding",
      "path" : "Observation.component.code.coding",
      "short" : "Coding",
      "comment" : "Motivation MS: Semantische Kodierung",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Motor.value[x]",
      "path" : "Observation.component.value[x]",
      "short" : "Kodiertes Ergebnis",
      "comment" : "Motivation MS: Kodierung der Ergebnisse der GCS-Komponenten.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Motor.value[x].coding",
      "path" : "Observation.component.value[x].coding",
      "short" : "Coding",
      "comment" : "Motivation MS: Semantische Kodierung.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Motor.value[x].coding.system",
      "path" : "Observation.component.value[x].coding.system",
      "short" : "System",
      "comment" : "Motivation MS: URL des CodeSystems des kodierten Wertes.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Motor.value[x].coding.code",
      "path" : "Observation.component.value[x].coding.code",
      "short" : "Code",
      "comment" : "Motivation MS: Kodierter Wert aus einem CodeSystem.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Verbal",
      "path" : "Observation.component",
      "sliceName" : "Verbal",
      "short" : "Verbale Reaktion",
      "comment" : "Motivation MS: Kodierung der verbalen Reaktion.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Verbal.code",
      "path" : "Observation.component.code",
      "short" : "Code",
      "comment" : "Motivation MS: Die Komponente wird anhand des Codes identifiziert.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Verbal.code.coding",
      "path" : "Observation.component.code.coding",
      "short" : "Coding",
      "comment" : "Motivation MS: Semantische Kodierung",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Verbal.value[x]",
      "path" : "Observation.component.value[x]",
      "short" : "Kodiertes Ergebnis",
      "comment" : "Motivation MS: Kodierung der Ergebnisse der GCS-Komponenten.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Verbal.value[x].coding",
      "path" : "Observation.component.value[x].coding",
      "short" : "Coding",
      "comment" : "Motivation MS: Semantische Kodierung.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Verbal.value[x].coding.system",
      "path" : "Observation.component.value[x].coding.system",
      "short" : "System",
      "comment" : "Motivation MS: URL des CodeSystems des kodierten Wertes.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:Verbal.value[x].coding.code",
      "path" : "Observation.component.value[x].coding.code",
      "short" : "Code",
      "comment" : "Motivation MS: Kodierter Wert aus einem CodeSystem.",
      "mustSupport" : true
    }]
  }
}

```
