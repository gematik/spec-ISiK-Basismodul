# Signaldaten - ISiK Vitalparameter Implementierungsleitfaden v6.0.0

ISiK Vitalparameter Implementierungsleitfaden

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* **Signaldaten**

## Signaldaten

Die Profilierung von Signaldaten liegt außerhalb der Zielsetzung des ISiK Vitalparameter Moduls, allerdings besteht durch Profile wie dem ISiK EKG eine undefinierte Nähe zu dieser Art Daten. An dieser Stelle wird daher ausdrücklich auf [die Empfehlung der deutschen Basisprofile zur Profilierung von Signaldaten](https://ig.fhir.de/basisprofile-de/1.2.0/Ressourcen-VerweiseaufExterneLeitfaeden.html#SignaldatenObservation) weiter verwiesen.

