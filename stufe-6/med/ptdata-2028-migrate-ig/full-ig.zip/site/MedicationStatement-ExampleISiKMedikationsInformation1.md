# Resource ExampleISiKMedikationsInformation1



## Resource Content

```json
{
  "resourceType" : "MedicationStatement",
  "id" : "ExampleISiKMedikationsInformation1",
  "meta" : {
    "profile" : [
      "https://gematik.de/fhir/isik/StructureDefinition/ISiKMedikationsInformation"
    ]
  },
  "extension" : [
    {
      "url" : "https://gematik.de/fhir/isik/StructureDefinition/ExtensionISiKAcceptedRisk",
      "valueString" : "Erhöhtes Blutungsrisiko ist in diesem Fall vertretbar."
    },
    {
      "url" : "https://gematik.de/fhir/isik/StructureDefinition/ExtensionISiKMedikationsart",
      "valueCoding" : {
        "system" : "https://gematik.de/fhir/isik/CodeSystem/ISiKMedikationsartCS",
        "code" : "akut"
      }
    },
    {
      "url" : "https://gematik.de/fhir/isik/StructureDefinition/ExtensionISiKSelbstmedikation",
      "valueBoolean" : true
    },
    {
      "url" : "https://gematik.de/fhir/isik/StructureDefinition/ExtensionISiKBehandlungsziel",
      "valueString" : "Schmerztherapie postoperativ"
    }
  ],
  "status" : "active",
  "medicationReference" : {
    "reference" : "Medication/ExampleISiKMedikament1"
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "context" : {
    "reference" : "Encounter/FachabteilungskontaktMinimal"
  },
  "effectivePeriod" : {
    "start" : "2021-07-01"
  },
  "dateAsserted" : "2021-07-01",
  "reasonReference" : [
    {
      "reference" : "Condition/BehandlungsDiagnoseFreitext"
    }
  ],
  "dosage" : [
    {
      "timing" : {
        "repeat" : {
          "when" : ["MORN", "NOON", "EVE"]
        }
      },
      "doseAndRate" : [
        {
          "doseQuantity" : {
            "value" : 1,
            "unit" : "Brausetablette",
            "system" : "http://unitsofmeasure.org",
            "code" : "1"
          }
        }
      ]
    }
  ]
}

```
