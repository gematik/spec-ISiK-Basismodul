# null - TTL Representation - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* ****

## : null - TTL Representation

[Raw ttl](MedicationStatement-ExampleISiKMedikationsInformationParkinson3.ttl) | [Download](MedicationStatement-ExampleISiKMedikationsInformationParkinson3.ttl)

