# Resource ExampleISiKMedikament6



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "ExampleISiKMedikament6",
  "meta" : {
    "profile" : [
      "https://gematik.de/fhir/isik/StructureDefinition/ISiKMedikament"
    ]
  },
  "code" : {
    "text" : "Enoxaparin-Natrium 40 mg"
  },
  "status" : "active"
}

```
