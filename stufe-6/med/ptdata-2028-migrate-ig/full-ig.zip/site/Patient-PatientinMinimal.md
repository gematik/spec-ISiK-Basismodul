# Resource PatientinMinimal



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "PatientinMinimal",
  "meta" : {
    "profile" : [
      "https://gematik.de/fhir/isik/StructureDefinition/ISiKPatient"
    ]
  },
  "identifier" : [
    {
      "type" : {
        "coding" : [
          {
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }
        ]
      },
      "system" : "https://fhir.krankenhaus.example/sid/PID",
      "value" : "TestPID1"
    }
  ],
  "name" : [
    {
      "use" : "official",
      "family" : "Müller",
      "given" : ["Anna"]
    }
  ],
  "gender" : "female",
  "birthDate" : "1957-08-12"
}

```
