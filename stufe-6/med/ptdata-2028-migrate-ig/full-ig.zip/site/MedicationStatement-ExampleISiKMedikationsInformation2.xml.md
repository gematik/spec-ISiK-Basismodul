# null - XML Representation - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* ****

## : null - XML Representation

[Raw xml](MedicationStatement-ExampleISiKMedikationsInformation2.xml) | [Download](MedicationStatement-ExampleISiKMedikationsInformation2.xml)

