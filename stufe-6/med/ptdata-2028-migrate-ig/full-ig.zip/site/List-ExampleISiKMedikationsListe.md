# Resource ExampleISiKMedikationsListe



## Resource Content

```json
{
  "resourceType" : "List",
  "id" : "ExampleISiKMedikationsListe",
  "meta" : {
    "profile" : [
      "https://gematik.de/fhir/isik/StructureDefinition/ISiKMedikationsListe"
    ]
  },
  "status" : "current",
  "mode" : "working",
  "code" : {
    "coding" : [
      {
        "system" : "http://terminology.hl7.org/CodeSystem/list-example-use-codes",
        "code" : "medications"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "encounter" : {
    "reference" : "Encounter/Fachabteilungskontakt"
  },
  "date" : "2021-07-04",
  "entry" : [
    {
      "date" : "2021-07-01",
      "item" : {
        "reference" : "MedicationStatement/ExampleISiKMedikationsInformation1"
      }
    },
    {
      "date" : "2021-07-04",
      "item" : {
        "reference" : "MedicationStatement/ExampleISiKMedikationsInformation2"
      }
    }
  ]
}

```
