#  - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* ****

## List: 

Profile: [ISiK Medikationsliste](StructureDefinition-ISiKMedikationsListe.md)

| | | | |
| :--- | :--- | :--- | :--- |
| Date: 2024-02-20 | Mode: Working List | Status: Current | Code: Medication List |
| Subject:[Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)Encounter:[Encounter: extension = ; identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Operation; serviceType = Innere Medizin; period = 2021-02-12 --> 2021-02-13](Encounter-Fachabteilungskontakt.md) | | | |

* **Items**: [MedicationStatement: status = active; medication[x] = Stalevo® 100 mg/25 mg/200 mg; effective[x] = 2024-02-20 --> (ongoing); dateAsserted = 2024-02-20](MedicationStatement-ExampleISiKMedikationsInformationParkinson1.md)
  * Date: 2024-02-20
* **Items**: [MedicationStatement: status = active; medication[x] = Quetiapin HEXAL® 50 mg; effective[x] = 2024-02-20 --> (ongoing); dateAsserted = 2024-02-20](MedicationStatement-ExampleISiKMedikationsInformationParkinson2.md)
  * Date: 2024-02-20
* **Items**: [MedicationStatement: status = active; medication[x] = Madopar® 125 mg; effective[x] = 2024-02-20 --> (ongoing); dateAsserted = 2024-02-20](MedicationStatement-ExampleISiKMedikationsInformationParkinson3.md)
  * Date: 2024-02-20
* **Items**: [MedicationStatement: status = active; medication[x] = Entacapon HEC 200 mg; effective[x] = 2024-02-20 --> (ongoing); dateAsserted = 2024-02-20](MedicationStatement-ExampleISiKMedikationsInformationParkinson4.md)
  * Date: 2024-02-20
* **Items**: [MedicationStatement: status = active; medication[x] = LevoCarb 200/50 ret - 1 A Pharma®; effective[x] = 2024-02-20 --> (ongoing); dateAsserted = 2024-02-20](MedicationStatement-ExampleISiKMedikationsInformationParkinson5.md)
  * Date: 2024-02-20

