#  - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* ****

## Medication: 

**Motivation:** Dieses Beispiel zeigt, wie Rezepturen als ISiK-Medikation in FHIR R4 abgebildet werden können. Es demonstriert die Kombination eines Wirkstoffs mit einer Trägerlösung.

**Medikament:** Paracetamol 10 mg/ml in Glukose 5 %

**Form:** Infusionslösung

**Wirkstoffe:**

* **Paracetamol:** 10 mg/ml (aktiv)
* **Glukose 5 %:** Trägerlösung (inaktiv)

**Gesamtmenge:** 100 ml (entspricht 1000 mg Paracetamol)

**Hinweis:** Rezepturen bestehen aus mehreren Bestandteilen. Dieses Beispiel zeigt, wie man sie mit `Medication.ingredient` korrekt modelliert.

