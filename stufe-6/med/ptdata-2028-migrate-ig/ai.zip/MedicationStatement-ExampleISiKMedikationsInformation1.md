#  - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* ****

## MedicationStatement: 

Profile: [ISiKMedikationsInformation](StructureDefinition-ISiKMedikationsInformation.md)

**de/fhir/isik/StructureDefinition/ExtensionISiKAcceptedRisk**: Erhöhtes Blutungsrisiko ist in diesem Fall vertretbar.

**de/fhir/isik/StructureDefinition/ExtensionISiKMedikationsart**: ISiKMedikationsartCS: akut (akut)

**de/fhir/isik/StructureDefinition/ExtensionISiKSelbstmedikation**: true

**de/fhir/isik/StructureDefinition/ExtensionISiKBehandlungsziel**: Schmerztherapie postoperativ

**status**: Active

**medication**: [Medication Acetylcystein](Medication-ExampleISiKMedikament1.md)

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**context**: [Encounter/FachabteilungskontaktMinimal](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.org/packages/de.basisprofil.r4/Encounter/FachabteilungskontaktMinimal)

**effective**: 2021-07-01 --> (ongoing)

**dateAsserted**: 2021-07-01

**reasonReference**: [Condition/BehandlungsDiagnoseFreitext](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.org/packages/de.basisprofil.r4/Condition/BehandlungsDiagnoseFreitext)

> **dosage****timing**: Morning, Noon, Evening, Once

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 1 Brausetablette (Details: UCUM code1 = '1') |


