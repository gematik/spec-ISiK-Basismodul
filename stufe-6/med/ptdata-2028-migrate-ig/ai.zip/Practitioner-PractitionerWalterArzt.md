#  - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* ****

## Practitioner: 

Information Source: [http://krankenhaus.de](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://krankenhaus.de)

Profile: [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)

**identifier**: Lifelong physician number/123456789, Doctor number/123456789123456

**active**: true

**name**: Walter Arzt(Official), Gross(Name changed for Marriage)

**address**: Schmiedegasse 16 Potsdam 14469 DE 

**gender**: Male

**birthDate**: Absent because : masked

### Qualifications

| | |
| :--- | :--- |
| - | **Code** |
| * | Physician (occupation) |

