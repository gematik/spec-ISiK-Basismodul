# Resource ExampleISiKMedikationsVerabreichung



## Resource Content

```json
{
  "resourceType" : "MedicationAdministration",
  "id" : "ExampleISiKMedikationsVerabreichung",
  "meta" : {
    "profile" : [
      "https://gematik.de/fhir/isik/StructureDefinition/ISiKMedikationsVerabreichung"
    ]
  },
  "status" : "completed",
  "medicationReference" : {
    "reference" : "Medication/ExampleISiKMedikament1"
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "context" : {
    "reference" : "Encounter/FachabteilungskontaktMinimal"
  },
  "effectiveDateTime" : "2021-07-01",
  "dosage" : {
    "dose" : {
      "value" : 1,
      "unit" : "Tablette",
      "system" : "http://unitsofmeasure.org",
      "code" : "1"
    }
  }
}

```
