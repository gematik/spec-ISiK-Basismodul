# ExampleISiKMedikationsInformationParkinson2 - JSON Representation - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikationsInformationParkinson2**

## : ExampleISiKMedikationsInformationParkinson2 - JSON Representation

[Raw json](MedicationStatement-ExampleISiKMedikationsInformationParkinson2.json) | [Download](MedicationStatement-ExampleISiKMedikationsInformationParkinson2.json)

