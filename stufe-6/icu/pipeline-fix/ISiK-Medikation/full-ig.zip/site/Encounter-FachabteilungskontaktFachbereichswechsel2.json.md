# FachabteilungskontaktFachbereichswechsel2 - JSON Representation - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **FachabteilungskontaktFachbereichswechsel2**

## : FachabteilungskontaktFachbereichswechsel2 - JSON Representation

[Raw json](Encounter-FachabteilungskontaktFachbereichswechsel2.json) | [Download](Encounter-FachabteilungskontaktFachbereichswechsel2.json)

