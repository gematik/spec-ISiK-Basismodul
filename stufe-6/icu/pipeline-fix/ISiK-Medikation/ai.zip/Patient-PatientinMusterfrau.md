# PatientinMusterfrau - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **PatientinMusterfrau**

## Patient: PatientinMusterfrau

Profile: [ISiKPatient](StructureDefinition-ISiKPatient.md)

Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))

-------

| | |
| :--- | :--- |
| Active: | true |
| Other Ids: | * Medical record number/TestPID
* Krankenversichertennummer/A123456789
 |
| Alt. Name: | Gabler (Name changed for Marriage) |
| Contact Detail | * Musterweg 2 3. Etage Musterhausen 98764 DE 
* Postfach 8 15 Musterhausen 98764 DE 
 |

