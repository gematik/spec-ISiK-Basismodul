# ExampleISiKMedikationsInformation2 - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikationsInformation2**

## MedicationStatement: ExampleISiKMedikationsInformation2

Profile: [ISiKMedikationsInformation](StructureDefinition-ISiKMedikationsInformation.md)

**ISiK MedicationStatementReplaces**: [MedicationStatement: extension = Erhöhtes Blutungsrisiko ist in diesem Fall vertretbar.,Akutmedikation (ISiK Medikationsart#akut),true,Schmerztherapie postoperativ; status = active; medication[x] = ->Medication Acetylcystein; effective[x] = 2021-07-01 --> (ongoing); dateAsserted = 2021-07-01](MedicationStatement-ExampleISiKMedikationsInformation1.md)

**status**: Active

**medication**: [Medication ](Medication-ExampleISiKMedikament2.md)

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**context**: [Encounter/FachabteilungskontaktMinimal](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.org/packages/de.basisprofil.r4/Encounter/FachabteilungskontaktMinimal)

**effective**: 2021-07-04 --> (ongoing)

**dateAsserted**: 2021-07-03

> **dosage****timing**: Count 6 times, Once per 3 weeks

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 100 mg (Details: UCUM codemg = 'mg') |


