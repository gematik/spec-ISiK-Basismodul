# ExampleISiKMedikationsListe - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikationsListe**

## List: ExampleISiKMedikationsListe

Profile: [ISiK Medikationsliste](StructureDefinition-ISiKMedikationsListe.md)

| | | | |
| :--- | :--- | :--- | :--- |
| Date: 2021-07-04 | Mode: Working List | Status: Current | Code: Medication List |
| Subject:[Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)Encounter:[Encounter: extension = ; identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Operation; serviceType = Innere Medizin; period = 2021-02-12 --> 2021-02-13](Encounter-Fachabteilungskontakt.md) | | | |

* **Items**: [MedicationStatement: extension = Erhöhtes Blutungsrisiko ist in diesem Fall vertretbar.,Akutmedikation (ISiK Medikationsart#akut),true,Schmerztherapie postoperativ; status = active; medication[x] = ->Medication Acetylcystein; effective[x] = 2021-07-01 --> (ongoing); dateAsserted = 2021-07-01](MedicationStatement-ExampleISiKMedikationsInformation1.md)
  * Date: 2021-07-01
* **Items**: [MedicationStatement: extension = ->MedicationStatement: extension = Erhöhtes Blutungsrisiko ist in diesem Fall vertretbar.,Akutmedikation (ISiK Medikationsart#akut),true,Schmerztherapie postoperativ; status = active; medication[x] = ->Medication Acetylcystein; effective[x] = 2021-07-01 --> (ongoing); dateAsserted = 2021-07-01; status = active; medication[x] = ->Medication ; effective[x] = 2021-07-04 --> (ongoing); dateAsserted = 2021-07-03](MedicationStatement-ExampleISiKMedikationsInformation2.md)
  * Date: 2021-07-04

