# ExampleISiKMedikament1 - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikament1**

## Medication: ExampleISiKMedikament1

Medikament codiert (Wirkstoff)

