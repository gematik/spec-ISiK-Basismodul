# DorisQuelle - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **DorisQuelle**

## Patient: DorisQuelle

Profile: [ISiKPatient](StructureDefinition-ISiKPatient.md)

Doris Duplikat (official) Female, DoB: 1964-08-12 ( Medical record number)

-------

| | |
| :--- | :--- |
| Active: | false |
| Other Id: | Krankenversichertennummer/A123456789 |

