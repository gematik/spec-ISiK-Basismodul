# ExampleISiKMedikationsInformation6 - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikationsInformation6**

## MedicationStatement: ExampleISiKMedikationsInformation6

Beispiel für Dosierung kurzwirksames Insulin nach gemessenen Werten

