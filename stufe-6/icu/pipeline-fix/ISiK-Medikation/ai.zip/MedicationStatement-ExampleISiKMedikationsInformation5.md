# ExampleISiKMedikationsInformation5 - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikationsInformation5**

## MedicationStatement: ExampleISiKMedikationsInformation5

Beispiel für Medikation/Einnahme am ersten Dienstag jedes dritten Monats

