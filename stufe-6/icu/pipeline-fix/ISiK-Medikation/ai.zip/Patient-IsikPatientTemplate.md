# IsikPatientTemplate - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **IsikPatientTemplate**

## Patient: IsikPatientTemplate

Profile: [ISiKPatient](StructureDefinition-ISiKPatient.md)

null(official) Unknown, DoB: ( Medical record number)

-------

| | |
| :--- | :--- |
| Active: | true |
| Other Id: | Krankenversichertennummer/?ngen-9? |
| Contact Detail | * ph: -unknown-
* null null null DE 
 |

