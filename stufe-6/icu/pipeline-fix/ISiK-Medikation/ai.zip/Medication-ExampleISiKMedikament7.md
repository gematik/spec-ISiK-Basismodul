# ExampleISiKMedikament7 - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikament7**

## Medication: ExampleISiKMedikament7

Medikament (hier: Paracetamol) in Wasser aufgelöst

