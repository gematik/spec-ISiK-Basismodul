# ExampleISiKMedikationsInformation4 - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikationsInformation4**

## MedicationStatement: ExampleISiKMedikationsInformation4

Beispiel für Medikation/Einnahme zu jeder Mahlzeit (auch Zwischenmahlzeiten)

