# FachabteilungskontaktNormal - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **FachabteilungskontaktNormal**

## Encounter: FachabteilungskontaktNormal

Profile: [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)

> **ExtensionAufnahmegrund**
* ErsteUndZweiteStelle: [CodeSystemAufnahmegrundErsteUndZweiteStelle: 01](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/CodeSystem/dkgev/AufnahmegrundErsteUndZweiteStelle#AufnahmegrundErsteUndZweiteStelle-01) (Krankenhausbehandlung, vollstationär)

**PlannedStartDate**: 2025-01-02

**PlannedEndDate**: 2025-01-04

**identifier**: Visit number/0123456789

**status**: Finished

**class**: [ActCode: IMP](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html#v3-ActCode-IMP) (inpatient encounter)

**type**: Abteilungskontakt, Operation

**serviceType**: Orthopädie

**subject**: [Anna Müller (official) Female, DoB: 1957-08-12 ( Medical record number)](Patient-PatientinNormal.md)

**period**: 2024-10-21 --> 2025-01-01

### Diagnoses

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Condition** | **Use** | **Rank** |
| * | [Condition/PrimaereGonarthroseNormal](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.org/packages/de.basisprofil.r4/Condition/PrimaereGonarthroseNormal) | Behandlungsrelevante Diagnosen | 1 |

**account**: [Account/AbrechnungsfallGonarthrose](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.org/packages/de.basisprofil.r4/Account/AbrechnungsfallGonarthrose)

### Hospitalizations

| | | |
| :--- | :--- | :--- |
| - | **AdmitSource** | **DischargeDisposition** |
| * | Einweisung durch einen Arzt |  |

> **location****location**: [Zimmer 1234](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.org/packages/de.basisprofil.r4/Location/RaumStandortBeispiel)**status**: Active**physicalType**: Room

> **location****location**: [Bettenstellplatz 1234](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.org/packages/de.basisprofil.r4/Location/BettenstellplatzStandortBeispiel)**status**: Active**physicalType**: Bed

> **location****location**: Ward 1234 (Identifier: `https://test.krankenhaus.de/fhir/sid/stationid`/1234)**status**: Active

> **location****location**: Ward 56789 (Identifier: `https://test.krankenhaus.de/fhir/sid/stationid`/56789)**status**: Completed**physicalType**: Ward

**serviceProvider**: Fachabteilung für Orthopädie und Endoprothetik (Identifier: `https://test.krankenhaus.de/fhir/sid/fachabteilungsid`/ORTHO-1234)

