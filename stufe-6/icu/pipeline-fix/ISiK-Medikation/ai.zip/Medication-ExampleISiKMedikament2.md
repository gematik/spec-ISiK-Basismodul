# ExampleISiKMedikament2 - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikament2**

## Medication: ExampleISiKMedikament2

Beispiel für eine Infusionslösung

