# SZ1Patient - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **SZ1Patient**

## Patient: SZ1Patient

Profile: [ISiKPatient](StructureDefinition-ISiKPatient.md)

Töchterchen Musterfrau (official) Female, DoB: 2010-01-01 ( Medical record number)

-------

| | |
| :--- | :--- |
| Active: | true |
| Other Id: | Krankenversichertennummer/A123456789 |

