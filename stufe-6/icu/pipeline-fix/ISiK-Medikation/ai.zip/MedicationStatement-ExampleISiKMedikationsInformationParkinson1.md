# ExampleISiKMedikationsInformationParkinson1 - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **ExampleISiKMedikationsInformationParkinson1**

## MedicationStatement: ExampleISiKMedikationsInformationParkinson1

Beispiel für Parkinson-Medikation mit Medikament1

