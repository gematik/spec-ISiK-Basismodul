# FachabteilungskontaktStationswechsel1 - ISiK Medikation Implementierungsleitfaden v6.0.0-rc

ISiK Medikation Implementierungsleitfaden

Version 6.0.0-rc - release-candidate 

* [**Table of Contents**](toc.md)
* [**Artefakte**](artifacts.md)
* **FachabteilungskontaktStationswechsel1**

## Encounter: FachabteilungskontaktStationswechsel1

Profile: [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)

**identifier**: Visit number/0123456789

**status**: Finished

**class**: [ActCode: IMP](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html#v3-ActCode-IMP) (inpatient encounter)

**type**: Abteilungskontakt

**serviceType**: Hals-, Nasen-, Ohrenheilkunde

**subject**: [Anna Müller (official) Female, DoB: 1957-08-12 ( Medical record number)](Patient-PatientinNormal.md)

**period**: 2025-01-15 08:00:00+0100 --> 2025-01-15 14:00:00+0100

> **location****location**: Station CHA1 (Identifier: `https://test.krankenhaus.de/fhir/sid/stationId`/CHA1)**status**: Active**physicalType**: Ward

> **location****location**: Zimmer Z001 (Identifier: `https://test.krankenhaus.de/fhir/sid/zimmerId`/Z001)**status**: Active**physicalType**: Room

> **location****location**: Bett B027 (Identifier: `https://test.krankenhaus.de/fhir/sid/bettId`/B027)**status**: Active**physicalType**: Bed

