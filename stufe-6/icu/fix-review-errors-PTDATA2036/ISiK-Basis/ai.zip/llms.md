# basis#6.0.0-rc: ISiK Basis Implementierungsleitfaden

## Pages

* [Einführung](index.md)
* [Allgemeine Hinweise zu Suchparametern](UebergreifendeFestlegungen_Suchparameter.md)
* [REST-API](UebergreifendeFestlegungen_Rest.md)
* [Umgang mit fehlenden Daten](UebergreifendeFestlegungen_UmgangFehlendeDaten.md)
* [Akteurs- und Rollenmodell](Erlaeuterung-Akteurs-und-Rollenmodell.md)
* [Bestätigungsrelevante Systeme](UebergreifendeFestlegungen_BestaetigungsrelevanteSysteme.md)
* [Methodik](UebergreifendeFestlegungen_Methodik.md)
* [Umgang mit FHIR-Artefakten](UebergreifendeFestlegungen_FHIR_Artefakte.md)
* [Must-Support-Flags](UebergreifendeFestlegungen_Must-Support-Flags.md)
* [Motivation](Motivation.md)
* [Szenario 2: Kreuz-Stern-Diagnose](Szenario-2-Kreuz-Stern-Diagnose.md)
* [FHIR-Artefakte](artifacts.md)
* [Herstellung von Patienten- und Besuchskontext](Patient-Besuch-Kontext.md)
* [Kompatibilität der gematik-Spezifikation](KompatibilitaetDerGematikSpezifikation_Andere.md)
* [Repräsentationsformate](UebergreifendeFestlegungen_Repraesentationsformate.md)
* [Abbildung des Konstrukts "Fall"](Abbildung-des-Konstrukts-Fall.md)
* [Szenario 1: DRG-Fall, Kind mit Wahlleistung](Szenario-1-DRG-Fall-Kind-mit-Wahlleistung.md)
* [Release Notes](ReleaseNotes.md)
* [Datenübermittlung aus Subsystemen](Datenuebermittlung-aus-Subsystemen.md)
* [Kompatibilität der gematik-Spezifikation IHE](KompatibilitaetDerGematikSpezifikation_IHE.md)

## Resources

### CodeSystems

* [TestKatalog](CodeSystem-CodeSystemExample.md)
* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)

### ValueSets

* [DiagnosesSCT](ValueSet-DiagnosesSCT.md)
* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiKLocationPhysicalType](ValueSet-ISiKLocationPhysicalType.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)
* [TestValueSet](ValueSet-ISiKValueSetExample.md)
* [ProzedurenCodesSCT](ValueSet-ProzedurenCodesSCT.md)
* [ProzedurenKategorieSCT](ValueSet-ProzedurenKategorieSCT.md)
* [Schwangerschaft Erwarteter Entbindungstermin Methode](ValueSet-SchwangerschaftEtMethodeVS.md)
* [Schwangerschaftsstatus Valueset](ValueSet-SchwangerschaftsstatusVS.md)
* [Stillstatus LOINC Antwortoptionen](ValueSet-StillstatusVS.md)
* [Current Smoking Status - IPS](ValueSet-current-smoking-status-uv-ips.md)

### Complex-type Profiles

* [ISiKCoding](StructureDefinition-ISiKCoding.md)
* [ISiKICD10GMCoding](StructureDefinition-ISiKICD10GMCoding.md)
* [ISiKLoincCoding](StructureDefinition-ISiKLoincCoding.md)
* [ISiKSnomedCTCoding](StructureDefinition-ISiKSnomedCTCoding.md)

### Resource Profiles

* [ISiKAbrechnungsfall](StructureDefinition-ISiKAbrechnungsfall.md)
* [ISiK Alkohol Abusus](StructureDefinition-ISiKAlkoholAbusus.md)
* [ISiKAllergieUnvertraeglichkeit](StructureDefinition-ISiKAllergieUnvertraeglichkeit.md)
* [ISiKAngehoeriger](StructureDefinition-ISiKAngehoeriger.md)
* [ISiKBerichtBundle](StructureDefinition-ISiKBerichtBundle.md)
* [ISiKBerichtSubSysteme](StructureDefinition-ISiKBerichtSubSysteme.md)
* [ISiKCodeSystem](StructureDefinition-ISiKCodeSystem.md)
* [ISiKDiagnose](StructureDefinition-ISiKDiagnose.md)
* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKLebensZustand](StructureDefinition-ISiKLebensZustand.md)
* [ISiKOrganisation](StructureDefinition-ISiKOrganisation.md)
* [ISiKOrganisationFachabteilung](StructureDefinition-ISiKOrganisationFachabteilung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)
* [ISiKProzedur](StructureDefinition-ISiKProzedur.md)
* [ISiK Raucherstatus](StructureDefinition-ISiKRaucherStatus.md)
* [ISiK Schwangerschaft - Erwarteter Entbindungstermin](StructureDefinition-ISiKSchwangerschaftErwarteterEntbindungstermin.md)
* [ISiK Schwangerschaftsstatus](StructureDefinition-ISiKSchwangerschaftsstatus.md)
* [ISiKStandort](StructureDefinition-ISiKStandort.md)
* [ISiKStandortBettenstellplatz](StructureDefinition-ISiKStandortBettenstellplatz.md)
* [ISiKStandortRaum](StructureDefinition-ISiKStandortRaum.md)
* [ISiKStillstatus](StructureDefinition-ISiKStillstatus.md)
* [ISiKValueSet](StructureDefinition-ISiKValueSet.md)
* [ISiKVersicherungsverhaeltnisGesetzlich](StructureDefinition-ISiKVersicherungsverhaeltnisGesetzlich.md)
* [ISiKVersicherungsverhaeltnisSelbstzahler](StructureDefinition-ISiKVersicherungsverhaeltnisSelbstzahler.md)
* [ISiKVersicherungsverhaeltnisSonstige](StructureDefinition-ISiKVersicherungsverhaeltnisSonstige.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)
* [PlannedEndDate](StructureDefinition-PlannedEndDate.md)
* [PlannedStartDate](StructureDefinition-PlannedStartDate.md)

### CapabilityStatements

* [CapabilityStatement für Rolle AufbaustrukturRolle](CapabilityStatement-ISiKCapabilityStatementAufbaustrukturRolle.md)
* [Akteur ISiKCapabilityStatementBasisServerAkteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur-expanded.md)
* [Akteur ISiKCapabilityStatementBasisServerAkteur](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementCompositionKonsumentenRolle](CapabilityStatement-ISiKCapabilityStatementCompositionKonsumentenRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementErweiterteStammdatenRolle](CapabilityStatement-ISiKCapabilityStatementErweiterteStammdatenRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementGesundheitsstatusRolle](CapabilityStatement-ISiKCapabilityStatementGesundheitsstatusRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementKlinischeRolle](CapabilityStatement-ISiKCapabilityStatementKlinischeRolle.md)
* [CapabilityStatement für Rolle LeistungserbringerRolle](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)
* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementTerminologieRolle](CapabilityStatement-ISiKCapabilityStatementTerminologieRolle.md)
* [CapabilityStatement für Rolle ISiKCapabilityStatementVersicherungsverhaeltnisRolle](CapabilityStatement-ISiKCapabilityStatementVersicherungsverhaeltnisRolle.md)

### ImplementationGuides

* [ISiK Basis Implementierungsleitfaden](index.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
