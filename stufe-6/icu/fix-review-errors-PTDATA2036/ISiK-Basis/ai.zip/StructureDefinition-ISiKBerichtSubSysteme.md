# ISiKBerichtSubSysteme - ISiK Basis Implementierungsleitfaden v6.0.0-rc

ISiK Basis Implementierungsleitfaden

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiKBerichtSubSysteme**

## Resource Profile: ISiKBerichtSubSysteme 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKBerichtSubSysteme | *Version*:6.0.0-rc |
| Active as of 2025-12-17 | *Computable Name*:ISiKBerichtSubSysteme |

 
Dieses Profil ermöglicht die krankenhaus-interne Übermittlung eines Berichtes bestehend aus beliebigen strukturierten FHIR-Ressourcen sowie einer textuellen HTML-Repräsentation (Narrative) an einen ISiK-Basis-kompatiblen Server. 

### Motivation

 
In der heterogenen Systemlandschaft im Krankenhaus sind eine Vielzahl spezialisierter Subsysteme im Einsatz. Die Ergebnisse aus diesen Subsystemen sind aktuell jedoch häufig nicht in den Primärsystemen des Krankenhauses verfügbar, denn es bestehen folgende Herausforderungen: 
Die Daten in Subsystemen sind sehr heterogen und können hochspezialisiert sein. Bei der Nutzung dieser Subsysteme besteht häufig ein Interesse, auf die menschenlesbare Repräsentation der strukturierten Daten einwirken zu können. Künftig ist mit Szenarien zu rechnen, bei denen Befunde aus Subsystemen in eine elektronische Patientenakte übertragen werden sollen. Aktuell werden Befunde, obwohl diese in den Subsystemen in hochstrukturierter Form vorliegen, nur als PDF an das Primärsystem übermittelt. Oft weil kein strukturiertes Format spezifiziert ist, das sowohl versendendes Subsystem als auch empfangendes Primärsystem implementiert haben. Der Umfang, in dem eine Datenübernahme in ein Primärsystem möglich ist, variiert stark zwischen den Systemen oder Installationen, z.B. abhängig davon, ob ein Modul für Vitalparameter installiert ist. Die ISiK-Spezifikation begegnet diesen Herausforderungen, indem sie die Übermittlung von Ergebnissen aus Subsystemen an die Primärsysteme in Form von strukturierten Dokumenten erfordert, die über eine menschenlesbare Repräsentation verfügen. Diese strukturierten Dokumente werden im ISiK-Kontext als Berichte bezeichnet. Dabei sind die strukturierten Inhalte der Berichte harmonisiert mit den verbreiteten Formaten für Primärsysteme. 
(Semi-)Strukturierte Dokumente werden in FHIR mit der `Composition`-Ressource repräsentiert, die die Dokumentenmetadaten sowie die textuelle Repräsentation des Dokumentes enthält. Die Composition referenziert auf beliebige weiter FHIR-Ressourcen, die die strukturierten Komponenten des Dokumentes darstellen. 
Für den Transport wird die Composition zusammen mit allen direkt oder indirekt referenzierten Ressourcen in eine `Bundle`-Ressource vom Typ `document` aggregiert. Das Document-Bundle trägt alle Eigenschaften eines Dokumentes: Abgeschlossenheit, Unveränderbarkeit, Signierbarkeit. 
Es obliegt dem empfangenden System, ob dieses Dokument lediglich in seiner Gesamtheit persistiert wird, oder ob darüber hinaus einzelne Bestandteile (Ressourcen) als strukturierte Daten automatisch oder auf Veranlassung eines Benutzers in die Patientenakte übernommen werden. 
In der aktuellen Ausbaustufe von ISiK ist lediglich die Übernahme und Anzeige der Dokument-Metadaten (z.B. Dokumenttyp, Dokumentdatum, Quelle) und der menschenlesbaren HTML-Repräsentation in die Primärsysteme erforderlich. 
In weiteren Ausbaustufen von ISiK soll darüber hinaus eine Übernahme der strukturierten Anteile der Dokumente möglich sein, die den ISiK-Spezifikationen entsprechen, z.B. Diagnosen und Prozeduren. 

### Kompatibilität

 
Hinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden. 

**Usages:**

* Use this Profile: [ISiKBerichtBundle](StructureDefinition-ISiKBerichtBundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/basis|current/StructureDefinition/ISiKBerichtSubSysteme)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ISiKBerichtSubSysteme.csv), [Excel](StructureDefinition-ISiKBerichtSubSysteme.xlsx), [Schematron](StructureDefinition-ISiKBerichtSubSysteme.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKBerichtSubSysteme",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKBerichtSubSysteme",
  "version" : "6.0.0-rc",
  "name" : "ISiKBerichtSubSysteme",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-17",
  "publisher" : "gematik GmbH",
  "contact" : [
    {
      "name" : "gematik GmbH",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://gematik.de"
        }
      ]
    }
  ],
  "description" : "Dieses Profil ermöglicht die krankenhaus-interne Übermittlung eines Berichtes bestehend aus beliebigen strukturierten FHIR-Ressourcen \nsowie einer textuellen HTML-Repräsentation (Narrative) an einen ISiK-Basis-kompatiblen Server.\n### Motivation\nIn der heterogenen Systemlandschaft im Krankenhaus sind eine Vielzahl spezialisierter Subsysteme im Einsatz. Die Ergebnisse aus diesen Subsystemen sind aktuell jedoch häufig nicht in den Primärsystemen des Krankenhauses verfügbar, denn es bestehen folgende Herausforderungen:\n\nDie Daten in Subsystemen sind sehr heterogen und können hochspezialisiert sein.\nBei der Nutzung dieser Subsysteme besteht häufig ein Interesse, auf die menschenlesbare Repräsentation der strukturierten Daten einwirken zu können.\nKünftig ist mit Szenarien zu rechnen, bei denen Befunde aus Subsystemen in eine elektronische Patientenakte übertragen werden sollen.\nAktuell werden Befunde, obwohl diese in den Subsystemen in hochstrukturierter Form vorliegen, nur als PDF an das Primärsystem übermittelt. Oft weil kein strukturiertes Format spezifiziert ist, das sowohl versendendes Subsystem als auch empfangendes Primärsystem implementiert haben.\nDer Umfang, in dem eine Datenübernahme in ein Primärsystem möglich ist, variiert stark zwischen den Systemen oder Installationen, z.B. abhängig davon, ob ein Modul für Vitalparameter installiert ist.\nDie ISiK-Spezifikation begegnet diesen Herausforderungen, indem sie die Übermittlung von Ergebnissen aus Subsystemen an die Primärsysteme in Form von strukturierten Dokumenten erfordert, die über eine menschenlesbare Repräsentation verfügen. Diese strukturierten Dokumente werden im ISiK-Kontext als Berichte bezeichnet. Dabei sind die strukturierten Inhalte der Berichte harmonisiert mit den verbreiteten Formaten für Primärsysteme.\n\n(Semi-)Strukturierte Dokumente werden in FHIR mit der `Composition`-Ressource repräsentiert, \ndie die Dokumentenmetadaten sowie die textuelle Repräsentation des Dokumentes enthält.\nDie Composition referenziert auf beliebige weiter FHIR-Ressourcen, die die strukturierten Komponenten des Dokumentes darstellen.\n\nFür den Transport wird die Composition zusammen mit allen direkt oder indirekt referenzierten Ressourcen in eine `Bundle`-Ressource\n vom Typ `document` aggregiert. \nDas Document-Bundle trägt alle Eigenschaften eines Dokumentes: Abgeschlossenheit, Unveränderbarkeit, Signierbarkeit.  \n\nEs obliegt dem empfangenden System, ob dieses Dokument lediglich in seiner Gesamtheit persistiert wird, oder ob darüber hinaus einzelne Bestandteile (Ressourcen) \nals strukturierte Daten automatisch oder auf Veranlassung eines Benutzers in die Patientenakte übernommen werden. \n\nIn der aktuellen Ausbaustufe von ISiK ist lediglich die Übernahme und Anzeige der Dokument-Metadaten (z.B. Dokumenttyp, Dokumentdatum, Quelle) und der menschenlesbaren HTML-Repräsentation in die Primärsysteme erforderlich.  \n\nIn weiteren Ausbaustufen von ISiK soll darüber hinaus eine Übernahme der strukturierten Anteile der Dokumente möglich sein, die den ISiK-Spezifikationen entsprechen, z.B. Diagnosen und Prozeduren.  \n\n### Kompatibilität  \nHinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden.",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "cda",
      "uri" : "http://hl7.org/v3/cda",
      "name" : "CDA (R2)"
    },
    {
      "identity" : "fhirdocumentreference",
      "uri" : "http://hl7.org/fhir/documentreference",
      "name" : "FHIR DocumentReference"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Composition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Composition.id",
        "path" : "Composition.id",
        "short" : "serverseitige, interne ID des Datensatzes",
        "comment" : "**bedingtes Pflichtfeld/bedingtes MS:** Alle von einem Server bereitgestellten Ressourcen MÜSSEN über eine `id` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `id`verfügen. ",
        "mustSupport" : true
      },
      {
        "id" : "Composition.meta.versionId",
        "path" : "Composition.meta.versionId",
        "short" : "Eindeutiger Name der serverseitigen Version des Datensatzes",
        "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über eine `versionID` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über eine `versionID`verfügen. "
      },
      {
        "id" : "Composition.meta.lastUpdated",
        "path" : "Composition.meta.lastUpdated",
        "short" : "Zeitpunkt der letzten Änderung",
        "comment" : "Alle von einem Server bereitgestellten Ressourcen SOLLEN über ein `lastUpdate` verfügen.\n  Von Clients erzeugte Ressourcen, die im Kontext einer CREATE-Interaktion übermittelt werden, MÜSSEN NICHT über ein `lastUpdate`verfügen. "
      },
      {
        "id" : "Composition.text",
        "path" : "Composition.text",
        "short" : "Narrativ",
        "comment" : "HTML-Repräsentation des Dokumenten-Headers.   \n    Bitte Hinweise unter [Document Presentation](https://hl7.org/fhir/documents.html#presentation) beachten.  \n    Der DokumentenHeader muss mindestens die folgenden Informationen enthalten:\n* `Composition.subject:Patient.name.family`\n* `Composition.subject:Patient.birthDate`\n* `Composition.subject:Patient.identifier:pid`\n* `Composition.status`\n* `Composition.type.text`\n* `Composition.date`\n* `Composition.title`\n* `Composition.author.display`",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Composition.text.status",
        "path" : "Composition.text.status",
        "fixedCode" : "extensions",
        "mustSupport" : true
      },
      {
        "id" : "Composition.text.div",
        "path" : "Composition.text.div",
        "mustSupport" : true
      },
      {
        "id" : "Composition.identifier",
        "path" : "Composition.identifier",
        "short" : "Eindeutige Dokumenten-ID",
        "comment" : "Eine vom erzeugenden Subsystem vergebene, eindeutige DokumentenID.  \n  Wenn es sich bei dem verwendeten Identifier um eine OID oder UUID handelt, so ist hier der Wert `urn:ietf:rfc:3986` anzugeben und in `Identifier.value` das jeweilige Präfix `urn:uuid:` bzw. `urn:oid:` zu verwenden.  \n  Beispiel:\n```xml  \n<identifier> \n    <system value=\"urn:ietf:rfc:3986\">  \n    <value value=\"urn:oid:2.16.840.1.113883.6.96\"> \n</identifier>\n```",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Composition.identifier.system",
        "path" : "Composition.identifier.system",
        "short" : "Namensraum des Identifiers",
        "comment" : "Hier ist stets der eindeutige Name (URL) des Namensraums anzugeben, \n    aus dem der Identifier stammt. \n    Hinweise zur Festlegung der URLs für lokale Namensräume sind in den \n    [Deutschen Basisprofilen](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-Terminologie-Namensraeume?version=current) beschrieben.  \n    **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher.",
        "mustSupport" : true
      },
      {
        "id" : "Composition.identifier.value",
        "path" : "Composition.identifier.value",
        "comment" : "Enthält den eigentlichen Wert des Identifiers.  \n    **Begründung Pflichtfeld:** Ist der Wert nicht bekannt, sollte der gesamte Slice weggelassen werden.",
        "mustSupport" : true
      },
      {
        "id" : "Composition.status",
        "path" : "Composition.status",
        "short" : "Status des Dokumentes",
        "comment" : "Im Kontext diese Moduls ist nur der Austausch finaler Berichte vorgesehen. \n  Ein Mechanismus zur Änderung oder Ersetzung bereits übermittelter Daten ist derzeit nicht spezifiziert. \n  Hier ist stets der Wert `final` anzugeben.",
        "fixedCode" : "final",
        "mustSupport" : true
      },
      {
        "id" : "Composition.type",
        "path" : "Composition.type",
        "short" : "Dokumenttyp",
        "comment" : "Begründung zu Must Support: Der Dokumenttyp ist für die Identifikation des Berichtes und die Zuordnung zu einem Subsystem für die weitere Verarbeitung erforderlich.\n\n  *Hinweis für Implementierer:* \n  Der zu übermittelnde Bericht repräsentiert eine Zusammenfassung der strukturierten Daten aus dem Subsystem. Das Dokument KANN z.B. mittels KDL oder IHE-D-XDS-Typecodes klassifiziert werden.  \n  Es KANN derzeit jedoch auch eine rein textuelle Beschreibung des Dokumenttyps angegeben werden.\n  \n  Während KDL-Codes eine feingranulare Dokumentenklassifikation für die gezielte Suche nach medizinischen und Administrativen Dokumenten ermöglichen,\n  sind IHE-XDS-Type-Codes für den einrichtungsübergreifenden Dokumentenaustausch maßgeblich.\n  Der XDS-Type-Code kann mit Hilfe der bereitgestellten [ConceptMaps](https://simplifier.net/kdl/~resources?category=ConceptMap)\n  aus dem KDL-Code ermittelt werden.\n  Weitere Typisierungen (z.B. nach SNOMED oder LOINC) sind uneingeschränkt erlaubt. [Konsens der Arbeitsgruppe vom 18.02.2022]. Im Falle, dass der Code 'UNK' entsprechend der ConceptMap verwendet werden soll, MUSS das System 'http://terminology.hl7.org/CodeSystem/v3-NullFlavor' verwendet werden.  \n  ",
        "mustSupport" : true
      },
      {
        "id" : "Composition.type.coding",
        "path" : "Composition.type.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "mustSupport" : true
      },
      {
        "id" : "Composition.type.coding.system",
        "path" : "Composition.type.coding.system",
        "min" : 1
      },
      {
        "id" : "Composition.type.coding.code",
        "path" : "Composition.type.coding.code",
        "min" : 1
      },
      {
        "id" : "Composition.type.coding:KDL",
        "path" : "Composition.type.coding",
        "sliceName" : "KDL",
        "min" : 0,
        "max" : "1",
        "patternCoding" : {
          "system" : "http://dvmd.de/fhir/CodeSystem/kdl"
        },
        "mustSupport" : true
      },
      {
        "id" : "Composition.type.coding:KDL.code",
        "path" : "Composition.type.coding.code",
        "constraint" : [
          {
            "key" : "kdl-1",
            "severity" : "warning",
            "human" : "KDL-Code ungültig",
            "expression" : "matches('^[A-Z]{2}[0-9]{6}$')",
            "source" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKBerichtSubSysteme"
          }
        ]
      },
      {
        "id" : "Composition.type.coding:XDS",
        "path" : "Composition.type.coding",
        "sliceName" : "XDS",
        "min" : 0,
        "max" : "1",
        "patternCoding" : {
          "system" : "http://ihe-d.de/CodeSystems/IHEXDStypeCode"
        },
        "mustSupport" : true
      },
      {
        "id" : "Composition.type.text",
        "path" : "Composition.type.text",
        "short" : "Dokumenttyp (Freitext)",
        "comment" : "Freitextliche Beschreibung oder assoziierter Displaywert der primären Codierung des Dokumenttyps.",
        "mustSupport" : true
      },
      {
        "id" : "Composition.category",
        "path" : "Composition.category",
        "short" : "Dokument-Kategorie",
        "comment" : "Begründung zu Must Support: Die Klassifizierung kann zur Strukturierung der Berichte genutzt werden, in dem Fall, dass das Narrative des Berichts dem Benutzer angezeigt wird. Das Dokument KANN z.B. mittels LOINC oder IHE-D-XDS-Classcodes klassifiziert werden.",
        "mustSupport" : true
      },
      {
        "id" : "Composition.category.coding",
        "path" : "Composition.category.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "mustSupport" : true
      },
      {
        "id" : "Composition.category.coding:LOINC",
        "path" : "Composition.category.coding",
        "sliceName" : "LOINC",
        "min" : 0,
        "max" : "1",
        "patternCoding" : {
          "system" : "http://loinc.org"
        },
        "mustSupport" : true
      },
      {
        "id" : "Composition.category.coding:LOINC.system",
        "path" : "Composition.category.coding.system",
        "min" : 1
      },
      {
        "id" : "Composition.category.coding:LOINC.code",
        "path" : "Composition.category.coding.code",
        "min" : 1
      },
      {
        "id" : "Composition.category.coding:IHE",
        "path" : "Composition.category.coding",
        "sliceName" : "IHE",
        "min" : 0,
        "max" : "1",
        "patternCoding" : {
          "system" : "http://ihe-d.de/CodeSystems/IHEXDSclassCode"
        },
        "mustSupport" : true
      },
      {
        "id" : "Composition.category.coding:IHE.system",
        "path" : "Composition.category.coding.system",
        "min" : 1
      },
      {
        "id" : "Composition.category.coding:IHE.code",
        "path" : "Composition.category.coding.code",
        "min" : 1
      },
      {
        "id" : "Composition.subject",
        "path" : "Composition.subject",
        "short" : "Patientenbezug",
        "comment" : "**Begründung Must-Support:** Ein Patientenbezug des Dokument MUSS stets zum Zwecke der Nachvollziehbarkeit und Datenintegrität vorliegen.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Composition.subject.reference",
        "path" : "Composition.subject.reference",
        "short" : "Patienten-Link",
        "comment" : "**Begründung Pflichtfeld:** Die Verlinkung auf eine Patienten-Ressource dient der technischen Zuordnung der Dokumentation zu einem Patienten und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.\nIm ISik Kontext MUSS die referenzierte Ressource konform zu [ISiKPatient](https://gematik.de/fhir/isik/StructureDefinition/ISiKPatient) sein.\nJenseits von ISiK KÖNNEN weitere Instanzen mit anderen Profilen referenziert werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Composition.encounter",
        "path" : "Composition.encounter",
        "short" : "Aufenthaltsbezug",
        "comment" : "**Begründung Must-Support:** Ein Aufenthaltsbezug des Dokument MUSS stets zum Zwecke der Nachvollziehbarkeit und Datenintegrität vorliegen.",
        "mustSupport" : true
      },
      {
        "id" : "Composition.encounter.reference",
        "path" : "Composition.encounter.reference",
        "short" : "Encounter-Link",
        "comment" : "**Begründung Pflichtfeld:** Die Verlinkung auf eine Encounter-Ressource dient der technischen Zuordnung der Dokumentation zu einem Aufenthalt und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.\n**WICHTIGER Hinweis für Implementierer:** Die Zuordnung MUSS auf einen Encounter der Ebene \"Abteilungskontakt\" (siehe hierzu Basismodul > UseCases > Abbildung des Konstruktes \"Fall\") erfolgen.  \nBei der Auswahl des Encounters ist zu beachten, dass unter einer (Abrechnungs-)\"Fallnummer\" (hier: `Encounter.account`) unter Umständen mehrere Encounter gruppiert sein können (z.B. stationärer Besuch mit mehreren vor- und nachstationären Aufenthalten.)\nIm ISik Kontext MUSS die referenzierte Ressource konform zu [ISiKKontaktGesundheitseinrichtung](https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung) sein.\nJenseits von ISiK KÖNNEN weitere Instanzen mit anderen Profilen referenziert werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Composition.date",
        "path" : "Composition.date",
        "short" : "Dokumentendatum",
        "comment" : "Datum der letzten Änderung des Dokumentes",
        "mustSupport" : true
      },
      {
        "id" : "Composition.author",
        "path" : "Composition.author",
        "short" : "Verfasser/Ersteller des Dokumentes (Person oder Subsystem/Gerät)",
        "comment" : "In der aktuellen Ausbaustufe von ISiK ist die Verwendung der textuellen Repräsentation (display) \n  von Autor und Subsystem ausreichend. \n  Die darüber hinausgehende Verlinkung auf Practitioner bzw. Device-Ressourcen \n  KANN implementiert werden.",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://hl7.org/fhir/StructureDefinition/PractitionerRole",
              "http://hl7.org/fhir/StructureDefinition/Device",
              "http://hl7.org/fhir/StructureDefinition/Organization",
              "http://hl7.org/fhir/StructureDefinition/RelatedPerson",
              "http://hl7.org/fhir/StructureDefinition/Patient",
              "http://hl7.org/fhir/StructureDefinition/Practitioner"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Composition.author.display",
        "path" : "Composition.author.display",
        "short" : "Bezeichnung des Verfassers (Freitext)",
        "comment" : "Freitextliche Bezeichnung des Verfassers (Person oder Subsystem/Gerät)",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Composition.title",
        "path" : "Composition.title",
        "short" : "Dokumentenbezeichnung",
        "comment" : "Die Dokumentenbezeichnung dient der Darstellung des Dokumentes in einer Übersicht, \n  z.B. in einer Patientenakte, und KANN der schnellen Auffindbarkeit \n  eines gesuchten Dokumentes dienen. \n  Geeignete Bezeichnungen sind zum Beispiel:  \n* 'Kleines Blutbild vom 13.10.2020'\n* 'Pathologiebefund (Abstrich) vom 13.10.2020'\n* 'Blutgasmessung vom 13.10.2020 14:14h'",
        "mustSupport" : true
      },
      {
        "id" : "Composition.section",
        "path" : "Composition.section",
        "short" : "Kapitel",
        "comment" : "Das Dokument kann in mehrere Kapitel und Unterkapitel gegliedert werden.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Composition.section.title",
        "path" : "Composition.section.title",
        "short" : "Kapitelbezeichnung",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Composition.section.text",
        "path" : "Composition.section.text",
        "short" : "Narrativ",
        "comment" : "menschenlesbare HTML-Repräsentation des Inhalts dieses Kapitels.  \n    Hinweise: Für Aggregation einer vollständigen menschenlesbaren Repräsentation \n    MÜSSEN die Repräsentationen der einzelnen Kapitel an die Repräsentation \n    der Metadaten (Composition.text) angehängt werden. \n    Für die Separierung KÖNNEN einfache <div>-Tags verwendet werden. \n    Es ist zu beachten, dass Kapitel auch Unterkapitel enthalten KÖNNEN \n    (Composition.section.section), die bei der Aggregation entsprechend \n    berücksichtigt werden MÜSSEN.  \nDie Mindestanforderungen an den Inhalt der menschenlesbaren Repräsentation umfasst folgende Informationen:\n* `section.title` + Freitext oder\n* `section.title` + `Resource.text` der referenzierten Ressource oder\n* `section.title` + eine aggregierte Repräsentation von `Resource.text`,\n    wenn in einer Section mehrere Ressourcen referenziert werden \n    (z.B. eine tabellarische Auflistung mehrere Blutdruckmesswerte, Diagnosen oder Allergien).",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Composition.section.section",
        "path" : "Composition.section.section",
        "short" : "Unterkapitel",
        "mustSupport" : true
      }
    ]
  }
}

```
