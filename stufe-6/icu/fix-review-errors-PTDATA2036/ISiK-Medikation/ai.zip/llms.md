# medikation#6.0.0-rc: ISiK Medikation Implementierungsleitfaden

## Pages

* [Einführung](index.md)
* [Informationsmodell](Informationsmodell.md)
* [Kompatibilität](Kompatibilitaet.md)
* [Akteure und Interaktionen](AkteureUndInteraktionen.md)
* [REST-API](RestApi.md)
* [Artefakte](artifacts.md)
* [Übersicht Anwendungsfälle](UebersichtAnwendungsfaelle.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Release Notes](ReleaseNotes.md)

## Resources

### CodeSystems

* [ISiKBehandlungsergebnisReha](CodeSystem-ISiKBehandlungsergebnisRehaCS.md)
* [ISiKBesondereBehandlungsformReha](CodeSystem-ISiKBesondereBehandlungsformRehaCS.md)
* [ISiKEntlassformReha](CodeSystem-ISiKEntlassformRehaCS.md)
* [ISiK Medikationsart](CodeSystem-ISiKMedikationsartCS.md)
* [ISiKUnterbrechungReha](CodeSystem-ISiKUnterbrechungRehaCS.md)

### ValueSets

* [ISiKBehandlungsergebnisRehaVS](ValueSet-ISiKBehandlungsergebnisReha.md)
* [ISiKBesondereBehandlungsformRehaVS](ValueSet-ISiKBesondereBehandlungsformReha.md)
* [ISiKEntlassformRehaVS](ValueSet-ISiKEntlassformReha.md)
* [ISiKLocationPhysicalType](ValueSet-ISiKLocationPhysicalType.md)
* [ISiKMedikationsartVS](ValueSet-ISiKMedikationsartVS.md)
* [ISiKUnterbrechungRehaVS](ValueSet-ISiKUnterbrechungReha.md)
* [Medikationslisten-Modes](ValueSet-MedikationsListeListModeVS.md)
* [SctRouteOfAdministration](ValueSet-SctRouteOfAdministration.md)

### Complex-type Profiles

* [ISiKASKCoding](StructureDefinition-ISiKASKCoding.md)
* [ISiKATCCoding](StructureDefinition-ISiKATCCoding.md)
* [ISiKCoding](StructureDefinition-ISiKCoding.md)
* [ISiKPZNCoding](StructureDefinition-ISiKPZNCoding.md)
* [ISiKSnomedCTCoding](StructureDefinition-ISiKSnomedCTCoding.md)
* [Medication Quantity](StructureDefinition-MedicationQuantity.md)

### Resource Profiles

* [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)
* [ISiKMedikament](StructureDefinition-ISiKMedikament.md)
* [ISiKMedikationsInformation](StructureDefinition-ISiKMedikationsInformation.md)
* [ISiK Medikationsliste](StructureDefinition-ISiKMedikationsListe.md)
* [ISiKMedikationsVerabreichung](StructureDefinition-ISiKMedikationsVerabreichung.md)
* [ISiKMedikationsVerordnung](StructureDefinition-ISiKMedikationsVerordnung.md)
* [ISiKPatient](StructureDefinition-ISiKPatient.md)
* [ISiKPersonImGesundheitsberuf](StructureDefinition-ISiKPersonImGesundheitsberuf.md)

### Extensions

* [ISiK Accepted Risk](StructureDefinition-ExtensionISiKAcceptedRisk.md)
* [ISiK Behandlungsziel](StructureDefinition-ExtensionISiKBehandlungsziel.md)
* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ISiK MedicationRequestReplaces](StructureDefinition-ExtensionISiKMedicationRequestReplaces.md)
* [ISiK MedicationStatementReplaces](StructureDefinition-ExtensionISiKMedicationStatementReplaces.md)
* [ISiK Medikationsart](StructureDefinition-ExtensionISiKMedikationsart.md)
* [ExtensionISiKRehaEntlassung](StructureDefinition-ExtensionISiKRehaEntlassung.md)
* [ISiK Selbstmedikation](StructureDefinition-ExtensionISiKSelbstmedikation.md)
* [PlannedEndDate](StructureDefinition-PlannedEndDate.md)
* [PlannedStartDate](StructureDefinition-PlannedStartDate.md)

### CapabilityStatements

* [CapabilityStatement für Rolle LeistungserbringerRolle](CapabilityStatement-ISiKCapabilityStatementLeistungserbringerRolle.md)
* [ISiK CapabilityStatement MedikamentRolle](CapabilityStatement-ISiKCapabilityStatementMedikamentRolle.md)
* [ISiK CapabilityStatement Medikationsinformation Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementMedikationInformationAkteur-expanded.md)
* [ISiK CapabilityStatement Medikationsinformation Server Akteur](CapabilityStatement-ISiKCapabilityStatementMedikationInformationAkteur.md)
* [ISiK CapabilityStatement Medikation Server - Medikationsinformation](CapabilityStatement-ISiKCapabilityStatementMedikationInformationRolle.md)
* [ISiK CapabilityStatement Medikationsverabreichung Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungAkteur-expanded.md)
* [ISiK CapabilityStatement Medikationsverabreichung Server Akteur](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungAkteur.md)
* [ISiK CapabilityStatement Medikationsverabreichung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerabreichungRolle.md)
* [ISiK CapabilityStatement Medikationsverordnung Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungAkteur-expanded.md)
* [ISiK CapabilityStatement Medikationsverordnung Server Akteur](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungAkteur.md)
* [ISiK CapabilityStatement Medikationsverordnung Rolle](CapabilityStatement-ISiKCapabilityStatementMedikationVerordnungRolle.md)
* [CapabilityStatement für Rolle StammdatenRolle](CapabilityStatement-ISiKCapabilityStatementStammdatenRolle.md)

### ImplementationGuides

* [ISiK Medikation Implementierungsleitfaden](index.md)

### SearchParameters

* [DateStart](SearchParameter-Encounter-date-start.md)
* [EndDate](SearchParameter-Encounter-end-date.md)
