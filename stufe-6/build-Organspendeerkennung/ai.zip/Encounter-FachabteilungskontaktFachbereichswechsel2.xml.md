# null - XML Representation - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## : null - XML Representation

[Raw xml](Encounter-FachabteilungskontaktFachbereichswechsel2.xml) | [Download](Encounter-FachabteilungskontaktFachbereichswechsel2.xml)

