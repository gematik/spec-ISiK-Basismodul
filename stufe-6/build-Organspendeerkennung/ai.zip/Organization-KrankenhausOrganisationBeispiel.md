# Uniklinik Entenhausen - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Uniklinik Entenhausen**

## Organization: Uniklinik Entenhausen

Profile: [ISiKOrganisation](StructureDefinition-ISiKOrganisation.md)

**identifier**: ArgeIkIknr/260120196, `https://fhir.kbv.de/NamingSystem/KBV_NS_Base_BSNR`/345678975, `https://gematik.de/fhir/sid/telematik-id`/1234567890

**name**: Uniklinik Entenhausen

