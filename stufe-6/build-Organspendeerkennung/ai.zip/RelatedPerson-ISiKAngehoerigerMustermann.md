#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## RelatedPerson: 

Profile: [ISiKAngehoeriger](StructureDefinition-ISiKAngehoeriger.md)

**patient**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**relationship**: daughter

**name**: Maxine Mustermann (Official)

**address**: Milchstr. 42 Beispielstadt 78143 DE 

