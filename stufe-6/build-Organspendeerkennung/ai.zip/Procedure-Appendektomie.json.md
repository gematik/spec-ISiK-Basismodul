# null - JSON Representation - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## : null - JSON Representation

[Raw json](Procedure-Appendektomie.json) | [Download](Procedure-Appendektomie.json)

