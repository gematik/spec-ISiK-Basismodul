# Allgemeinchirurgie - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **Allgemeinchirurgie**

## Organization: Allgemeinchirurgie

Profile: [ISiKOrganisationFachabteilung](StructureDefinition-ISiKOrganisationFachabteilung.md)

**identifier**: Ward/123456, `https://gematik.de/fhir/sid/telematik-id`/1234567890

**type**: Hospital Department, Allgemeine Chirurgie

**name**: Allgemeinchirurgie

**partOf**: [Organization Uniklinik Entenhausen](Organization-KrankenhausOrganisationBeispiel.md)

