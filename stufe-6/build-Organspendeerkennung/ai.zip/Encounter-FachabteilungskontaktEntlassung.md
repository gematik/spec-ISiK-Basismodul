#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## Encounter: 

Profile: [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)

**identifier**: Visit number/0123456789

**status**: Finished

**class**: [ActCode: IMP](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html#v3-ActCode-IMP) (inpatient encounter)

**type**: Abteilungskontakt

**serviceType**: Innere Medizin

**subject**: [Anna Müller (official) Female, DoB: 1957-08-12 ( Medical record number)](Patient-PatientinNormal.md)

**period**: 2025-01-20 10:00:00+0100 --> (ongoing)

> **location****location**: Station INNG1 (Identifier: `https://test.krankenhaus.de/fhir/sid/stationId`/INNG1)**status**: Active**physicalType**: Ward

> **location****location**: Zimmer Z001 (Identifier: `https://test.krankenhaus.de/fhir/sid/zimmerId`/Z001)**status**: Active**physicalType**: Room

> **location****location**: Bett A010 (Identifier: `https://test.krankenhaus.de/fhir/sid/bettId`/A010)**status**: Active**physicalType**: Bed

