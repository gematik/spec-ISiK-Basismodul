#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## AllergyIntolerance: 

Profile: [ISiKAllergieUnvertraeglichkeit](StructureDefinition-ISiKAllergieUnvertraeglichkeit.md)

**clinicalStatus**: Active

**verificationStatus**: Confirmed

**type**: Allergy

**category**: Environment

**criticality**: Low Risk

**code**: Betula pendula pollen

**patient**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**onset**: 1987

**recordedDate**: 2011-05-12

**recorder**: Dr. Martin Mustermann

**asserter**: Dr. Berta Beispiel

**note**: By Practitioner/PractitionerWalterArzt @2024-02-20 14:34:12+0100

> 

Patientin berichtet von einer leichten Verschlimmerung in den letzten 3 Jahren.


### Reactions

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Manifestation** | **Severity** | **ExposureRoute** |
| * | Sneezing (finding) | Moderate | Inspiration |

