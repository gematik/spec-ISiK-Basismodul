#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## Encounter: 

Profile: [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)

> **ExtensionAufnahmegrund**
* ErsteUndZweiteStelle: [CodeSystemAufnahmegrundErsteUndZweiteStelle: 01](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/CodeSystem/dkgev/AufnahmegrundErsteUndZweiteStelle#AufnahmegrundErsteUndZweiteStelle-01) (Krankenhausbehandlung, vollstationär)
* DritteStelle: [AufnahmegrundDritteStelle: 0](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/CodeSystem/dkgev/AufnahmegrundDritteStelle#AufnahmegrundDritteStelle-0) (Anderes)
* VierteStelle: [AufnahmegrundVierteStelle: 1](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/CodeSystem/dkgev/AufnahmegrundVierteStelle#AufnahmegrundVierteStelle-1) (Normalfall)

**identifier**: Visit number/0123456789

**status**: Finished

**class**: [ActCode: IMP](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html#v3-ActCode-IMP) (inpatient encounter)

**type**: Abteilungskontakt, Operation

**serviceType**: Innere Medizin

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**period**: 2021-02-12 --> 2021-02-13

### Diagnoses

| | | |
| :--- | :--- | :--- |
| - | **Condition** | **Use** |
| * | [Condition ](Condition-BehandlungsDiagnoseFreitext.md) | Behandlungsrelevante Diagnosen |

**account**: [Account: extension = ; identifier = Account number; status = active; type = inpatient encounter](Account-AbrechnungsfallDRG.md)

### Hospitalizations

| | | |
| :--- | :--- | :--- |
| - | **AdmitSource** | **DischargeDisposition** |
| * | Einweisung durch einen Arzt |  |

### Locations

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Location** | **Status** | **PhysicalType** |
| * | Bettenstellplatz 123 (Identifier:`https://test.krankenhaus.de/fhir/sid/locationid`/123) | Active | Bed |

**serviceProvider**: Fachabteilung XYZ (Identifier: `https://test.krankenhaus.de/fhir/sid/fachabteilungsid`/XYZ)

