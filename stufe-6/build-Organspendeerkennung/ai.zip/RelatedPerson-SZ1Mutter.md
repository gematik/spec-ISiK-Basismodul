#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## RelatedPerson: 

Profile: [ISiKAngehoeriger](StructureDefinition-ISiKAngehoeriger.md)

**identifier**: Krankenversichertennummer/A987654321

**patient**: [Töchterchen Musterfrau (official) Female, DoB: 2010-01-01 ( Medical record number)](Patient-SZ1Patient.md)

**relationship**: mother

**name**: Mama Musterfrau (Official)

**address**: Milchstr. 42 Beispielstadt 78143 DE 

