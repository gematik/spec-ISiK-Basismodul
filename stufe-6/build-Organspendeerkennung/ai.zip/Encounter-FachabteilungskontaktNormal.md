#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## Encounter: 

Profile: [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)

> **ExtensionAufnahmegrund**
* ErsteUndZweiteStelle: [CodeSystemAufnahmegrundErsteUndZweiteStelle: 01](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/CodeSystem/dkgev/AufnahmegrundErsteUndZweiteStelle#AufnahmegrundErsteUndZweiteStelle-01) (Krankenhausbehandlung, vollstationär)

**Extension Definition for Encounter.plannedStartDate for Version 5.0**: 2025-01-02

**Extension Definition for Encounter.plannedEndDate for Version 5.0**: 2025-01-04

**identifier**: Visit number/0123456789

**status**: Finished

**class**: [ActCode: IMP](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html#v3-ActCode-IMP) (inpatient encounter)

**type**: Abteilungskontakt, Operation

**serviceType**: Orthopädie

**subject**: [Anna Müller (official) Female, DoB: 1957-08-12 ( Medical record number)](Patient-PatientinNormal.md)

**period**: 2024-10-21 --> 2025-01-01

### Diagnoses

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Condition** | **Use** | **Rank** |
| * | [Condition Primäre Gonarthrose, beidseitig](Condition-PrimaereGonarthroseNormal.md) | Behandlungsrelevante Diagnosen | 1 |

**account**: [Account: identifier = Account number; status = active; type = inpatient encounter](Account-AbrechnungsfallGonarthrose.md)

### Hospitalizations

| | | |
| :--- | :--- | :--- |
| - | **AdmitSource** | **DischargeDisposition** |
| * | Einweisung durch einen Arzt |  |

> **location****location**: [Zimmer 1234](Location-RaumStandortBeispiel.md)**status**: Active**physicalType**: Room

> **location****location**: [Bettenstellplatz 1234](Location-BettenstellplatzStandortBeispiel.md)**status**: Active**physicalType**: Bed

> **location****location**: Ward 1234 (Identifier: `https://test.krankenhaus.de/fhir/sid/stationid`/1234)**status**: Active

> **location****location**: Ward 56789 (Identifier: `https://test.krankenhaus.de/fhir/sid/stationid`/56789)**status**: Completed**physicalType**: Ward

**serviceProvider**: Fachabteilung für Orthopädie und Endoprothetik (Identifier: `https://test.krankenhaus.de/fhir/sid/fachabteilungsid`/ORTHO-1234)

