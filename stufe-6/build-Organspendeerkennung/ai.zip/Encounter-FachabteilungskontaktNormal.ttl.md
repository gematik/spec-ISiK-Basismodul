# null - TTL Representation - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## : null - TTL Representation

[Raw ttl](Encounter-FachabteilungskontaktNormal.ttl) | [Download](Encounter-FachabteilungskontaktNormal.ttl)

