#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## Account: 

Profile: [ISiKAbrechnungsfall](StructureDefinition-ISiKAbrechnungsfall.md)

**identifier**: Account number/0123456789

**status**: Active

**type**: inpatient encounter

**subject**: [Töchterchen Musterfrau (official) Female, DoB: 2010-01-01 ( Medical record number)](Patient-SZ1Patient.md)

> **coverage****Abrechnungsart**: [Abrechnungsart: DRG](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/CodeSystem/dkgev/Abrechnungsart#Abrechnungsart-DRG) (Diagnosebezogene Fallgruppen)**coverage**: [Coverage: status = active; type = gesetzliche Krankenversicherung](Coverage-SZ1VersicherungGesetzlich.md)

> **coverage****Abrechnungsart**: [Abrechnungsart: SZ](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/CodeSystem/dkgev/Abrechnungsart#Abrechnungsart-SZ) (Selbstzahlerrechnung)**coverage**: [Coverage: status = active; type = Selbstzahler](Coverage-SZ1VersicherungSelbstzahler.md)

