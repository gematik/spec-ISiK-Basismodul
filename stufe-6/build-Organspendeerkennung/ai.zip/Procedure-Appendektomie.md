#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## Procedure: 

Profile: [ISiKProzedur](StructureDefinition-ISiKProzedur.md)

**ExtensionProzedurDokumentationsdatum**: 2020-04-23

**status**: Completed

**category**: Surgical procedure (procedure)

**code**: Entfernung des Blinddarms

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**performed**: 2020-04-23

**note**: 

> 

Testnotiz


