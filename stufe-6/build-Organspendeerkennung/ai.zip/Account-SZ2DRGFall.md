#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## Account: 

Profile: [ISiKAbrechnungsfall](StructureDefinition-ISiKAbrechnungsfall.md)

> **Fallbezogene Abrechnungsrelevanz von Diagnosen und Prozeduren**
* Use: [KontaktDiagnoseProzedur: hospital-main-diagnosis](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/CodeSystem/KontaktDiagnoseProzedur#KontaktDiagnoseProzedur-hospital-main-diagnosis) (Krankenhaus Hauptdiagnose)
* Referenz: [Condition Diabetes mellitus, Typ 1: Mit Augenkomplikationen: Nicht als entgleist bezeichnet](Condition-SZ2Primaerdiagnose.md)

**identifier**: Account number/22222222222

**status**: Active

**type**: inpatient encounter

**subject**: [Friedlinde Musterfrau (official) Female, DoB: 1924-01-01 ( Medical record number)](Patient-SZ2Patient.md)

### Coverages

| | | |
| :--- | :--- | :--- |
| - | **Extension** | **Coverage** |
| * |  | [Coverage: status = active; type = gesetzliche Krankenversicherung](Coverage-SZ2VersicherungGesetzlich.md) |

