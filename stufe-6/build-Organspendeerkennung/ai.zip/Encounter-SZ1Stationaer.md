#  - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* ****

## Encounter: 

Profile: [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)

**identifier**: Visit number/0123456789-2

**status**: Finished

**class**: [ActCode: IMP](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html#v3-ActCode-IMP) (inpatient encounter)

**type**: Abteilungskontakt, Normalstationär

**subject**: [Töchterchen Musterfrau (official) Female, DoB: 2010-01-01 ( Medical record number)](Patient-SZ1Patient.md)

**period**: 2024-10-07 --> 2024-10-10

**account**: [Account: identifier = Account number; status = active; type = inpatient encounter](Account-SZ1DRGFall.md)

### Hospitalizations

| | |
| :--- | :--- |
| - | **Extension** |
| * |  |

> **location****location**: Bettenstellplatz 123 (Identifier: `http://beispiel-krankenhaus.de/sid/betten`/123)**status**: Active**physicalType**: Bed

> **location****location**: Zimmer 12 (Identifier: `http://beispiel-krankenhaus.de/sid/zimmer`/12)**status**: Active**physicalType**: Room

