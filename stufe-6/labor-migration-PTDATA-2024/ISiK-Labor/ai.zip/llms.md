# labor#6.0.0-rc: ISiK Labor Implementierungsleitfaden

## Pages

* [Einführung](index.md)
* [Bestätigungsrelevante Systeme](BestaetigungsrelevanteSysteme.md)
* [Überleitung Intensiv](UeberleitungIntensiv.md)
* [Kompatibilität](Kompatibilitaet.md)
* [Interaktionen und Search Types](InteraktionenUndSearchTypes.md)
* [REST-API](RestApi.md)
* [Artifacts Summary](artifacts.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Release Notes](ReleaseNotes.md)
* [Artefakte](artifacts-isik.md)
* [AMTS](AMTS.md)
* [Übergreifende Use Cases](UebergreifendeUseCases.md)

## Resources

### ValueSets

* [ObservationCodesCRP](ValueSet-ObservationCodesCRP.md)
* [ObservationCodesGFR](ValueSet-ObservationCodesGFR.md)
* [ObservationCodesHb](ValueSet-ObservationCodesHb.md)
* [ObservationCodesPCT](ValueSet-ObservationCodesPCT.md)
* [ObservationCodesSerumkreatinin](ValueSet-ObservationCodesSerumkreatinin.md)
* [ObservationCodesTSH](ValueSet-ObservationCodesTSH.md)
* [ObservationCodesThrombozyten](ValueSet-ObservationCodesThrombozyten.md)
* [ObservationCodesTroponin](ValueSet-ObservationCodesTroponin.md)
* [ObservationUnitsCRP](ValueSet-ObservationUnitsCRP.md)
* [ObservationUnitsGFR](ValueSet-ObservationUnitsGFR.md)
* [ObservationUnitsHb](ValueSet-ObservationUnitsHb.md)
* [ObservationUnitsPCT](ValueSet-ObservationUnitsPCT.md)
* [ObservationUnitsSerumkreatinin](ValueSet-ObservationUnitsSerumkreatinin.md)
* [ObservationUnitsTSH](ValueSet-ObservationUnitsTSH.md)
* [ObservationUnitsThrombozyten](ValueSet-ObservationUnitsThrombozyten.md)
* [ObservationUnitsTroponin](ValueSet-ObservationUnitsTroponin.md)

### Resource Profiles

* [ISiKLaboruntersuchung](StructureDefinition-ISiKLaboruntersuchung.md)
* [ISiKLaboruntersuchungCRP](StructureDefinition-ISiKLaboruntersuchungCRP.md)
* [ISiKLaboruntersuchungGFR](StructureDefinition-ISiKLaboruntersuchungGFR.md)
* [ISiKLaboruntersuchungHb](StructureDefinition-ISiKLaboruntersuchungHb.md)
* [ISiKLaboruntersuchungPCT](StructureDefinition-ISiKLaboruntersuchungPCT.md)
* [ISiKLaboruntersuchungSerumkreatinin](StructureDefinition-ISiKLaboruntersuchungSerumkreatinin.md)
* [ISiKLaboruntersuchungTSH](StructureDefinition-ISiKLaboruntersuchungTSH.md)
* [ISiKLaboruntersuchungThrombozyten](StructureDefinition-ISiKLaboruntersuchungThrombozyten.md)
* [ISiKLaboruntersuchungTroponin](StructureDefinition-ISiKLaboruntersuchungTroponin.md)

### CapabilityStatements

* [ISiK CapabilityStatement Labor Minimal Rolle (Expanded)](CapabilityStatement-ISiKCapabilityStatementLaborMinimalRolle-expanded.md)
* [ISiK CapabilityStatement Labor Minimal Rolle](CapabilityStatement-ISiKCapabilityStatementLaborMinimalRolle.md)

### ImplementationGuides

* [ISiK Labor Implementierungsleitfaden](index.md)

### Observations

* [ExampleISiKLaboruntersuchungCRP1](Observation-ExampleISiKLaboruntersuchungCRP1.md)
* [ExampleISiKLaboruntersuchungGFR1](Observation-ExampleISiKLaboruntersuchungGFR1.md)
* [ExampleISiKLaboruntersuchungHb1](Observation-ExampleISiKLaboruntersuchungHb1.md)
* [ExampleISiKLaboruntersuchungPCT1](Observation-ExampleISiKLaboruntersuchungPCT1.md)
* [ExampleISiKLaboruntersuchungSerumkreatinin1](Observation-ExampleISiKLaboruntersuchungSerumkreatinin1.md)
* [ExampleISiKLaboruntersuchungTSH1](Observation-ExampleISiKLaboruntersuchungTSH1.md)
* [ExampleISiKLaboruntersuchungThrombozyten1](Observation-ExampleISiKLaboruntersuchungThrombozyten1.md)
* [ExampleISiKLaboruntersuchungTroponin1](Observation-ExampleISiKLaboruntersuchungTroponin1.md)
