# Intensivversorgung - ISiK Vitalparameter Implementierungsleitfaden v6.0.0-rc

ISiK Vitalparameter Implementierungsleitfaden

Version 6.0.0-rc - 6.0.0-rc 

* [**Table of Contents**](toc.md)
* **Intensivversorgung**

## Intensivversorgung

# Überleitung Intensivversorgung im Krankenhaus

Ein Kontext, der durch eine Schnittstelle zur Übermittlung von Vitalparametern insbesondere unterstützt werden soll, betrifft den Übergang zwischen Akut- und Normalversorgung.

Dies geht jedoch über den Kontext des vorliegenden Implementierungsleitfadens hinaus und ist ein einem eigenen [Implementierungsleitfaden ICU-Normalstation Workflow](https://simplifier.net/guide/isik-icu-stufe-5) abgebildet. Dort sind Anwendungsfälle rund um den bidirektionalen Überleitungsprozess zwischen einer Intensiv- und einer Normalstation innerhalb eines Krankenhauses berücksichtigt, respektive die bidirektionale Kommunikation von Vitalparametern und Körpermaßen zwischen einem KIS und einem PDMS.

