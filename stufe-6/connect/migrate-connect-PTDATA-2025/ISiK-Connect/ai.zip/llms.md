# connect#6.0.0-rc: ISiK Connect Implementierungsleitfaden

## Pages

* [Einführung](index.md)
* [Conformance: Scopes und Kontexte](ConformanceScopesKontexte.md)
* [ISiK Connect Kontext](Kontext.md)
* [Conformance: Smart Capabilities](ConformanceSmartCapabilities.md)
* [Artifacts Summary](artifacts.md)
* [Festlegungen zur Kompatibilität der gematik-Spezifikation](KompatibilitaetDerGematikSpezifikation.md)
* [ISiK-Connect: Autorisierung](ISiKAutorisierung.md)
* [Übergreifende Festlegungen und Kompatibilität](UebergreifendeFestlegungen.md)
* [Akteure](Akteure.md)
* [Auto Provisioning von Zugriffsrechten auf Basis externer Authentifizierungsdienste](AutoProvisioning.md)
* [SMART Backend Services](BackendServices.md)
* [Release Notes](ReleaseNotes.md)
* [Anforderungsübersicht](Anforderungsuebersicht.md)
* [ISiK Connect und Smart-on-FHIR](ISiKundSMART.md)

## Resources

### ImplementationGuides

* [ISiK Connect Implementierungsleitfaden](index.md)
