# ObservationCodesCRP - ISiK Formularmodul Implementation Guide v6.0.0-rc

ISiK Formularmodul Implementation Guide

Version 6.0.0-rc - ci-build 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ObservationCodesCRP**

## ValueSet: ObservationCodesCRP 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/ValueSet/ObservationCodesCRP | *Version*:6.0.0-rc |
| Active as of 2025-12-17 | *Computable Name*:ObservationCodesCRP |

 
Enthält LOINC-Codes für die Observation CRP 

 **References** 

* [ISiKLaboruntersuchungCRP](StructureDefinition-ISiKLaboruntersuchungCRP.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ObservationCodesCRP",
  "url" : "https://gematik.de/fhir/isik/ValueSet/ObservationCodesCRP",
  "version" : "6.0.0-rc",
  "name" : "ObservationCodesCRP",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-17",
  "publisher" : "gematik GmbH",
  "contact" : [
    {
      "name" : "gematik GmbH",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://gematik.de"
        }
      ]
    }
  ],
  "description" : "Enthält LOINC-Codes für die Observation CRP",
  "compose" : {
    "include" : [
      {
        "system" : "http://loinc.org",
        "concept" : [
          {
            "code" : "71426-1",
            "display" : "C-reaktives Protein [Masse/Volumen] in Blut mittels Hochsensitivitätsmethode"
          },
          {
            "code" : "30522-7",
            "display" : "C-reaktives Protein [Masse/Volumen] in Serum oder Plasma mittels Hochsensitivitätsmethode"
          },
          {
            "code" : "76486-0",
            "display" : "C-reaktives Protein [Mol/Volumen] in Serum oder Plasma mittels Hochsensitivitätsmethode"
          },
          {
            "code" : "45062-7",
            "display" : "C-reaktives Protein [Masse/Volumen] in Liquor"
          },
          {
            "code" : "48421-2",
            "display" : "C-reaktives Protein [Masse/Volumen] in Kapillarblut"
          },
          {
            "code" : "11039-5",
            "display" : "C-reaktives Protein [Nachweis] in Serum oder Plasma"
          },
          {
            "code" : "76485-2",
            "display" : "C-reaktives Protein [Mol/Volumen] in Serum oder Plasma"
          },
          {
            "code" : "16503-5",
            "display" : "C-reaktives Protein [Masse/Volumen] in Körperflüssigkeit"
          },
          {
            "code" : "1988-5",
            "display" : "C-reaktives Protein [Masse/Volumen] in Serum oder Plasma"
          },
          {
            "code" : "14634-0",
            "display" : "C-reaktives Protein [Titer] in Serum oder Plasma"
          }
        ]
      }
    ]
  }
}

```
