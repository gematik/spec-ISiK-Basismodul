# BundleExampleIntensivstation - ISiK Organspendeerkennung v0.0.1-rc

ISiK Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **BundleExampleIntensivstation**

## Bundle: BundleExampleIntensivstation



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BundleExampleIntensivstation",
  "meta" : {
    "profile" : [
      "https://gematik.de/fhir/isik/StructureDefinition/ISiKBerichtBundle"
    ]
  },
  "identifier" : {
    "type" : {
      "coding" : [
        {
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "FILL"
        }
      ]
    },
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:a8f12c45-8e61-4f32-b123-456789abcdef"
  },
  "type" : "document",
  "timestamp" : "2025-07-21T00:00:00+02:00",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:54d0804f-c770-4b61-a175-28fa1875b2a9",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "54d0804f-c770-4b61-a175-28fa1875b2a9",
        "meta" : {
          "profile" : [
            "https://gematik.de/fhir/isik/StructureDefinition/ISiKBerichtSubSysteme"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_54d0804f-c770-4b61-a175-28fa1875b2a9\"> </a><h2>Verlegungsbericht für Patient Herrn Thomas Müller (1234567890) - Intensivstation 0100</h2><div><strong>Dokument-ID:</strong><span>urn:uuid:54d0804f-c770-4b61-a175-28fa1875b2a9</span><span> (urn:ietf:rfc:3986)</span></div><div><strong>Status:</strong><span>final</span></div><div><strong>Dokumenttyp:</strong><span><span>Verlegungsbericht</span><span> (http://dvmd.de/fhir/CodeSystem/kdl)</span></span></div><div><strong>Erstellt am:</strong><span>21.07.2025 00:00</span></div><div><strong>Autor:</strong><ul><li><span>Dr. Alenia Vogt</span></li></ul></div><div><strong>Patient:</strong><span>urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Fall:</strong><span>urn:uuid:88bdd3e7-fbd1-42b8-bd9f-9afdf1e31d41</span></div></div>"
        },
        "identifier" : {
          "type" : {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                "code" : "FILL"
              }
            ]
          },
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:uuid:54d0804f-c770-4b61-a175-28fa1875b2a9"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://dvmd.de/fhir/CodeSystem/kdl",
              "code" : "AD010116",
              "display" : "Verlegungsbericht"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79"
        },
        "encounter" : {
          "reference" : "urn:uuid:88bdd3e7-fbd1-42b8-bd9f-9afdf1e31d41"
        },
        "date" : "2025-07-21T00:00:00+02:00",
        "author" : [
          {
            "display" : "Dr. Alenia Vogt"
          }
        ],
        "title" : "Verlegungsbericht für Patient Herrn Thomas Müller (1234567890) - Intensivstation 0100",
        "section" : [
          {
            "title" : "Beatmungswerte (Unterstützungsdruck) vom 22.07.2025 - #1",
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div><h3>Observation</h3><div><strong>Typ:</strong><span><span>Pressure support setting Ventilator</span><span> (http://loinc.org)</span></span></div><div><strong>Status:</strong><span>FINAL</span></div><div><strong>Kategorie:</strong><ul><li><span><span><span>Artificial ventilation (regime/therapy)</span><span> (http://snomed.info/sct)</span></span></span></li></ul></div><div><strong>Patient:</strong><span>urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Zeitpunkt:</strong><span>2025-07-21T00:00:00+02:00</span></div><div><strong>Wert:</strong><span>6</span><span>cm[H2O]</span></div><div><strong>Teil von:</strong><ul><li><span>urn:uuid:61a2e9af-88f9-4ee2-a97f-c136530aadba</span></li></ul></div></div></div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:32bb8c8a-418c-4fc2-b1c7-c33f1a99a464"
              }
            ]
          },
          {
            "title" : "Patient",
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Patient</h3><div><strong>ID:</strong><span>Patient/urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Patienten-Identifikator:</strong><ul><li><span><span>MR</span>: </span><span>1234567890</span><span> (https://example.org/fhir/sid/pid)</span></li></ul></div><div><strong>Name:</strong><span> Thomas <b>MÜLLER</b></span></div><div><strong>Geschlecht:</strong><span>male</span></div><div><strong>Geburtsdatum:</strong><span>11.04.1965</span></div></div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79"
              }
            ]
          },
          {
            "title" : "Encounter",
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Encounter</h2><div><strong>Fallnummer:</strong><span><span>ICU-2025-001</span><span> (https://example.org/fhir/sid/encounter-id)</span></span></div><div><strong>Status:</strong><span>in-progress</span></div><div><strong>Kontaktart:</strong><span>inpatient encounter</span></div><div><strong>Typ:</strong><ul><li><span><span><span>Abteilungskontakt</span><span> (http://fhir.de/CodeSystem/Kontaktebene)</span></span></span></li></ul></div><div><strong>Abteilung:</strong><span><span>Innere Medizin</span><span> (Code: 0100)</span></span></div><div><strong>Einrichtung:</strong><span>Intensivstation - Innere Medizin</span></div><div><strong>Patient:</strong><span>urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Zeitraum:</strong><span>21.07.2025 00:00</span><span> (laufend)</span></div></div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:88bdd3e7-fbd1-42b8-bd9f-9afdf1e31d41"
              }
            ]
          },
          {
            "title" : "Observation",
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Observation</h3><div><strong>Typ:</strong><span><span>85354-9</span><span> (http://loinc.org)</span></span></div><div><strong>Status:</strong><span>FINAL</span></div><div><strong>Kategorie:</strong><ul><li><span><span><span>vital-signs</span><span> (http://terminology.hl7.org/CodeSystem/observation-category)</span></span></span></li></ul></div><div><strong>Patient:</strong><span>urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Zeitpunkt:</strong><span>2025-07-22T14:10:00+02:00</span></div><div><strong>Messwerte:</strong><table style=\"border-collapse: collapse; width: 100%;\"><thead><tr style=\"background-color: #f2f2f2;\"><th style=\"border: 1px solid #ddd; padding: 8px;\">Parameter</th><th style=\"border: 1px solid #ddd; padding: 8px;\">Wert</th><th style=\"border: 1px solid #ddd; padding: 8px;\">Einheit</th></tr></thead><tbody><tr><td style=\"border: 1px solid #ddd; padding: 8px;\"><span><span>Systolisch</span></span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>210</span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>mmHg</span></td></tr><tr><td style=\"border: 1px solid #ddd; padding: 8px;\"><span><span>Diastolisch</span></span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>115</span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>mmHg</span></td></tr><tr><td style=\"border: 1px solid #ddd; padding: 8px;\"><span><span>Mittlerer arterieller Druck</span></span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>140</span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>mmHg</span></td></tr></tbody></table></div></div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:880d8c69-fc05-4e1f-8203-a8ff40007f84"
              }
            ]
          },
          {
            "title" : "Procedure",
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Prozedur</h3><div><strong>Typ:</strong><ul><li><span>Jet ventilation procedure (procedure)</span><span> (http://snomed.info/sct)</span></li></ul></div><div><strong>Status:</strong><span>COMPLETED</span></div><div><strong>Kategorie:</strong><span/><ul><li><span>Artificial ventilation (regime/therapy)</span><span> (http://snomed.info/sct)</span></li></ul></div><div><strong>Patient:</strong><span>urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Durchführungszeitraum:</strong><span>21.07.2025 00:00</span><span> (laufend)</span></div></div>"
            },
            "entry" : [
              {
                "reference" : "urn:uuid:61a2e9af-88f9-4ee2-a97f-c136530aadba"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "11c3de2f-d461-4063-a0c2-fde122e76a79",
        "meta" : {
          "profile" : [
            "https://gematik.de/fhir/isik/StructureDefinition/ISiKPatient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_11c3de2f-d461-4063-a0c2-fde122e76a79\"> </a><h3>Patient</h3><div><strong>ID:</strong><span>Patient/urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Patienten-Identifikator:</strong><ul><li><span><span>MR</span>: </span><span>1234567890</span><span> (https://example.org/fhir/sid/pid)</span></li></ul></div><div><strong>Name:</strong><span> Thomas <b>MÜLLER</b></span></div><div><strong>Geschlecht:</strong><span>male</span></div><div><strong>Geburtsdatum:</strong><span>11.04.1965</span></div></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "MR"
                }
              ]
            },
            "system" : "https://example.org/fhir/sid/pid",
            "value" : "1234567890"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "Müller",
            "given" : ["Thomas"]
          }
        ],
        "gender" : "male",
        "birthDate" : "1965-04-11"
      }
    },
    {
      "fullUrl" : "urn:uuid:88bdd3e7-fbd1-42b8-bd9f-9afdf1e31d41",
      "resource" : {
        "resourceType" : "Encounter",
        "id" : "88bdd3e7-fbd1-42b8-bd9f-9afdf1e31d41",
        "meta" : {
          "profile" : [
            "https://gematik.de/fhir/isik/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_88bdd3e7-fbd1-42b8-bd9f-9afdf1e31d41\"> </a><h2>Encounter</h2><div><strong>Fallnummer:</strong><span><span>ICU-2025-001</span><span> (https://example.org/fhir/sid/encounter-id)</span></span></div><div><strong>Status:</strong><span>in-progress</span></div><div><strong>Kontaktart:</strong><span>inpatient encounter</span></div><div><strong>Typ:</strong><ul><li><span><span><span>Abteilungskontakt</span><span> (http://fhir.de/CodeSystem/Kontaktebene)</span></span></span></li></ul></div><div><strong>Abteilung:</strong><span><span>Innere Medizin</span><span> (Code: 0100)</span></span></div><div><strong>Einrichtung:</strong><span>Intensivstation - Innere Medizin</span></div><div><strong>Patient:</strong><span>urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Zeitraum:</strong><span>21.07.2025 00:00</span><span> (laufend)</span></div></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "VN"
                }
              ]
            },
            "system" : "https://example.org/fhir/sid/encounter-id",
            "value" : "ICU-2025-001"
          }
        ],
        "status" : "in-progress",
        "class" : {
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
          "code" : "IMP",
          "display" : "inpatient encounter"
        },
        "type" : [
          {
            "coding" : [
              {
                "system" : "http://fhir.de/CodeSystem/Kontaktebene",
                "code" : "abteilungskontakt",
                "display" : "Abteilungskontakt"
              }
            ]
          }
        ],
        "serviceType" : {
          "coding" : [
            {
              "system" : "http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel",
              "code" : "0100",
              "display" : "Innere Medizin"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79"
        },
        "period" : {
          "start" : "2025-07-21T00:00:00+02:00"
        },
        "serviceProvider" : {
          "identifier" : {
            "system" : "https://example.org/fhir/sid/abteilungsid",
            "value" : "ICU-001"
          },
          "display" : "Intensivstation - Innere Medizin"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:880d8c69-fc05-4e1f-8203-a8ff40007f84",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "880d8c69-fc05-4e1f-8203-a8ff40007f84",
        "meta" : {
          "profile" : [
            "https://gematik.de/fhir/isik/StructureDefinition/ISiKBlutdruckSystemischArteriell"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_880d8c69-fc05-4e1f-8203-a8ff40007f84\"> </a><h3>Observation</h3><div><strong>Typ:</strong><span><span>85354-9</span><span> (http://loinc.org)</span></span></div><div><strong>Status:</strong><span>FINAL</span></div><div><strong>Kategorie:</strong><ul><li><span><span><span>vital-signs</span><span> (http://terminology.hl7.org/CodeSystem/observation-category)</span></span></span></li></ul></div><div><strong>Patient:</strong><span>urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Zeitpunkt:</strong><span>2025-07-22T14:10:00+02:00</span></div><div><strong>Messwerte:</strong><table style=\"border-collapse: collapse; width: 100%;\"><thead><tr style=\"background-color: #f2f2f2;\"><th style=\"border: 1px solid #ddd; padding: 8px;\">Parameter</th><th style=\"border: 1px solid #ddd; padding: 8px;\">Wert</th><th style=\"border: 1px solid #ddd; padding: 8px;\">Einheit</th></tr></thead><tbody><tr><td style=\"border: 1px solid #ddd; padding: 8px;\"><span><span>Systolisch</span></span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>210</span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>mmHg</span></td></tr><tr><td style=\"border: 1px solid #ddd; padding: 8px;\"><span><span>Diastolisch</span></span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>115</span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>mmHg</span></td></tr><tr><td style=\"border: 1px solid #ddd; padding: 8px;\"><span><span>Mittlerer arterieller Druck</span></span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>140</span></td><td style=\"border: 1px solid #ddd; padding: 8px;\"><span>mmHg</span></td></tr></tbody></table></div></div>"
        },
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "vital-signs"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "85354-9"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79"
        },
        "effectiveDateTime" : "2025-07-22T14:10:00+02:00",
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "8480-6"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 210,
              "unit" : "mmHg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mm[Hg]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "8462-4"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 115,
              "unit" : "mmHg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mm[Hg]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "8478-0"
                }
              ]
            },
            "valueQuantity" : {
              "value" : 140,
              "unit" : "mmHg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mm[Hg]"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:61a2e9af-88f9-4ee2-a97f-c136530aadba",
      "resource" : {
        "resourceType" : "Procedure",
        "id" : "61a2e9af-88f9-4ee2-a97f-c136530aadba",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_61a2e9af-88f9-4ee2-a97f-c136530aadba\"> </a><h3>Prozedur</h3><div><strong>Typ:</strong><ul><li><span>Jet ventilation procedure (procedure)</span><span> (http://snomed.info/sct)</span></li></ul></div><div><strong>Status:</strong><span>COMPLETED</span></div><div><strong>Kategorie:</strong><span/><ul><li><span>Artificial ventilation (regime/therapy)</span><span> (http://snomed.info/sct)</span></li></ul></div><div><strong>Patient:</strong><span>urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Durchführungszeitraum:</strong><span>21.07.2025 00:00</span><span> (laufend)</span></div></div>"
        },
        "status" : "completed",
        "category" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "40617009",
              "display" : "Artificial ventilation (regime/therapy)"
            }
          ]
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "4764004",
              "display" : "Jet ventilation procedure (procedure)"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79"
        },
        "performedPeriod" : {
          "start" : "2025-07-21"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:32bb8c8a-418c-4fc2-b1c7-c33f1a99a464",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "32bb8c8a-418c-4fc2-b1c7-c33f1a99a464",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_32bb8c8a-418c-4fc2-b1c7-c33f1a99a464\"> </a><h3>Observation</h3><div><strong>Typ:</strong><span><span>Pressure support setting Ventilator</span><span> (http://loinc.org)</span></span></div><div><strong>Status:</strong><span>FINAL</span></div><div><strong>Kategorie:</strong><ul><li><span><span><span>Artificial ventilation (regime/therapy)</span><span> (http://snomed.info/sct)</span></span></span></li></ul></div><div><strong>Patient:</strong><span>urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79</span></div><div><strong>Zeitpunkt:</strong><span>2025-07-21T00:00:00+02:00</span></div><div><strong>Wert:</strong><span>6</span><span>cm[H2O]</span></div><div><strong>Teil von:</strong><ul><li><span>urn:uuid:61a2e9af-88f9-4ee2-a97f-c136530aadba</span></li></ul></div></div>"
        },
        "partOf" : [
          {
            "reference" : "urn:uuid:61a2e9af-88f9-4ee2-a97f-c136530aadba"
          }
        ],
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "40617009",
                "display" : "Artificial ventilation (regime/therapy)"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "20079-0",
              "display" : "Pressure support setting Ventilator"
            }
          ]
        },
        "subject" : {
          "reference" : "urn:uuid:11c3de2f-d461-4063-a0c2-fde122e76a79"
        },
        "effectiveDateTime" : "2025-07-21T00:00:00+02:00",
        "valueQuantity" : {
          "value" : 6,
          "unit" : "cm[H2O]",
          "system" : "http://unitsofmeasure.org",
          "code" : "cm[H2O]"
        }
      }
    }
  ]
}

```
