# ISiKVersicherungsverhaeltnisGesetzlich - Organspendeerkennung v0.0.1-rc

Organspendeerkennung

Version 0.0.1-rc - STU1 

* [**Table of Contents**](toc.md)
* [**FHIR-Artefakte**](artifacts.md)
* **ISiKVersicherungsverhaeltnisGesetzlich**

## Resource Profile: ISiKVersicherungsverhaeltnisGesetzlich 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/ISiKVersicherungsverhaeltnisGesetzlich | *Version*:0.0.1-rc |
| Active as of 2025-12-17 | *Computable Name*:ISiKVersicherungsverhaeltnisGesetzlich |

 
Dieses Profil ermöglicht die Darstellung eines gesetzlichen Versicherungsverhältnisses in ISiK Szenarien. 

### Motivation

 
ISiK unterstützt Anwendungsszenarien, in denen durch das Krankenhaus erbrachte Leistungen erfasst oder gegenüber Kostenträgern abgerechnet werden. In diesen Anwendungsszenarien wird das Versicherungsverhältnis verwendet, um bspw. den Versicherungsstatus oder die Rechnungsanschrift der Versicherung zu ermitteln.
 In FHIR werden Versicherungsverhältnisse mit der Coverage-Ressource repräsentiert. 

### Kompatibilität

 
Das Profil ISiKVersicherungsverhaeltnisGesetzlich basiert auf dem [GKV-Profil der deutschen Basisprofile](http://fhir.de/StructureDefinition/coverage-de-basis). Instanzen, die gegen ISiKVersicherungsverhaeltnisGesetzlich valide sind, sind auch valide gegen 
* [GKV-Profil der deutschen Basisprofile](http://fhir.de/StructureDefinition/coverage-de-basis)
 
Hinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden. 

**Usages:**

* Examples for this Profile: [Coverage/CoverageGesetzlich](Coverage-CoverageGesetzlich.md), [Coverage/SZ1VersicherungGesetzlich](Coverage-SZ1VersicherungGesetzlich.md) and [Coverage/SZ2VersicherungGesetzlich](Coverage-SZ2VersicherungGesetzlich.md)
* CapabilityStatements using this Profile: [Akteur "ISiKCapabilityStatementBasisServerAkteur" (Expanded)](CapabilityStatement-ISiKCapabilityStatementBasisServerAkteur-expanded.md) and [CapabilityStatement für Rolle "ISiKCapabilityStatementVersicherungsverhaeltnisRolle"](CapabilityStatement-ISiKCapabilityStatementVersicherungsverhaeltnisRolle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/Organspendeerkennung.test.ig|current/StructureDefinition/ISiKVersicherungsverhaeltnisGesetzlich)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ISiKVersicherungsverhaeltnisGesetzlich.csv), [Excel](StructureDefinition-ISiKVersicherungsverhaeltnisGesetzlich.xlsx), [Schematron](StructureDefinition-ISiKVersicherungsverhaeltnisGesetzlich.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ISiKVersicherungsverhaeltnisGesetzlich",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/ISiKVersicherungsverhaeltnisGesetzlich",
  "version" : "0.0.1-rc",
  "name" : "ISiKVersicherungsverhaeltnisGesetzlich",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-17",
  "description" : "Dieses Profil ermöglicht die Darstellung eines gesetzlichen Versicherungsverhältnisses in ISiK Szenarien.  \n### Motivation\nISiK unterstützt Anwendungsszenarien, in denen durch das Krankenhaus erbrachte Leistungen erfasst oder gegenüber Kostenträgern abgerechnet werden.\nIn diesen Anwendungsszenarien wird das Versicherungsverhältnis verwendet, um bspw. den Versicherungsstatus oder die Rechnungsanschrift der Versicherung zu ermitteln.  \nIn FHIR werden Versicherungsverhältnisse mit der Coverage-Ressource repräsentiert.\n\n### Kompatibilität\nDas Profil ISiKVersicherungsverhaeltnisGesetzlich basiert auf dem [GKV-Profil der deutschen Basisprofile](http://fhir.de/StructureDefinition/coverage-de-basis). \nInstanzen, die gegen ISiKVersicherungsverhaeltnisGesetzlich valide sind, sind auch valide gegen\n\n* [GKV-Profil der deutschen Basisprofile](http://fhir.de/StructureDefinition/coverage-de-basis)\n\nHinweise zu Inkompatibilitäten können über die [Portalseite](https://service.gematik.de/servicedesk/customer/portal/16) gemeldet werden.",
  "fhirVersion" : "4.0.1",
  "kind" : "resource",
  "abstract" : false,
  "type" : "Coverage",
  "baseDefinition" : "http://fhir.de/StructureDefinition/coverage-de-basis",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Coverage",
        "path" : "Coverage"
      },
      {
        "id" : "Coverage.status",
        "path" : "Coverage.status",
        "short" : "Status",
        "comment" : "Zeigt den aktuellen Status der Ressource an.     \n  **WICHTIGER Hinweis für Implementierer:**    \n  * Alle server-seitigen Implementierungen MÜSSEN in der Lage sein, \n  die systemintern möglichen Statuswerte korrekt in FHIR abzubilden, mindestens jedoch den Wert `active`.\n  * Alle client-seitigen Implementierungen MÜSSEN in der Lage sein, sämtliche Status-Codes zu interpretieren und dem Anwender in angemessener Form darstellen zu können, \n  beispielsweise durch Ausblenden/Durchstreichen von Ressourcen mit dem status `entered-in-error` und Ausgrauen von Ressourcen, die einen Plan- oder Entwurfs-Status haben.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.type",
        "path" : "Coverage.type",
        "comment" : "\n  Die Angabe der Versicherungsart `GKV` dient der Kennzeichnung dieser Coverage-Ressource als gesetzliches Versicherungsverhältnis.  \n  **Begründung Pflichtfeld:** Die Angabe der Versicherungsart dient der Unterscheidung, wenn zu einem Patienten mehrere Coverage-Ressourcen hinterlegt sind, \n  z.B. gesetzliche Versicherung + Selbszahlerverhältnis und als Suchkriterium, um gezielt nach der in einem konkreten Kontext relevanten Coverage suchen zu können.  \n  **Historie:**  \n  28.07.2017 (zulip): TC Konsens bzgl. Verwendung eines eigenen ValueSets anstelle des im Standard definierten preferred bindings, da die dortigen Codes nicht passen.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.type.coding",
        "path" : "Coverage.type.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "pattern",
              "path" : "$this"
            }
          ],
          "rules" : "open"
        },
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Coverage.type.coding:VersicherungsArtDeBasis",
        "path" : "Coverage.type.coding",
        "sliceName" : "VersicherungsArtDeBasis",
        "short" : "Codierte Darstellung der Versicherungsart",
        "min" : 1,
        "max" : "1",
        "patternCoding" : {
          "system" : "http://fhir.de/CodeSystem/versicherungsart-de-basis",
          "code" : "GKV"
        },
        "mustSupport" : true
      },
      {
        "id" : "Coverage.type.coding:VersicherungsArtDeBasis.system",
        "path" : "Coverage.type.coding.system",
        "short" : "Codier-Schema",
        "comment" : "Hier ist stets der Wert `http://fhir.de/CodeSystem/versicherungsart-de-basis` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Coverage.type.coding:VersicherungsArtDeBasis.code",
        "path" : "Coverage.type.coding.code",
        "short" : "Code",
        "comment" : "Hier ist stets der Code `GKV` anzugeben.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Coverage.subscriber",
        "path" : "Coverage.subscriber",
        "short" : "Hauptversicherte Person",
        "comment" : "Die hauptversicherte Person kann der Patient selbst sein, oder (z.B. im Falle einer Familienversicherung) auch ein Angehöriger (`RelatedPerson`)\n  **Begründung MS: Die Information über die hauptversicherte Person ist insbesondere im Kontext der Korrespondenz von Bedeutung, \n  da z.B. bei familienversicherten Kindern i.d.R. über die hauptversicherte Person korrespondiert wird.  \n\n  **Hinweis:** Die Angabe der VersichertenID des Hauptversicherten in `subscriber.identifier` ist verpflichtend. \n  Weitere Angaben zum Versicherten (Name, Adresse) können in einer `RelatedPerson`-Resource hinterlegt werden, auf die hier referenziert wird.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.subscriber.reference",
        "path" : "Coverage.subscriber.reference",
        "comment" : "Die Verlinkung auf eine Patienten- oder RelatedPerson-Ressource dient der technischen Zuordnung der Dokumentation zu einem Patienten/Angehörigen \n    und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.subscriber.identifier",
        "path" : "Coverage.subscriber.identifier",
        "short" : "Lebenslange Krankenversichertennummer der Hauptversicherten",
        "comment" : "Die als 'KVZ10' kodierte Versichertennummer ist der 10-stellige, \n      unveränderbare Teil der Versichertennummer, \n      der lesbar auf die Elektronische Gesundheitskarte aufgedruckt ist.\n      Er gilt für alle Krankenversichertennummern, \n      unabhängig davon, ob es sich um GKV, PKV oder Sonderkostenträger handelt.  \n      **Weitere Hinweise:** siehe [Deutschen Basisprofile](https://simplifier.net/guide/leitfaden-de-basis-r4/ig-markdown-LebenslangeKrankenversichertennummer10-stelligeKVID-Identifier?version=current)",
        "min" : 1,
        "type" : [
          {
            "code" : "Identifier",
            "profile" : ["http://fhir.de/StructureDefinition/identifier-kvid-10"]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Coverage.subscriber.identifier.system",
        "path" : "Coverage.subscriber.identifier.system",
        "short" : "Namensraum der Versichertennummer",
        "comment" : "Hier ist stets der Wert `http://fhir.de/sid/gkv/kvid-10` anzugeben.  \n      **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.subscriber.identifier.value",
        "path" : "Coverage.subscriber.identifier.value",
        "short" : "Lebenslange Krankenversichertennummer",
        "comment" : "Der 10-stellige, unveränderbare Teil der Versichertennummer.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.subscriber.display",
        "path" : "Coverage.subscriber.display",
        "short" : "Name des Hauptversicherten",
        "comment" : "**Begründung MS:** Da das die Versichertennummer nicht zur Darstellung für den Anwender geeignet ist, \n    sollte ergänzend der Name des Versicherten angegeben werden.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.beneficiary",
        "path" : "Coverage.beneficiary",
        "short" : "Versicherte Person",
        "comment" : "Hier handelt es ich konkret um den Patienten, der unter diesem Versicherungsverhältnis behandelt wird.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.beneficiary.reference",
        "path" : "Coverage.beneficiary.reference",
        "short" : "Patienten-Link",
        "comment" : "Die Verlinkung auf eine Patienten-Ressource dient der technischen Zuordnung der Dokumentation zu einem Patienten \n    und ermöglicht wichtige API-Funktionen wie verkettete Suche, (Reverse-)Include etc.",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Coverage.payor",
        "path" : "Coverage.payor",
        "short" : "Kostenträger",
        "comment" : "Die Angabe der IK-Nummer in `payor.identifier` sowie des Namens der Versicherung in `payor.display` ist zwingend erforderlich.  \n  Die Referenz auf eine Resource vom Typ `Organization` in `payor.reference`, die weitere Details zur Versicherung enthalten kann (z.B. Adresse, Kontaktdaten) ist optional.  \n\n  Die Angabe der IK-Nummer des Versicherers in payor.identifier ist verpflichtend. \n  Weitere Angaben zum Versicherer (Name, Adresse) können in einer Organization-Resource hinterlegt werden, auf die hier referenziert wird.",
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Coverage.payor.identifier",
        "path" : "Coverage.payor.identifier",
        "short" : "Institutskennzeichern der Versicherung",
        "comment" : "**Begründung Pflichtfeld:** Als eindeutiger Identifikator der Versicherung ist in vielen Fällen das Institutskennzeichen ausreichend.",
        "min" : 1,
        "type" : [
          {
            "code" : "Identifier",
            "profile" : ["http://fhir.de/StructureDefinition/identifier-iknr"]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Coverage.payor.identifier.system",
        "path" : "Coverage.payor.identifier.system",
        "short" : "Namensraum der IK-Nummer",
        "comment" : "Hier ist stets der Wert `http://fhir.de/sid/arge-ik/iknr` anzugeben.  \n      **Begründung Pflichtfeld:** `system` stellt in Kombination mit `value` die Eindeutigkeit eines Identifiers sicher.",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.payor.identifier.value",
        "path" : "Coverage.payor.identifier.value",
        "short" : "IK-Nummer",
        "comment" : "Das Institutskennzeichen der Versicherung",
        "mustSupport" : true
      },
      {
        "id" : "Coverage.payor.display",
        "path" : "Coverage.payor.display",
        "short" : "Name der Versicherung",
        "comment" : "**Begründung Pflichtfeld:** Da das Institutskennzeichen nicht zur Darstellung für den Anwender geeignet ist, \n    muss ergänzend der Name der Versicherung angegeben werden.",
        "min" : 1,
        "mustSupport" : true
      }
    ]
  }
}

```
