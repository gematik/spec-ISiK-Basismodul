# dokumentenaustausch#6.0.0-rc: ISiK Dokumentenaustausch Implementierungsleitfaden

## Pages

* [Einführung](index.md)
* [Interaktion: Dokumentenabfrage und -Zugriff](Dokumentenabfrage.md)
* [Kompatibilität zu IHE-Profilen](Kompatibilitaet.md)
* [Interaktionen](Interaktionen.md)
* [Abgrenzung zu ISiK Basis bei Kommunikation strukturierter Daten](Abgrenzung-Basis.md)
* [Interaktion: Erzeugen von Metadaten](ErzeugenVonMetadaten.md)
* [Interaktion: Dokumentenbereitstellung](Interaktion-Dokumentenbereitstellung.md)
* [FHIR-Artefakte](artifacts.md)
* [Übergreifende Festlegungen](UebergreifendeFestlegungen.md)
* [Akteure](Akteure.md)
* [Interaktion: Update von Metadaten](Update.md)
* [Release Notes](ReleaseNotes.md)

## Resources

### ValueSets

* [ISiKConfidentialityCodes](ValueSet-ISiKConfidentialityCodes.md)

### Resource Profiles

* [ISiKBinary](StructureDefinition-ISiKBinary.md)
* [Erforderliche Metadaten für Dokumentenaustausch in ISiK](StructureDefinition-ISiKDokumentenMetadaten.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)
* [ISiKTerminPriorityExtension](StructureDefinition-ISiKTerminPriorityExtension.md)

### CapabilityStatements

* [ISiK CapabilityStatement Dokumenten Server Akteur (Expanded)](CapabilityStatement-ISiKCapabilityStatementDokumentenServerAkteur.md)
* [ISiK CapabilityStatement Dokumenten Server Akteur](CapabilityStatement-ISiKCapabilityStatementDokumentenServerAkteur.md)
* [ISiK CapabilityStatement Dokumentenverwaltung Rolle](CapabilityStatement-ISiKCapabilityStatementDokumentenverwaltungRolle.md)
* [ISiK CapabilityStatement Metadaten Erzeugen Rolle](CapabilityStatement-ISiKCapabilityStatementMetadatenErzeugenRolle.md)
* [ISiK CapabilityStatement Metadaten Update Rolle](CapabilityStatement-ISiKCapabilityStatementMetadatenUpdateRolle.md)

### DocumentReferences

* [dok-beispiel-client-with-binary-jpeg-example-short](DocumentReference-dok-beispiel-client-with-binary-jpeg-example-short.md)
* [dok-beispiel-client-with-binary-jpeg-example](DocumentReference-dok-beispiel-client-with-binary-jpeg-example.md)
* [dok-beispiel-client-with-binary-pdf-example-short](DocumentReference-dok-beispiel-client-with-binary-pdf-example-short.md)
* [dok-beispiel-client-with-binary-pdf-example](DocumentReference-dok-beispiel-client-with-binary-pdf-example.md)
* [dok-beispiel-server](DocumentReference-dok-beispiel-server.md)

### ImplementationGuides

* [ISiK Dokumentenaustausch Implementierungsleitfaden](index.md)

### OperationDefinitions

* [Update document metadata](OperationDefinition-UpdateMetadata.md)
