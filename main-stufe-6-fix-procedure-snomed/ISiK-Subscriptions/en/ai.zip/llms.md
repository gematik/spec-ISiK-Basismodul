# subscription#6.0.0: ISiK Subscription Implementierungsleitfaden(en)

## Pages

* [Einführung](index.md)
* [Funktionen und Interaktionen](FunktionenInteraktionen.md)
* [Akteure](Akteure.md)
* [Patient merge und Notification](Patientenzusammenfuehrung.md)
* [Use Cases - Übersicht](UseCases.md)
* [FHIR-Artefakte](artifacts.md)
* [Übergreifende Festlegungen](Festlegungen.md)
* [Encounter Merge Notification (Kontaktzusammenführung)](Kontaktzusammenfuehrung.md)
* [Release Notes](ReleaseNotes.md)

## Resources

### CodeSystems

* [ISiK-SubscriptionTopic](CodeSystem-ISiKSubscriptionTopic.md)
* [MIME Types (Fragment)](CodeSystem-MimeTypeCS.md)
* [SubscriptionNotificationType](CodeSystem-subscription-notification-type.md)

### ValueSets

* [FhirMimeTypeVS](ValueSet-FhirMimeTypeVS.md)
* [ISiKSubscriptionTopic ValueSet](ValueSet-ISiKSubscriptionTopicVS.md)
* [SubscriptionNotificationType](ValueSet-subscription-notification-type.md)

### Resource Profiles

* [R4 Topic-Based Subscription Notification Bundle](StructureDefinition-BackportSubscriptionNotificationR4Fixed.md)
* [R4 Backported R5 SubscriptionStatus](StructureDefinition-BackportSubscriptionStatusR4Fixed.md)
* [ISiK Subscription](StructureDefinition-ISiKSubscription.md)

### Extensions

* [ISiK CapabilityStatement Imports Expectation](StructureDefinition-ExtensionISiKCapabilityStatementImportsExpectation.md)

### CapabilityStatements

* [CapabilityStatement für Rolle &quot;Subscription&quot;](CapabilityStatement-ISiKCapabilityStatementSubscriptionRolle.md)
* [Akteur &quot;ISiKCapabilityStatementSubscriptionServerAkteur&quot; (Expanded)](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur-expanded.md)
* [Akteur &quot;ISiKCapabilityStatementSubscriptionServerAkteur&quot;](CapabilityStatement-ISiKCapabilityStatementSubscriptionServerAkteur.md)

### ImplementationGuides

* [ISiK Subscription Implementierungsleitfaden](ImplementationGuide-subscription.md)

### Parameters

* [exp-params](Parameters-exp-params.md)

### Subscriptions

* [PatientMergeSubscriptionExample](Subscription-PatientMergeSubscriptionExample.md)
