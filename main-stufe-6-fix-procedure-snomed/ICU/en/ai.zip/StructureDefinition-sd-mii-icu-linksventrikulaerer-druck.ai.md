# SD MII ICU Linksventrikulaerer Druck - ISiK ICU v6.0.0

ISiK ICU

Version 6.0.0 - active 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SD MII ICU Linksventrikulaerer Druck**

## Resource Profile: SD MII ICU Linksventrikulaerer Druck 

| | |
| :--- | :--- |
| *Official URL*:https://gematik.de/fhir/isik/StructureDefinition/sd-mii-icu-linksventrikulaerer-druck | *Version*:6.0.0 |
| Active as of 2026-07-01 | *Computable Name*:SD_MII_ICU_Linksventrikulaerer_Druck |

 
Dieses Profil dient der spezialisierten Abbildung des linksventrikulären Drucks in der Akutmedizin. 

**Usages:**

* Examples for this Profile: [Observation/Linksventrikulaerer-Druck](Observation-Linksventrikulaerer-Druck.md)
* CapabilityStatements using this Profile: [ISiK CapabilityStatement Vitalparameter Server Extended (Expanded)](CapabilityStatement-ISiKCapabilityStatementVitalSignICUSourceExtendedAkteur-expanded.md) and [ISiK CapabilityStatement VitalSign ICU Source Extended](CapabilityStatement-ISiKCapabilityStatementVitalSignICUSourceExtendedRolle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/icu|current/StructureDefinition/StructureDefinition-sd-mii-icu-linksventrikulaerer-druck.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-sd-mii-icu-linksventrikulaerer-druck.csv), [Excel](../StructureDefinition-sd-mii-icu-linksventrikulaerer-druck.xlsx), [Schematron](../StructureDefinition-sd-mii-icu-linksventrikulaerer-druck.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "sd-mii-icu-linksventrikulaerer-druck",
  "url" : "https://gematik.de/fhir/isik/StructureDefinition/sd-mii-icu-linksventrikulaerer-druck",
  "version" : "6.0.0",
  "name" : "SD_MII_ICU_Linksventrikulaerer_Druck",
  "title" : "SD MII ICU Linksventrikulaerer Druck",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.gematik.de"
    }]
  }],
  "description" : "Dieses Profil dient der spezialisierten Abbildung des linksventrikulären Drucks in der Akutmedizin.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "https://gematik.de/fhir/isik/StructureDefinition/sd-mii-icu-sonstige-pulsatile-druecke-generisch",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      }
    },
    {
      "id" : "Observation.code.coding",
      "path" : "Observation.code.coding",
      "min" : 3,
      "max" : "3"
    },
    {
      "id" : "Observation.code.coding:sct",
      "path" : "Observation.code.coding",
      "sliceName" : "sct",
      "patternCoding" : {
        "system" : "http://snomed.info/sct",
        "code" : "276769008"
      }
    },
    {
      "id" : "Observation.code.coding:IEEE11073",
      "path" : "Observation.code.coding",
      "sliceName" : "IEEE11073",
      "min" : 1,
      "max" : "1",
      "patternCoding" : {
        "system" : "urn:iso:std:iso:11073:10101",
        "code" : "150100"
      }
    },
    {
      "id" : "Observation.component:SystolicBP",
      "path" : "Observation.component",
      "sliceName" : "SystolicBP"
    },
    {
      "id" : "Observation.component:SystolicBP.code.coding:IEEE-11073",
      "path" : "Observation.component.code.coding",
      "sliceName" : "IEEE-11073",
      "patternCoding" : {
        "system" : "urn:iso:std:iso:11073:10101",
        "code" : "150101"
      }
    },
    {
      "id" : "Observation.component:SystolicBP.code.coding:loinc-detailed",
      "path" : "Observation.component.code.coding",
      "sliceName" : "loinc-detailed",
      "min" : 0,
      "max" : "1",
      "patternCoding" : {
        "system" : "http://loinc.org",
        "code" : "8430-1"
      }
    },
    {
      "id" : "Observation.component:SystolicBP.code.coding:sct-detailed",
      "path" : "Observation.component.code.coding",
      "sliceName" : "sct-detailed",
      "min" : 0,
      "max" : "1",
      "patternCoding" : {
        "system" : "http://snomed.info/sct",
        "code" : "276780008"
      }
    },
    {
      "id" : "Observation.component:DiastolicBP",
      "path" : "Observation.component",
      "sliceName" : "DiastolicBP"
    },
    {
      "id" : "Observation.component:DiastolicBP.code.coding:IEEE-11073",
      "path" : "Observation.component.code.coding",
      "sliceName" : "IEEE-11073",
      "patternCoding" : {
        "system" : "urn:iso:std:iso:11073:10101",
        "code" : "150102"
      }
    },
    {
      "id" : "Observation.component:DiastolicBP.code.coding:loinc-detailed",
      "path" : "Observation.component.code.coding",
      "sliceName" : "loinc-detailed",
      "min" : 0,
      "max" : "1",
      "patternCoding" : {
        "system" : "http://loinc.org",
        "code" : "8375-8"
      }
    },
    {
      "id" : "Observation.component:meanBP",
      "path" : "Observation.component",
      "sliceName" : "meanBP"
    },
    {
      "id" : "Observation.component:meanBP.code.coding:IEEE-11073",
      "path" : "Observation.component.code.coding",
      "sliceName" : "IEEE-11073",
      "patternCoding" : {
        "system" : "urn:iso:std:iso:11073:10101",
        "code" : "150103"
      }
    },
    {
      "id" : "Observation.component:meanBP.code.coding:loinc-detailed",
      "path" : "Observation.component.code.coding",
      "sliceName" : "loinc-detailed",
      "min" : 0,
      "max" : "1",
      "patternCoding" : {
        "system" : "http://loinc.org",
        "code" : "8404-6"
      }
    }]
  }
}

```
